import Vue from 'vue';

import VueRouter from 'vue-router';

import adsList from '../views/ads/list/index';

import adsEdit from '../views/ads/edit/index';

import adsWorkflow from '../views/ads/workflow/index';

import raceSettings from '../views/race/settings';

import racingDashboard from '@/views/dashboard/racing';

import exposureDashboard from '@/views/dashboard/exposure';

import personalList from '@/views/personal/list';

import personalContent from '@/views/personal/content';

import abtestContent from '@/views/abtest/content';

Vue.use(VueRouter);
// 路由配置从方法调用，变成了对象传递
const routes = [
  {
    path: '/list',
    component: adsList
  },
  {
    path: '/ads-edit',
    component: adsEdit
  },
  {
    path: '/workflow',
    component: adsWorkflow
  },
  {
    path: '/race-settings',
    component: raceSettings
  },
  {
    path: '/dashboard',
    component: racingDashboard
  },
  {
    path: '/exposure-dashboard',
    component: exposureDashboard,
  },
  {
    path: '/personal-list',
    component: personalList,
  },
  {
    path: '/personal-content/edit/:id',
    component: personalContent,
  },
  {
    path: '/personal-content/add',
    component: personalContent,
  },
  {
    path: '/abtest-setting',
    component: abtestContent,
  },
  {
    path: '/ads2.x/content',
    name: 'ads2.x-content',
    component: () => import('@/views/ads2.x/content'),
  }
];
const router = new VueRouter({
  routes
});

export default router;
