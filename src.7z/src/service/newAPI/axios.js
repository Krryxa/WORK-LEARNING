'use strict';

import axios from 'axios';
import { Loading, Message } from 'element-ui';
import uriHelper from '@/libs/uri';

// const isDebug = process.env.NODE_ENV !== 'production'

// global settings
// axios.defaults.withCredentials = true
// axios.defaults.baseURL = isDebug ? '/api' : '/'

let loadingInstance;
let isNotCheckedLoginStatus = true;

let initAxios = async () => {
  const ticket = uriHelper.get('ticket');
  if (isNotCheckedLoginStatus && ticket) {
    await axios.get('/index.php?c=admin&m=ticket', {
      params: {
        'ticket': ticket,
        'madmin_app_name': uriHelper.get('madmin_app_name'),
        'madmin_component_name': uriHelper.get('madmin_component_name'),
        'madmin_version': uriHelper.get('madmin_version'),
        'madmin_app_code': uriHelper.get('madmin_app_code'),
        'madmin_component_id': uriHelper.get('madmin_component_id'),
      },
    });
    isNotCheckedLoginStatus = false;
  } else {
    // nothing to do
  }
};

axios.interceptors.request.use(config => {
  loadingInstance = Loading.service({
    lock: true,
    text: '拼命加载中',
    background: 'rgba(255, 255, 255, 0.7)',
  });
  return config;
}, error => {
  loadingInstance.close();
  Message.error({
    message: '加载超时'
  });
  console.log(error);
  return Promise.reject(error);
});

axios.interceptors.response.use(res => {
  loadingInstance.close();
  return res.data;
}, async error => {
  loadingInstance.close();
  Message.error({
    message: '加载失败'
  });
  console.dir(error);
  return Promise.reject(error);
});

(async () => { await initAxios(); })();

export default axios;
