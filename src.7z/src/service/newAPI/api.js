'use strict';

import Ax from './axios';
import qs from 'qs';

export const personalGroup = {
  // group list
  fetchGroupList (params) {
    return Ax.get('/index.php?c=personal_group&m=get_list', { params: params });
  },
  deleteGroup (params) {
    return Ax.post('/index.php?c=personal_group&m=delete', qs.stringify(params));
  },
  // group content
  fetchGroupInfo (params) {
    return Ax.get('/index.php?c=personal_group&m=get_info', { params: params });
  },
  fetchGroupTime(params) {
    return Ax.get('/index.php?c=race&m=get_group_banners_info', { params: params });
  },
  fetchCategories (params) {
    return Ax.get('/index.php?c=personal_group&m=get_category_list', { params: params });
  },
  fetchGroupsList (params) {
    return Ax.get('/index.php?c=personal_group&m=get_search_list', { params: params });
  },
  saveGroupInfo (params) {
    return Ax.post('/index.php?c=personal_group&m=save', qs.stringify(params));
  },
};

export const abtest = {
  fetchInfo () {
    return Ax.get('/index.php?c=abt&m=get_config');
  },
  saveInfo (params) {
    return Ax.post('/index.php?c=abt&m=save_config', qs.stringify(params));
  },
};

export const dashboard = {
  exportIds () {
    return '/index.php?c=dataview&m=export_ids';
  },
  fetchExposureDatas (params) {
    return Ax.get('/index.php?c=expose_data&m=query', { params: params });
  },
  exportExposureUrl () {
    return '/index.php?c=expose_data&m=export_data';
  },
};
