import URL from './url';

import axios from 'axios';

import listeners from '../../libs/listeners';

// import utils from '../../libs/utils';
import uri from '../../libs/uri';

// var qs = require('querystring');
import qs from 'qs';

var hasCheckLogin = false; /* 是否调用了检查登录接口 */

function getRequestInstance() {
  const instance = axios.create();
  instance.interceptors.request.use(config => {
    const headers = {};

    // if (config.data && (config.data instanceof FormData) ) {
    if (config.isFormData && config.data) {
      config.data = qs.stringify(config.data);
      // config.data.json = 'true';
    }

    // console.log(config);
    var url = config.url;
    if (/\?/.test(url)) {
      url += '&json=true';
    } else {
      url += '?json=true';
    }

    // var ticket = uri.get('ticket');
    // if (ticket) {
    //  url += '&ticket=' + (ticket);
    // }

    // var madminAppName = uri.get('madmin_app_name');
    // if (madminAppName) {
    //  url += '&madmin_app_name=' + (madminAppName);
    // }

    // var madminComponentName = uri.get('madmin_component_name');
    // if (madminComponentName) {
    //  url += '&madmin_component_name=' + (madminComponentName);
    // }

    // var madminVersion = uri.get('madmin_version');
    // if (madminVersion) {
    //  url += '&madmin_version=' + (madminVersion);
    // }

    // var madminAppCode = uri.get('madmin_app_code');
    // if (madminAppCode) {
    //  url += '&madmin_app_code=' + (madminAppCode);
    // }

    // var madminComponentId = uri.get('madmin_component_id');
    // if (madminComponentId) {
    //  url += '&madmin_component_id=' + (madminComponentId);
    // }

    // console.log(madminAppName, madminComponentName, madminVersion, madminAppCode, madminComponentId);

    config.url = url;

    Object.assign(headers, { 'Content-Type': 'application/x-www-form-urlencoded' });
    // 添加 X-Requested-With
    Object.assign(headers, { 'X-Requested-With': 'XMLHttpRequest' });

    Object.assign(config, { 'responseType': 'json' });

    return Object.assign(config, headers);
  });

  instance.interceptors.response.use(response => {
    // console.log("response: ", response);
    if (response && response.status === 200) {
      var result = response.data;
      if (result) {
        if (!hasCheckLogin) {
          listeners.pub('SystemAjaxResult', { 'result': result });
        }
        return Promise.resolve(result);
      } else {
        return Promise.resolve({
          status: 10001,
          msg: '服务器通信问题: 数据为空'
        });
      }
    }
    var errMsg = (response && response.msg) ? response.msg : '未知错误';
    return Promise.reject({
      status: 10002,
      msg: errMsg
    });
  }, response => {
    var errMsg = (response && response.msg) ? ('服务器通信问题: ' + response.msg) : '服务器通信问题';
    return Promise.reject({
      status: 10003,
      msg: errMsg
    });
  });

  // console.log(instance);
  // console.log(instance.request({}));
  return instance;
}

var requestAPI = getRequestInstance().request;
function Ajax(options) {
  if (this instanceof Ajax) {
    var ticket = uri.query('ticket');
    if (!ticket) {
      this.promise = requestAPI(options);
    } else { /* 拦截，全局判断登录 */
      if (!hasCheckLogin) { /* 只检查一次 */
        hasCheckLogin = true;
        requestAPI({
          method: 'get',
          url: URL.getUrl('checkTicket'),
          params: {
            'ticket': ticket,
            'madmin_app_name': uri.get('madmin_app_name'),
            'madmin_component_name': uri.get('madmin_component_name'),
            'madmin_version': uri.get('madmin_version'),
            'madmin_app_code': uri.get('madmin_app_code'),
            'madmin_component_id': uri.get('madmin_component_id')
          }
        }).then(function (result) {
          listeners.pub('SystemCheckLogin', { 'result': result });
        }, function (result) {
          listeners.pub('SystemCheckLogin', { 'result': result });
        });
      } else {
        // 已经检查了，不必理会
      }
    }
  } else {
    return new Ajax(options);
  }
}

Ajax.prototype.then = function (success, failure) {
  this.promise && this.promise.then(success, failure);
}

// const API = getRequestInstance().request;
const API = Ajax;
// 调用例子
// API({
//  url: URL.getUrl('adsList')
// }).then(s => {

// }, s => {
//  console.log(s);
// });
export { API, URL };
