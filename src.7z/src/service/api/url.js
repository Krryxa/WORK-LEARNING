'use strict';

const ADD = {
  // 开发环境基本路径
  // develop: 'http://ads-admin2-test.vip.vip.com:233/',
  // develop: 'http://localhost:9980/api/',
  development: 'http://ads-admin-test.vip.vip.com/',
  // http://ads-admin-test.vip.vip.com
  debug: '/',
  // 生产环境基本路径 http://ads-admin.vip.vip.com
  production: '/',
  // 广告列表
  adsList: 'index.php?c=banners_new&m=getBannerList',
  // 广告列表状态开关
  updateStatus: 'index.php?c=banners&m=status',
  // 广告列表删除广告
  deleteBanners: 'index.php?c=banners&m=check_ids',
  // 粘贴广告
  pasteBanners: 'index.php?c=banners&m=copy_to_visual',
  // 搜索：根据平台id获取广告位接口(下拉)
  searchZones: 'index.php?c=banners_new&m=getZones',
  // 搜索：获取广告表单获取全部app接口（下拉）
  searchApp: 'index.php?c=banners_new&m=getApp',
  // 搜索：获取父频道接口（下拉）
  searchPChannel: 'index.php?c=banners_new&m=getApplicationChannel',
  // 搜索：假设同个接口包含模糊查询及高级查询
  search: '/search',
  // TODO 上传图片接口
  uploadImg: 'index.php',

  checkTicket: 'index.php?c=admin&m=ticket',

  /* 赛马分组列表，赛马设置页面用 */
  raceGroupList: 'index.php?c=race&m=get_grouplist',
  /* 开通工作流投放 */
  getFLSettings: 'index.php?c=application_op&m=is_permit',

  /* 赛马分组的详细信息 */
  raceGroupInfo: 'index.php?c=racing_group&m=load_form',
  saveRaceSettings: 'index.php?c=race&m=save_group',
  getRaceTime: 'index.php?c=race&m=get_group_banners_info',
  getZoneInfo: 'index.php?c=zones&m=get_zones_info',
  getApplyTree: 'index.php?c=application&m=getApplyNameTree',
  getRoleList: 'index.php?c=roles&m=get_select_list',
  getPChannelList: 'index.php?c=application&m=getApplicationChannel',
  saveAdsWorkflow: 'index.php?c=application_op&m=add_op_to_application',
  unbindRoles: 'index.php?c=application_op&m=del_privileges_from_roles',

  viewDashboardDay: 'index.php?c=dataview&m=total',
  viewDashboardMonth: 'index.php?c=dataview&m=total_months',
  viewDashboardYear: 'index.php?c=dataview&m=total_years',
  getRacingSwitchRecord: 'index.php?c=dataview&m=get_racing_switch_record',
  getRaceData: 'index.php?c=racing_group&m=check_auto_switch_info',
  getUserInfo: 'index.php?d=api&c=users&m=get_user_info',

  getAppZonelist: 'index.php?c=banners&m=getZonelistForApplicationId',

  getCategoryList: 'index.php?c=pic_category&m=ADSCategoryList',
  getCategoryPicList: 'index.php?c=pic_category&m=CategoryPicList',

  getWarehouseList: 'index.php?c=basicsCommonData&m=getWarehouse',
  getPlatformList: 'index.php?c=basicsCommonData&m=getCategoryDataByModel&model=app',
  getChannelList: 'index.php?c=basicsCommonData&m=getChannelInfo',
  getAdsTemplateList: 'index.php?c=ads_template&m=getTemplateList',
  getAdsTemplateForId: 'index.php?c=ads_template&m=getTemplateForId',
  getAdsPostionList: 'index.php?c=zones&m=getZonelistForApplicationId',
  getGoMethodList: 'index.php?c=basicsCommonData&m=getGotoInfo',
  getRegionData: 'index.php?c=district&m=getdistrictassoc',
  warehouseAndRegionsMap: 'index.php?c=basicsCommonData&m=getWarehouse',

  getUserTypeList: 'index.php?c=basicsCommonData&m=getUserTags&is_privilege=1',
  getUspAttrList: 'index.php?c=usp&m=usp_property_list',
  getUspTagList: 'index.php?c=usp&m=rule_list',
  getVersionData: 'index.php?c=version&m=getVersionData',
  getUploadUrl: 'index.php?c=upload',

  getAdsInfo: 'index.php?c=banners_api&m=getBannerDetailById',
  checkZoneAd: 'index.php?c=banners&m=checkZoneAd',
  saveAdsInfo: 'index.php?c=banners_api&m=saveBannerData'
};

class UrlApi {
  // 构造函数
  constructor() {
    this.root = ADD[process.env.NODE_ENV];
  }
  // 获取完整地址
  getUrl(url) {
    let add = this.root + ADD[url];

    if (add) {
      return add;
    } else {
      console.log('NO API:' + ADD[url]);
      return '';
    }
  }
  // 获取图片地址
  getImgUrl() {
    switch (process.env.NODE_ENV) {
      case 'development':
        return '../src/static/images/';
      case 'debug':
        return '../src/static/images/';
      case 'production':
        return '../src/static/images/';
      default:
        return '../src/static/images/';
    }
  }
  // 获取主路径
  getRoot() {
    return this.root;
  }
}

const URL = new UrlApi();

export default URL;
