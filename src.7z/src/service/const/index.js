
export const basic = {
  name: '',
  startTime: '',
  endTime: '',
  // 广告类型：0-普通广告；1-OTD广告；
  type: 1,
  otdID: '111111',
  // 频道申请位：只传申请位ID
  channelApplicationSpace: '',
  // 运营位
  operationSpaces: ['1', '2'],
  weight: 1,
};

export const resource = {
  linkType: '',
  links: [
    {
      warehouse: 'default',
      adLink: 'http://www.vip.com',
    },
    {
      warehouse: 'VIP_NH',
      adLink: 'http://www.vip.com',
    },
  ],
  // 跳转方式：0-不跳转；1-普通跳转；2-领券；
  linkMode: 1,
  couponConfig: {
    imageUrl: 'http://b.appsimg.com/upload/dsdmin/2017/11/22/60/15113445596182.png',
    finalState: 1,
    buttonText: {
      left: '',
      right: '',
      center: '',
    },
    infos: [
      {
        id: '22222',
        rule: '2',
        source: '来源于419大促',
      },
      {
        id: '22222',
        rule: '2',
        source: '来源于419大促',
      },
    ],
  },
  template: '',
  // 运营位功能： 0-不使用；1-图片个性化；2-图片自动生成
  operationFunction: '1',
  imageAutomationConfig: {
    type: 1,
    pool: 232,
    category: 12344,
    group: 4343,
    ratio: 2.4,
  },
  images: {
    5: [
      {
        id: '111',
        url: 'http://b.appsimg.com/upload/dsdmin/2017/12/18/50/15135796791222.jpg',
        width: 360,
        height: 750,
        isDefault: 1,
      },
      {
        // ...
      }
    ],
    6: [
      {
        // ...
      },
    ],
  },
};

export const target = {
  userTypes: [1, 2, 3],
  // 人群：0-全部人群；1-USP人群；2-其它人群；
  userGroup: 1,
  groupConfig: {
    properties: [],
    tags: [],
    isDefault: 1,
    // 人群服务：0-金融JIE人群；1-PMC营销人群；2-沉睡唤起-7天免邮人群
    service: 1,
  },
  // 版本类型：0-全部版本；1-选中版本；2-排除选中版本；3-所选版本以上
  versionType: 1,
  versions: ['5.1.1', '6.1.1'],
  isExposed: 1,
  exposureConfig: {
    // 打压条件：0-曝光打压；1-点击打压；
    type: 1,
    exposurePv: 2,
    exposureClickPv: 2,
    clickPv: 3,
  },
};

export const more = {
  warehouses: ['VIP_NH'],
  textTips: '文字提示！！',
  videoUrl: 'http://www.vip.com',
  // 视频启动次数
  videoStartupTime: 1,
  // 轮播显示时长
  carouselStopTime: 10,
  whitelist: '',
  districts: [],
  launchingChannels: [],
};
