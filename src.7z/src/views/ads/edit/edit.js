	/**
	 * 此文件的作用是：用来对广告添加和编辑时其属性合法性的检测
	 */

	 import utils from '../../../libs/utils';

	/*
		检查跳转地址的红包模块
		@params data 需要检查的数据,数据形式见ads/edit中的couponInfo
		@return {'error': 0/1, 'errorText': errorText, 'warnText': warnText}
	 */
	var checkAdsCoupon = function(data) {
		var isRight = true;
		var errorText = '';
		var warnText = '';

		//检查图片
		var image = data.image;
		if (!utils.trim(image.url)) {
			isRight = false;
			errorText = '红包弹窗图不能为空';
			return {'error': (isRight?0:1), 'errorText': errorText, 'warnText': warnText};
		}

		//检查按钮
		var buttons = data.buttons;
		for (var i = 0; i < buttons.length; i++) {
			var buttonInfo = buttons[i];
			var text = utils.trim(buttonInfo.text);
			if (buttonInfo.required && !text) {
				isRight = false;
				errorText = buttonInfo.msg + '不能为空';
				return {'error': (isRight?0:1), 'errorText': errorText, 'warnText': warnText};
			}
		}

		var couponList = data.couponList;
		for (var m = 0; m < couponList.length; m++) {
			var coupons = couponList[m];
			for (var n = 0; n < coupons.length; n++) {
				var coupon = coupons[n];
				if (coupon.required && !utils.trim(coupon.text)) {
					isRight = false;
					errorText = '第' + (m + 1) + '红包券的' + coupon.msg + '不能为空';
					return {'error': (isRight?0:1), 'errorText': errorText, 'warnText': warnText};
				}
			}
		}

		//检查红包券
		return {'error': (isRight?0:1), 'errorText': errorText, 'warnText': warnText};
	}

	/*
		提交跳转地址数据时，组装成服务器需要的形式
		@params data 需要检查的数据,数据形式见ads/edit中的couponInfo
		@return 见 http://wiki.corp.vipshop.com/pages/viewpage.action?pageId=388924505
	 */
	var constructAdsCoupon = function(data) {
		var paramObj = {};
		paramObj.coupon_image = data.image.url;
		paramObj.coupon_image_size = data.image.size;
		var curButtons = data.buttons;
		curButtons.forEach(button => {
			paramObj[button.key] = utils.trim(button.text);
		});

		//券
		var couponObj = {};
		var curCoupons = data.couponList;
		curCoupons.forEach(inputs => {
			inputs.forEach(input => {
				var inputInfo = couponObj[input.key];
				if (inputInfo) {
					inputInfo.push(input.text);
				} else {
					couponObj[input.key] = [input.text];
				}
			});
		});
		utils.extend(paramObj, couponObj);
		var other = data.other;
		paramObj[other.key] = other.isShow ? 'on' : '';

		return {'adcoupon': paramObj};
	}


	/*
		检查跳转地址的地址模块
		@params data 需要检查的数据,数据形式见ads/edit中的urlInfo
		@return {'error': 0/1, 'errorText': errorText, 'warnText': warnText}
	 */
	var checkAdsUrl = function(data) {
		var spaceReg = /\s/;
		var isRight = true;
		var errorText = '';
		var warnText = '';

		/**
		 * [{"fieldType":"URI","fieldName":"brand_id","is_optionnal":1},
		 * {"fieldType":"STRING","fieldName":"title","is_optionnal":1},
		 * {"fieldType":"NUMBER","fieldName":"title","is_optionnal":0}]
		 */
		var formatInfos = data.formatInfos;
		var separator = data.separator;
		var urls = data.urls;

		/* 不做检查，直接返回正确 */
		if (formatInfos && formatInfos.length > 0 && formatInfos[0].fieldType == 'EMPTY') {
			return {'error': 0, 'errorText': errorText, 'warnText': warnText}
		}

		if (urls.length <= 0) {
			errorText = '没有跳转地址';
			return {'error': 1, 'errorText': errorText, 'warnText': warnText};
		}

		//检查第一条
		var newUrl = utils.trim(urls[0].url);
		if (!newUrl) {
			isRight = false;
			errorText = '第1个跳转地址不能为空';
			return {'error': 1, 'errorText': errorText, 'warnText': warnText};
		} else if (spaceReg.test(newUrl)) {
			isRight = false;
			errorText = '第1个跳转地址存在空格';
			return {'error': 1, 'errorText': errorText, 'warnText': warnText};
		}


		//判断是否有重复或没选择的情况
		var tmpUrlObj = {};
		for (var i = 1; i < urls.length; i++) {		/* 第一个是默认地址不用判断 */
			var curNum = i + 1;
			var urlInfo = urls[i];
			var curWarehouseTxt = urlInfo.warehouse;
			if (!curWarehouseTxt) {
				errorText = '第' + curNum + '跳转地址没有选择分仓';
				return {'error': 1, 'errorText': errorText, 'warnText': warnText};
			}
			var curPlatformTxt = urlInfo.platform;
			if (!curPlatformTxt) {
				errorText = '第' + curNum + '跳转地址没有选择平台';
				return {'error': 1, 'errorText': errorText, 'warnText': warnText};
			}

			var curWarehouses = curWarehouseTxt.split('-');
			var curPlatforms = curPlatformTxt.split('-');

			for (var m = 0; m < curWarehouses.length; m++) {
				var warehouse = curWarehouses[m];
				for (var n = 0; n < curPlatforms.length; n++) {
					var platform = curPlatforms[n];
					var newKey = warehouse + '-' + platform;
					if (tmpUrlObj[newKey]) {	//已经存在，值就是第几个
						var prevNum = tmpUrlObj[newKey];
						errorText = '第' + prevNum + '跳转地址和第' + curNum + '跳转地址存在重复的情况，请删除多余的地址' ;
						return {'error': 1, 'errorText': errorText, 'warnText': warnText};
					} else {
						tmpUrlObj[newKey] = curNum;
					}
				}
			}
		}

		for (var i = 1; i < urls.length; i++) {
			var urlInfo = urls[i];
			var newUrl = utils.trim(urlInfo.url);
			if (!newUrl) {
				isRight = false;
				errorText = '第' + (i + 1) + '个跳转地址不能为空';
				break;
			} else if (spaceReg.test(newUrl)) {
				isRight = false;
				errorText = '第' + (i + 1) + '个跳转地址存在空格';
				break;
			}
		}

		if (isRight && formatInfos && formatInfos.length > 0) {

			for (var index = 0; index < urls.length; index++) {

				var value = utils.trim(urls[index].url);

				if (separator) {
					var querys = value.split(separator);
					if (querys.length == formatInfos.length) {
						for (var i = 0; i < querys.length; i++) {
							var query = querys[i];
							var formatInfo = formatInfos[i];

							if (formatInfo.fieldType == 'URI') {	//url
								var searchArr = utils.arrQuery(query);
								var isOptionnal = formatInfo.is_optionnal ? true : false;
								if (searchArr.length == 2 && searchArr[0] == formatInfo.fieldName) {
									var searchValue = searchArr[1];
									if (isOptionnal) {
										if (searchValue && !utils.isUri(searchValue)) {
											errorText = '第' + (index + 1) + '个跳转地址非法,' + searchArr[0] + '应为 ' + formatInfo.fieldName + '=xxx(xxx为以://或http://或https://开头的非必填链接)';
											isRight = false;
											break;
										}

										if (searchValue && utils.isWapUrl(searchValue)) {
											warnText = ('你填写的是M站链接，请填写正确专题智能分仓链接（以https://mst.vip.com开头的）.(注：程序将继续运行)');
										}

									} else {
										if (!utils.isUri(searchValue)) {
											errorText = '第' + (index + 1) + '个跳转地址非法,' + searchArr[0] + '应为 ' + formatInfo.fieldName + '=xxx(xxx为以://或http://或https://开头的必填链接)';
											isRight = false;
											break;
										}

										if (utils.isWapUrl(searchValue)) {
											warnText = ('你填写的是M站链接，请填写正确专题智能分仓链接（以https://mst.vip.com开头的）.(注：程序将继续运行)');
										}
									}
								} else {
									errorText = '第' + (index + 1) + '个跳转地址非法,' + searchArr[0] + '应为 ' + formatInfo.fieldName + '=xxx' + (isOptionnal ? '(xxx为以://或http://或https://开头的非必填链接)' : '(xxx为以://或http://或https://开头的必填链接)');
									isRight = false;
									break;
								}
							} else if (formatInfo.fieldType == 'NUMBER') {
								var searchArr = utils.arrQuery(query);
								var isOptionnal = formatInfo.is_optionnal ? true : false;
								if (searchArr.length == 2 && searchArr[0] == formatInfo.fieldName) {
									var searchValue = searchArr[1];
									if (isOptionnal) {
										if (searchValue && !utils.isNumber(searchValue)) {
											errorText = '第' + (index + 1) + '个跳转地址非法,' + searchArr[0] + '应为 ' + formatInfo.fieldName + '=xxx(xxx为非必填数字)';
											isRight = false;
											break;
										}
									} else {
										if (!utils.isNumber(searchValue)) {
											errorText = '第' + (index + 1) + '个跳转地址非法,' + searchArr[0] + '应为 ' + formatInfo.fieldName + '=xxx(xxx为必填数字)';
											isRight = false;
											break;
										}
									}
								} else {
									errorText = '第' + (index + 1) + '个跳转地址非法,' + searchArr[0] + '应为 ' + formatInfo.fieldName + '=xxx' + (isOptionnal ? '(xxx为非必填数字)' : '(xxx为必填数字)');
									isRight = false;
									break;
								}
							} else if (formatInfo.fieldType == 'STRING') { //STRING
								var searchArr = utils.arrQuery(query);
								var isOptionnal = formatInfo.is_optionnal ? true : false;
								if (searchArr.length == 2 && searchArr[0] == formatInfo.fieldName) {
									var searchValue = searchArr[1];
									if (isOptionnal) {
										// do nothing
									} else {
										if (!searchValue) {
											errorText = '第' + (index + 1) + '个跳转地址非法,' + searchArr[0] + '应为 ' + formatInfo.fieldName + '=xxx(xxx为非必填字符串)';
											isRight = false;
											break;
										}
									}
									if (searchValue && utils.isWapUrl(searchValue)) {
										warnText = ('你填写的是M站链接，请填写正确专题智能分仓链接（以https://mst.vip.com开头的）.(注：程序将继续运行)');
									}
								} else {
									errorText = '第' + (index + 1) + '个跳转地址非法,' + searchArr[0] + '应为 ' + formatInfo.fieldName + '=xxx' + (isOptionnal ? '(xxx为非必填字符串)' : '(xxx为必填字符串)');
									isRight = false;
									break;
								}
							}

						}
					} else {
						var formatStr = '';
						formatInfos.forEach(function(item) {
							var isOptionnal = item.is_optionnal ? true : false;
							var typeStr = 'xxx';
							if (item.fieldType == 'URI') {
								typeStr = '链接';
							} else if (item.fieldType == 'NUMBER') {
								typeStr = '数字';
							} else if (item.fieldType == 'STRING') {
								typeStr = '字符串';
							}
							formatStr += item.fieldName + '=' + typeStr + separator;
						});
						formatStr = formatStr.substr(0, formatStr.length - separator.length);
						errorText = '第' + (index + 1) + '个跳转地址非法,格式应如 ' + formatStr;
						isRight = false;
						break;
					}
				} else {	/* 没有分隔符的情况，直接输入框当成整个值 */
					var formatInfo = formatInfos[0];
					if (formatInfo.fieldType == 'URI') {	//url
						if (!utils.isUri(value)) {
							errorText = '第' + (index + 1) + '个跳转地址不是正确的链接(格式应以://或http://或https://开头)';
							isRight = false;
							break;
						}

						if (utils.isWapUrl(value)) {
							warnText = ('你填写的是M站链接，请填写正确专题智能分仓链接（以https://mst.vip.com开头的）.(注：程序将继续运行)');
						}
					} else if (formatInfo.fieldType == 'NUMBER') {
						if (!utils.isNumber(value)) {
							errorText = '第' + (index + 1) + '个跳转地址非法,请输入数字';
							isRight = false;
							break;
						}
					} else if (formatInfo.fieldType == 'STRING') { //STRING
						if (utils.isWapUrl(value)) {
							warnText = ('你填写的是M站链接，请填写正确专题智能分仓链接（以https://mst.vip.com开头的）.(注：程序将继续运行)');
						}
					}
				}
			}
		}

		return {'error': (isRight?0:1), 'errorText': errorText, 'warnText': warnText};
	}

	/*
		提交跳转地址数据时，组装成服务器需要的形式
		@params data 需要检查的数据,数据形式见ads/edit中的urlInfo
		@return 见 http://wiki.corp.vipshop.com/pages/viewpage.action?pageId=388924505
	 */
	var constructAdsUrl = function(data) {
		var paramObj = {};
		var adlink = {};
		var urls = data.urls;
		urls.forEach((urlInfo, index) => {
			var newKey, newValue;
			if (index == 0) {
				newKey = '0';
			} else {
				newKey = urlInfo.warehouse + '-' + urlInfo.platform;
			}
			var tmpObj = {};
			adlink[newKey] = urlInfo.url;

		});
		paramObj.adlink = adlink;
		// paramObj.adcoupon = '';
		return paramObj;
	}


	/*
		检查广告图模板的数据
		@params data 需要检查的数据,数据形式见ads/edit中的adsTemplateInfo
		@return {'error': 0/1, 'errorText': errorText, 'warnText': warnText}
	 */
	var checkAdsTemplate = function(data) {

		var isRight = true;
		var errorText = '';
		var warnText = '';

		if (data.isIndividual) {	/* 个性化 */
			isRight = false;
			errorText = '至少选择一张个性化图片';
			var groups = data.groups;
			groups.forEach(group => {
				if (group.individualPics.length > 0) {
					errorText = '';
					isRight = true;
				}
			});
		} else {
			isRight = false;
			errorText = '至少上传一张广告图';
			var groups = data.groups;
			groups.forEach(group => {
				group.pictures.forEach(picture => {
					if (picture.url) {
						errorText = '';
						isRight = true;
					}
				});
			});
		}

		return {'error': (isRight?0:1), 'errorText': errorText, 'warnText': warnText};
	}

	/*
		提交广告图模板数据时(不是个性化)，组装成服务器需要的形式
		@params data 需要检查的数据,数据形式见ads/edit中的adsTemplateInfo
		@return 见 http://wiki.corp.vipshop.com/pages/viewpage.action?pageId=388924505
	 */
	var constructTemplatePic = function(data) {
		var paramObj = {};
		var tmpPictureObj = {};
		var curGroups = data.groups;
		curGroups.forEach(group => {
			var curPictures = group.pictures;
			curPictures.forEach(picture => {
				var tmpResolutionObj = {};
				tmpPictureObj[picture.resolution] = tmpResolutionObj;
				tmpResolutionObj['1'] = [picture.url, picture.surl];
			});
		});
		paramObj.pictures = tmpPictureObj;
		return paramObj;
	}

	/*
		提交广告图模板数据时(个性化)，组装成服务器需要的形式
		@params data 需要检查的数据,数据形式见ads/edit中的adsTemplateInfo
		@return 见 http://wiki.corp.vipshop.com/pages/viewpage.action?pageId=388924505
	 */
	var constructIndividualPic = function(data) {
		var paramObj = {};
		var tmpPictureObj = {};
		var curGroups = data.groups;
		curGroups.forEach(group => {
			var curPictures = group.individualPics;
			var curResolution = group.individualResolution;
			curPictures.forEach(picture => {
				var tmpResolutionObj = {};
				tmpPictureObj[curResolution] = tmpResolutionObj;
				tmpResolutionObj[picture.id] = {
					"pic": picture.url,
                    "pic_name": picture.picName,
                    "height": picture.height,
                    "width": picture.width,
                    "category_name": picture.categoryName,
                    "is_default": picture.isDefault
				};
			});
		});
		paramObj.pic_category = tmpPictureObj;
		return paramObj;

	};

	var isRightUserType = function(typeList, type) {
		for (var i = 0; i < typeList.length; i++) {
			var userType = typeList[i];
			if (userType.id == type) {
				return true;
			}
		}
		return false;
	};


	var preVerTag = '8.';

	/* 比较 */
	var compare = function(text1, text2) {
	    var verTxt1 = text1;
	    var verTxt2 = text2;
	    var hasPreVer1 = false;
	    var hasPreVer2 = false;
	    if (verTxt1.indexOf(preVerTag) == 0) {
	      verTxt1 = verTxt1.substr(preVerTag.length);
	      hasPreVer1 = true;
	    }
	    if (verTxt2.indexOf(preVerTag) == 0) {
	      verTxt2 = verTxt2.substr(preVerTag.length);
	      hasPreVer2 = true;
	    }

	    if (verTxt1 == verTxt2) {
	      if (hasPreVer1 == hasPreVer2) {
	        return 0;
	      } else if (hasPreVer1 && !hasPreVer2) {
	        return -1;
	      } else {
	        return 1;
	      }
	    } else {
	      var verArr1 = verTxt1.split('.');
	      var verArr2 = verTxt2.split('.');
	      var maxLen = Math.max(verArr1.length, verArr2.length);
	      for (var i = 0; i < maxLen; i++) {
	        var subVer1 = verArr1[i];
	        var subVer2 = verArr2[i];
	        if (subVer1 !== undefined && subVer2 !== undefined) {
	          subVer1 = parseInt(subVer1);
	          subVer2 = parseInt(subVer2);
	          if (subVer1 == subVer2) {
	            continue;
	          } else if (subVer1 > subVer2) {
	            return 1
	          } else {
	            return -1;
	          }
	        } else if (subVer1 !== undefined) {
	          return 1;
	        } else if (subVer2 !== undefined) {
	          return -1
	        } else {
	          return 0;
	        }
	      }
	      return 0;
	    }
	}

	/* 按降序排，5.31大于8.5.31 */
	var sortVersion = function(a, b) {
		var value = compare(a.name, b.name);
		return -value;
	}

	export default {
		preVerTag,
		checkAdsCoupon,
		checkAdsUrl,
		checkAdsTemplate,
		sortVersion,
		constructAdsCoupon,
		constructAdsUrl,
		constructTemplatePic,
		constructIndividualPic,
		isRightUserType
	};

