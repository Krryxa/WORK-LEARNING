<template>
  <div class="container-box ads-edit-box" v-loading="bodyLoading" element-loading-text="拼命加载中">
    <header class="container-header clearfix">
      <div class="top-line-title">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item v-if="isVisual">可视化投放</el-breadcrumb-item>
          <el-breadcrumb-item v-else>广告列表</el-breadcrumb-item>
          <el-breadcrumb-item v-if="adsId">广告内容编辑(ID:{{adsId}})</el-breadcrumb-item>
          <el-breadcrumb-item v-else>添加广告</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="source-box">
        <div class="inner">
          <span class="source">（特卖会）</span>
        </div>
      </div>
    </header>

    <div class="container-body">

      <div class="base-panel">
        <h2 class="title">基本信息
          <span style="font-size:14px;" v-if="isPlan">（规划日历广告<span v-if="planPersonalID"> - 个性化分组ID:{{ planPersonalID }}</span><span v-if="loopPicFrameID"> - 帧数:{{ loopPicFrameID }}</span>）</span>
        </h2>
        <div class="settings-row">
          <div class="settings-label"><span class="star">*</span>广告名称：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <el-input v-model="adsName" placeholder="建议按规范格式命名（见右侧提示），以便查找和统计数据" size="small"></el-input>
              <template>
                <el-tooltip placement="right">
                  <div slot="content" class="g-ads-tooltip">点击打开详细说明文档</div>
                  <a class="info-icon" href="http://wiki.corp.vipshop.com/pages/viewpage.action?pageId=360418358" target="_blank"><i class="el-icon-info"></i></a>
                </el-tooltip>
              </template>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label"><span class="star">*</span>上线时间：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <el-row>
                <el-col :span="11">
                  <el-date-picker
                    class="datetime"
                    v-model="startTime"
                    size="small"
                    type="datetime"
                    :default-value="defaultStartTime"
                    placeholder="选择开始时间">
                  </el-date-picker>
                </el-col>
                <el-col :span="2">
                  <div class="txt-to">至</div>
                </el-col>
                <el-col :span="11">
                  <el-date-picker
                    class="datetime"
                    v-model="endTime"
                    size="small"
                    type="datetime"
                    :default-value="defaultEndTime"
                    placeholder="选择结束始时间(不能超过半年)">
                  </el-date-picker>
                </el-col>
              </el-row>
              <el-tooltip placement="right">
                <div slot="content" class="g-ads-tooltip">广告上线时长不能超过半年</div>
                <div class="info-icon"><i class="el-icon-info"></i></div>
              </el-tooltip>
            </div>
          </div>
        </div>
        <div class="settings-row" v-if="!isVisual">
          <div class="settings-label"><span class="star">*</span>频道申请位：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <template>
                <el-cascader
                  :options="applyList"
                  filterable
                  placeholder="单选，或关键字搜索"
                  :props="{value: 'id', label: 'name'}"
                  size="small"
                  class="full-box"
                  v-model="selectedApplys"
                  @change="handleApplyChange"></el-cascader>
              </template>
            </div>
          </div>
        </div>
        <div class="settings-row" v-if="!isVisual">
          <div class="settings-label"><span class="star">*</span>广告运营位：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <template>
                <el-select v-model="selectedAdsPositions" multiple :disabled="selectedApplys.length<=0" filterable :placeholder="selectedApplys.length>0 ? '多选，或关键字搜索' : '请先设置频道申请位'" size="small" class="full-box">
                  <el-option
                    v-for="item in adsPositionList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id">
                  </el-option>
                </el-select>
              </template>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label"><span class="star">*</span>权重值：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <el-input-number controls-position="right" size="small" v-model="adsWeight" :step="1" :min="0" :max="20" class="number-box"></el-input-number>
            </div>
          </div>
        </div>
      </div>

      <div class="base-panel">
        <h2 class="title">
          <div class="title-inner">
            <div class="title-txt">链接与图片</div>
          </div>
        </h2>
        <div class="settings-row">
          <div class="settings-label"><span class="star">*</span>跳转到：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <template>
                <el-select v-model="selectedGoMethod" placeholder="请选择" size="small" class="full-box" @change="handleGoMethodChange">
                  <el-option
                    v-for="item in goMethodList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id">
                  </el-option>
                </el-select>
              </template>
            </div>
          </div>
        </div>
        <div class="settings-wrap">
          <div class="settings-row settings-row-txt2" v-if="selectedGoMethod&&couponInfo">
            <div class="settings-label">&nbsp;</div>
            <div class="settings-cnt">
              <div class="cnt-box">
                <ads-coupon v-model="couponInfo"></ads-coupon>
              </div>
            </div>
          </div>
          <!-- <div class="settings-row" v-if="selectedGoMethod&&(!couponInfo)"> -->
          <div class="settings-row">
            <div class="settings-label">跳转地址：</div>
            <div class="settings-cnt">
              <div class="cnt-box">
                <ads-url :urlPlatformList="urlPlatformList" :urlWarehouseList="urlWarehouseList" v-model="urlInfo"></ads-url>
              </div>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label"><span class="star">*</span>广告图模板：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <template>
                <el-select v-model="selectedAdsTemplate" placeholder="单选，或关键字搜索。（先选模板再上传广告图）" filterable size="small" class="full-box" @change="handleAdsTemplateChange">
                  <el-option
                    v-for="item in adsTemplateList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id">
                  </el-option>
                </el-select>
              </template>
            </div>
          </div>
        </div>
        <div class="settings-wrap" v-if="selectedAdsTemplate">
          <div class="settings-row">
            <div class="settings-label"><span class="star">*</span>上传图片：</div>
            <div class="settings-cnt">
              <div class="cnt-box">
                <ads-template v-model="adsTemplateInfo"></ads-template>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="base-panel">
        <h2 class="title">
          <div class="title-inner">
            <div class="title-txt">投放目标</div>
          </div>
        </h2>
        <div class="settings-row">
          <div class="settings-label">新老客：</div>
          <div class="settings-cnt">
            <div class="cnt-box cnt-box-form">
              <el-row>
                <el-col :span="7" class="two-col-box">
                  <el-tree :data="newUserTypes" ref="newUserTypeTree" :props="{label: 'name'}" show-checkbox node-key="id"></el-tree>
                </el-col>
                <el-col :span="1">
                  &nbsp;
                </el-col>
                <el-col :span="15" class="five-col-box">
                  <el-tree :data="oldUserTypes" ref="oldUserTypeTree" :props="{label: 'name'}" show-checkbox node-key="id"></el-tree>
                </el-col>
                <el-col :span="1">
                  &nbsp;
                </el-col>
              </el-row>
              <el-tooltip placement="right">
                <div slot="content" class="g-ads-tooltip">点击打开详细说明文档</div>
                <a class="info-icon" href="http://wiki.corp.vipshop.com/pages/viewpage.action?pageId=33673552" target="_blank"><i class="el-icon-info"></i></a>
              </el-tooltip>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label">人群：</div>
          <div class="settings-cnt">
            <div class="cnt-box cnt-box-form">
              <template>
                <el-radio-group v-model="uspType">
                  <el-radio :label="0">全部人群</el-radio>
                  <el-radio :label="1">USP人群</el-radio>
                  <el-radio :label="-1">其它人群</el-radio>
                </el-radio-group>
              </template>
            </div>
          </div>
        </div>
        <div class="settings-wrap" v-if="uspType==1">
          <div class="settings-row">
            <div class="settings-label">人群属性：</div>
            <div class="settings-cnt">
              <div class="cnt-box">
                <template>
                  <!-- <el-cascader :options="uspAttrList" multiple filterable placeholder="fr开头的USP人群，多选为并集，或关键字搜索" size="small" class="full-box" v-model="selectedUspAttrs" :props="{value: 'id', label: 'name'}">
                  </el-cascader> -->
                  <el-select v-model="selectedUspAttrs" multiple placeholder="ug开头的USP人群，多选为并集，或关键字搜索" size="small" class="full-box">
                    <el-option
                      v-for="item in uspAttrList"
                      :key="item.id"
                      :label="item.name"
                      :value="item.id">
                      <span class="child-name" style="float: left;">{{ item.name }}</span>
                      <span class="parent-name" style="float: right; color: #8492a6; font-size: 13px; margin-right: 30px;">{{ item.parentName }}</span>
                    </el-option>
                  </el-select>
                </template>
                <el-tooltip placement="right">
                  <div slot="content" class="g-ads-tooltip">
                    “人群属性”与“ 人群标签”是交集关系。<br />
                    即当这个广告同时选取了“人群属性”与“ 人群标签”时，只有同时符合的用户才能看到这个广告。<br />
                    例如：USP人群属性选取了“70后丽人”，USP人群标签选取了“唯品花开通用户”，则只有是唯品花开通用户，并且也是70后丽人的用户，才能看到这个广告。
                  </div>
                  <div class="inter-icon">交</div>
                </el-tooltip>
              </div>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-label">人群标签：</div>
            <div class="settings-cnt">
              <div class="cnt-box">
                <template>
                  <el-select v-model="selectedUspTags" multiple placeholder="ug开头的USP人群，多选为并集，或关键字搜索" size="small" class="full-box">
                    <el-option
                      v-for="item in uspTagList"
                      :key="item.id"
                      :label="item.name"
                      :value="item.id">
                    </el-option>
                  </el-select>
                </template>
              </div>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-label">默认设置：</div>
            <div class="settings-cnt">
              <div class="cnt-box cnt-box-form">
                <span class="usp-prompt">当以上人群标签异常时，该广告对所有人群默认不展示</span>
                <template>
                  <el-radio-group v-model="isUspShow">
                    <el-radio :label="1">默认展示</el-radio>
                    <el-radio :label="0">默认不展示</el-radio>
                  </el-radio-group>
                </template>
              </div>
            </div>
          </div>
        </div>
        <div class="settings-wrap" v-else-if="uspType==-1">
          <div class="settings-row">
            <div class="settings-label">人群服务：</div>
            <div class="settings-cnt">
              <div class="cnt-box cnt-box-form">
                <template>
                  <el-radio-group v-model="serviceType">
                    <el-radio :label="1">金融JIE人群</el-radio>
                    <el-radio :label="2">PMC营销人群</el-radio>
                    <el-radio :label="3">沉睡唤起-7天免邮人群</el-radio>
                  </el-radio-group>
                </template>
              </div>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-label">默认设置：</div>
            <div class="settings-cnt">
              <div class="cnt-box cnt-box-form">
                <span class="usp-prompt">当以上USP人群异常时，该广告对所有人群</span>
              </div>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label">版本号：</div>
          <div class="settings-cnt">
            <div class="cnt-box cnt-box-form">
              <template>
                <el-radio-group v-model="versionType">
                  <el-radio :label="2">全部版本</el-radio>
                  <el-radio :label="0">选中版本</el-radio>
                  <el-radio :label="-1">排除选中版本</el-radio>
                  <el-radio :label="1">所选版本以上</el-radio>
                </el-radio-group>
              </template>
              <el-tooltip placement="right">
                <div slot="content" class="g-ads-tooltip">点击打开详细说明文档</div>
                <a class="info-icon" href="http://wiki.corp.vipshop.com/pages/viewpage.action?pageId=90380773" target="_blank"><i class="el-icon-info"></i></a>
              </el-tooltip>
            </div>
          </div>
        </div>
        <div class="settings-wrap" v-if="versionType==0||versionType==-1">
          <div class="settings-row settings-prompt-row">
            <span class="prompt-txt" v-if="versionType==1">（广告只对以下选中版本生效）</span>
            <span class="prompt-txt" v-else-if="versionType==-1">（广告对以下选中版本不生效）</span>
          </div>
          <div class="settings-row settings-row-txt">
            <div class="settings-label">&nbsp;</div>
            <div class="settings-cnt">
              <div class="cnt-box">
                <div class="five-col-box clearfix">
                  <el-tree :data="treeVersions" ref="versionTree" :props="{label: 'name'}" show-checkbox node-key="id"></el-tree>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="settings-wrap" v-else-if="versionType==1">
          <div class="settings-row settings-prompt-row">
            <span class="prompt-txt">（广告对选中版本[含当前选中的版本]以上的版本生效，含8.x.x的安卓预装版本）</span>
          </div>
          <div class="settings-row settings-row-txt">
            <div class="settings-label">&nbsp;</div>
            <div class="settings-cnt">
              <div class="cnt-box cnt-box-form">
                <el-row>
                  <el-col :span="20" class="five-col-box">
                    <el-select v-model="selectedVersion" placeholder="请选择" size="small" class="full-box">
                      <el-option
                        v-for="item in versionList"
                        :key="item.id"
                        :label="item.name"
                        :value="item.id">
                      </el-option>
                    </el-select>
                  </el-col>
                  <el-col :span="4">
                    <span class="version-txt">版本以上</span>
                  </el-col>
                </el-row>
              </div>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label">曝光打压：</div>
          <div class="settings-cnt">
            <div class="cnt-box cnt-box-form">
              <el-switch
                v-model="isExposeOpen"
                active-color="#13ce66"
                inactive-color="#c0ccda">
              </el-switch>
              <el-tooltip placement="right">
                <div slot="content" class="g-ads-tooltip">曝光打压用于有效控制广告的流量，避免流量浪费。通过设置曝光、点击、销售额等多个条件去控制这个广告对于一个用户能展示的次数</div>
                <div class="info-icon"><i class="el-icon-info"></i></div>
              </el-tooltip>
            </div>
          </div>
        </div>
        <div class="settings-wrap" v-if="isExposeOpen">
          <div class="settings-row">
            <div class="settings-label">打压条件：</div>
            <div class="settings-cnt">
              <div class="cnt-box cnt-box-form">
                <template>
                  <el-radio-group v-model="suppressType">
                    <el-radio :label="0">曝光打压</el-radio>
                    <el-radio :label="1">点击打压</el-radio>
                  </el-radio-group>
                </template>
                <div v-if="suppressType==0" :key="0">
                  <div class="expose-row">
                    <span>查看次数（单个用户曝光量PV） 大于等于（≥）</span>
                    <el-input-number controls-position="right" size="small" v-model="viewTimes" :step="1" :min="0" class="expose-input"></el-input-number>
                  </div>
                  <div class="expose-row">
                    <span>单个用户点击次数（点击量PV） 小于等于（≤）</span>
                    <el-input-number controls-position="right" size="small" v-model="clickTimes" :step="1" :min="0" class="expose-input"></el-input-number>
                  </div>
                </div>
                <div v-if="suppressType==1" :key="1">
                  <div class="expose-row">
                    <span>单个用户点击次数（点击量PV） 大于等于（≥）</span>
                    <el-input-number controls-position="right" size="small" v-model="clickTimes2" :step="1" :min="0" class="expose-input"></el-input-number>
                  </div>
                </div>
                <div class="prompt-txt">（注：曝光打压只针对<b>同时符合以上全部打压条件</b>的用户生效，对未符合条件的用户，广告仍然正常展示。）</div>
                <div class="prompt-txt">（注：如广告生效期间，想重新设置曝光打压条件或关闭曝光打压，请重新投放一个新的广告。）</div>
                <div class="prompt-txt">（注：广告时间不要超过30天，否则曝光打压会在30天时失效。）</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="base-panel">
        <h2 class="title">
          <div class="title-inner">
            <div class="title-txt">更多设置</div>
          </div>
        </h2>
        <div class="settings-row">
          <div class="settings-label">分仓：</div>
          <div class="settings-cnt">
            <div class="cnt-box cnt-box-form">
              <template>
                <el-checkbox-group v-model="selectedWarehouses" @change='handleWhChange'>
                  <el-checkbox :label="wh.id" v-for="wh in warehouses" :key="wh.id">{{wh.name}}</el-checkbox>
                  <!-- <el-checkbox label="VIP_CD">成都-CD</el-checkbox>
                  <el-checkbox label="VIP_SH">上海-SH</el-checkbox>
                  <el-checkbox label="VIP_NH">南海-NH</el-checkbox>
                  <el-checkbox label="VIP_HZ">华中-HZ</el-checkbox> -->
                </el-checkbox-group>
              </template>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label">文字提示：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <el-input v-model="adsTooltips" placeholder="如为文字广告，请输入文字信息，这里也支持其他场景的文字字段" size="small"></el-input>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label">视频广告URL：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <el-input v-model="adsVideoUrl" placeholder="如为动态视频广告，请输入视频URL（只支持腾讯云视频URL）" size="small"></el-input>
              <div class="info-icon view-icon"><i class="el-icon-view" @click="clickView"></i></div>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label">启动视频次数：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <div class="number-warp">
                <el-input-number controls-position="right" size="small" v-model="adsTimes" :step="1" :min="0" class="full-box"></el-input-number>
                <span class="number-unit">次</span>
              </div>
              <el-tooltip placement="right">
                <div slot="content" class="g-ads-tooltip">只用于启动页视频，每个用户最多能看到本广告的次数</div>
                <div class="info-icon"><i class="el-icon-info"></i></div>
              </el-tooltip>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label">轮播显示时长：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <div class="number-warp">
                <el-input-number controls-position="right" size="small" v-model="adsDuration" :step="1" :min="0" class="full-box"></el-input-number>
                <span class="number-unit">秒</span>
              </div>
              <el-tooltip placement="right">
                <div slot="content" class="g-ads-tooltip">轮播广告每帧显示的时长</div>
                <div class="info-icon"><i class="el-icon-info"></i></div>
              </el-tooltip>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label">白名单：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <el-input v-model="whiteListStr" type="textarea" :rows="1" placeholder="仅支持mid，可输入最多10个用户mid，用英文逗号 &quot;,&quot; 隔开" size="small"></el-input>
              <el-tooltip placement="right">
                <div slot="content" class="g-ads-tooltip">设置白名单后，本广告必然会对白名单用户显示。如只想对白名单用户展示，其他用户不显示，则请在USP人群标签处选择“白名单专用”标签</div>
                <div class="info-icon"><i class="el-icon-info"></i></div>
              </el-tooltip>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label">地区：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <region :data="regionData" v-model="selectedRegions"></region>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label">渠道：</div>
          <div class="settings-cnt">
            <div class="cnt-box">
              <template>
                <el-transfer
                  v-model="selectedChannels"
                  filterable
                  :props="{key: 'id', label: 'name'}"
                  :titles="['渠道', '已选中']"
                  :data="channelList">
                </el-transfer>
              </template>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!--底部条-->
    <footer class="container-footer clearfix">
      <div class="btn-box">
        <el-button type="primary" size="small" class="save-btn" @click="saveSettings()"><strong>保存</strong></el-button>
        <el-button class="cancel-btn" size="small" @click="goBack()">取消</el-button>
      </div>
    </footer>
  </div>
</template>

<script>

  import utils from '../../../libs/utils';
  import uri from '../../../libs/uri';
  import editLib from './edit';
  import listeners from '../../../libs/listeners';
  import region from 'com/region/index';
  import adsUrl from 'com/adsUrl/index';
  import adsCoupon from 'com/adsCoupon/index';
  import adsTemplate from 'com/adsTemplate/index';

  import regionData from '../../../libs/region-test';

  /* 订阅事件 */
  const INIT_APPLY_LIST = 'INIT_APPLY_LIST';
  const INIT_USER_TAG_LIST = 'INIT_USER_TAG_LIST';
  const INIT_PLATFORM_LIST = 'INIT_PLATFORM_LIST';
  const INIT_CHANNEL_LIST = 'INIT_CHANNEL_LIST';
  const INIT_ADSTEMPLATE_LIST = 'INIT_ADSTEMPLATE_LIST';
  const INIT_GOMETHOD_LIST = 'INIT_GOMETHOD_LIST';
  const INIT_WAREHOUSE_LIST = 'INIT_WAREHOUSE_LIST';
  const INIT_REGION_DATA = 'INIT_REGION_DATA';
  const INIT_USPATTR_LIST = 'INIT_USPATTR_LIST';
  const INIT_USPTAG_LIST = 'INIT_USPTAG_LIST';
  const INIT_VERSION_DATA = 'INIT_VERSION_DATA';


  const INIT_APPLY_POSITION_LIST = 'INIT_APPLY_POSITION_LIST';
  const INIT_ADS_TEMPLATE_DATA = 'INIT_ADS_TEMPLATE_DATA';

  const VERSION_SUFFIX = '.xx??hh';

  /* 链接上携带的参数 */
  const Q_ID = 'id';    /* 广告ID，存在的话，证明是编辑状态 */
  const Q_IS_VISUAL = 'isVisual'; /* 存在为1的话，证明是来自己可视化 */
  const Q_ZONE_CODE = 'zoneCode';  /* Q_IS_VISUAL存在为1的才有意义，坑位的zoneCode */

  /* 记录初始化过程中的订阅事件，因为不同的编辑状态，初始化的内容可能会不同 */
  var g_init_event_list = '';

  /* 编辑时，初始化过程中，由于接口顺序的原因，有些值需要暂存 */
  var g_tmpPositionIds = null;     //运营位的ID[是后台数据]
  var g_tmpAdsTemplateData = null;  //当前的广告图模板的内容{content: data.templates.msg, isIndividual: true/false}

  var g_tmpParamObj = null;   /* 提交数据时，临时保存 */

  var g_tmpWhInfo = {};     /* 用来记录分仓对应的省份:如{VIP_NH: [province]} */
  var g_tmpLastSelectedWhs = [];  /* 用来记录上一次的分仓信息，以便和改变后的信息作比较 */

  export default {
    data() {
      return {

        bodyLoading: true,

        adsId: false,   //广告ID，若存在，证明是编辑状态
        isVisual: false,  //是否来自可视化
        zoneCode: false,  //坑位的zonecode


        /* 基本信息 */
        adsName: '',  // 广告名称

        // AD from plan
        isPlan: 0,
        planPersonalID: 0,
        loopPicFrameID: 0,

        startTime: '',    //广告的开始时间
        endTime: '',      //广告的结束时间
        defaultStartTime: '', //广告的开始默认时间:明天10点
        defaultEndTime: '',   //广告的结束默认时间:后天10点

        applyList:  [], // 申请位列表
        selectedApplys: [],

        adsPositionList: [],  /* 运营位 */
        selectedAdsPositions: [],

        adsWeight: 10,  //权重



        /* 链接与图片 */
        goMethodList: [],   // 跳转到
        selectedGoMethod: '',
        /*
        couponInfo.buttons = [{key: "left_button", placeholder, msg(label), text, required}...]
        couponInfo.couponList = [
        [{key: "id", msg: "券id", required: true, placeholder, text},
        {key: "r_id", msg: "规则id", required: false, placeholder, text},
        {key: "source", msg: "来源", required: true, placeholder, text}
        ]...]
        couponInfo.image.placeholder = '';
        couponInfo.image.isUpload = false;
        couponInfo.image.percent = 1;
        couponInfo.image.url = '';
        couponInfo.image.placeholder = '';
        couponInfo.other = info.otherButton[0]; //otherButton[{key: "isDisappearAfterGot", msg: "领券后按钮是否消失", required: true}]
        couponInfo.other.isShow = 1; // 领券后按钮是否显示
          */
        couponInfo: null,   //红包信息
        urlInfo: {          //地址信息
          separator: '',  /* 分隔符 */
          formatInfos: '', /* 规则 */
          urls: [{
            url: 'ha'
          }, {
            url: 'xxxx',
            warehouse: '',
            platform: ''
          }]
        },

        urlWarehouseList: [],
        urlPlatformList: [],

        adsTemplateList: [],    // 广告图模板
        selectedAdsTemplate: '',
        /**
          广告模板的数据
          groups:如
          var groupInfo = data[key];
            var tmpPictures = [];
            for (var key2 in groupInfo) {
              var tmpPicture = {};
              tmpPicture.resolution = key2;
              tmpPicture.size = (groupInfo[key2])[0];
              tmpPicture.ext = (groupInfo[key2])[1];
              tmpPicture.placeholder = tmpPicture.ext ? '(格式: ' + tmpPicture.ext + ')' : '';
              tmpPicture.url = '';
              tmpPicture.isUpload = false;
              tmpPicture.percent = 1;
              tmpPictures.push(tmpPicture);
            }
            group.pictures = tmpPictures;
            group.individualResolution    //只对是运营位且个性化时有用：此模块的分辨率
            group.individualPics = [{
              categoryName:"糖/盐"
              id:"269"
              isDefault:0
              picName:"1477021580"
              url:"http://b.appsimg.com/2016/12/16/8277/14818823226492.jpg"
              width:"750",
              heigth: "222"
            }];
            groups.push(group);
         **/
        adsTemplateInfo: {
          templateId: 0,    //当前广告图模板的ID
          isIndividual: false,  //是否打开个性化
          isOperation: false,   //当前的模板是否运营位
          groups: [],           //模板里面的组信息
          activeIndexs: []      //el-collapse打开哪些面板，现在是全打开
        },




        /* 投放目标 */
        newUserTypes: [{  // 新客标签
            id: 'u-1',
            name: '新客',
            children: []
          }],

        oldUserTypes: [{  // 老客标签
            id: 'u-2',
            name: '老客',
            children: []
          }],

        uspType: 0, // 人群

        //USP人群的设置内容
        serviceType: 1,  // 人群服务
        uspAttrList: [],
        selectedUspAttrs: [],
        uspTagList: [],
        selectedUspTags: [],
        isUspShow: 1,

        versionType: 2,   //版本号类型 : -1-反选,0-正选,1-选中版本以上,2-全部版本,注意，默认是2，version_type=2的时候version字段不需要传数值，传空即可
        treeVersions: [],
        versionList: [],	// 版本列表，（选择选中版本以上）
        selectedVersion: '',

        //爆光打压
        isExposeOpen: false,
        suppressType: 0,
        viewTimes: 2,
        clickTimes: 0,
        clickTimes2: 1,

        /* 更多设置 */
        warehouses: [
          // {id: "VIP_BJ", name: '北京-BJ'},
          // {id: "VIP_CD", name: '成都-CD'},
          // {id: "VIP_SH", name: '上海-SH'},
          // {id: "VIP_NH", name: '南海-NH'},
          // {id: "VIP_DA", name: '团购仓'},
          // {id: "VIP_HZ", name: '华中-HZ'}
          ],   //分仓
        selectedWarehouses: [],   //分仓

        adsTooltips: '',  //文字提示
        adsVideoUrl: '',  //视频广告URL
        adsTimes: 0,      //启动视频次数
        adsDuration: 4,   //轮播显示时长
        whiteListStr: '', //白名单

        regionData: {}, //地区数据
        selectedRegions: [],

        channelList: [],  //地区数据
        selectedChannels: [], //渠道



      };
    },

    computed: {

    },

    mounted() {
      //解析页面的状态：添加或编辑、来自可视化或普通广告
      var adsId = uri.query(Q_ID, true);
      var isVisual = uri.query(Q_IS_VISUAL, true);
      var zoneCode = uri.query(Q_ZONE_CODE, true);
      this.adsId = adsId ? adsId : false;
      this.isVisual = (isVisual == '1') ? true : false;
      this.zoneCode = this.isVisual ? zoneCode : false;

      //检查是否合法
      if (this.adsId) {
        if (!utils.isNumber(this.adsId)) {
          this.$toast({
            title: '广告ID错误.',
            type: 'warning'
          });
          return false;
        }
      } else if (this.isVisual && !this.zoneCode) {
        this.$toast({
          title: 'zoneCode为空.',
          type: 'warning'
        });
        return false;
      }

      //合法，进行初始化
      this.init();
    },
    methods: {

      init() {

        //设置日历的默认时间
        var d, defaultStr;
        d = utils.newDate(1);
        defaultStr = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate() + ' 10:00:00';
        this.defaultStartTime = new Date(defaultStr);
        d = utils.newDate(2);
        defaultStr = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate() + ' 10:00:00';
        this.defaultEndTime = new Date(defaultStr);

        this.bodyLoading = true;

        /* 监听所有的初始化事件 */
        if (this.isVisual) {

          g_init_event_list = INIT_USER_TAG_LIST
                  + ' ' + INIT_PLATFORM_LIST
                  + ' ' + INIT_CHANNEL_LIST
                  + ' ' + INIT_ADSTEMPLATE_LIST
                  + ' ' + INIT_GOMETHOD_LIST
                  + ' ' + INIT_WAREHOUSE_LIST
                  + ' ' + INIT_REGION_DATA
                  + ' ' + INIT_USPATTR_LIST
                  + ' ' + INIT_USPTAG_LIST
                  + ' ' + INIT_VERSION_DATA;

          listeners.sub(g_init_event_list, data => {
            listeners.unsub(g_init_event_list);
            if (this.adsId) { //编辑状态
              this.getAdsInfo(this.adsId);
            } else {  //新添加
              //因为是添加状态，设置地址的值跟分仓保持一致
              this.reinitSyncRegions();
            }
          });

          // this.getApplyList();
          this.getPlatformList();
          this.getUserTypeList();
          this.getChannelList();
          this.getAdsTemplateList();
          this.getGoMethodList();
          this.getWarehourseList();
          this.getRegionData();
          // this.setWarehouseRelatedRegions()

          this.getUspAttrList();
          this.getUspTagList();

          this.getVersionData();

        } else {
          g_init_event_list = INIT_APPLY_LIST
                  + ' ' + INIT_USER_TAG_LIST
                  + ' ' + INIT_PLATFORM_LIST
                  + ' ' + INIT_CHANNEL_LIST
                  + ' ' + INIT_ADSTEMPLATE_LIST
                  + ' ' + INIT_GOMETHOD_LIST
                  + ' ' + INIT_WAREHOUSE_LIST
                  + ' ' + INIT_REGION_DATA
                  + ' ' + INIT_USPATTR_LIST
                  + ' ' + INIT_USPTAG_LIST
                  + ' ' + INIT_VERSION_DATA;

          listeners.sub(g_init_event_list, data => {
            listeners.unsub(g_init_event_list);   /* 取消这个订阅 */
            if (this.adsId) { //编辑状态
              this.getAdsInfo(this.adsId);
            } else {    //新添加
              //因为是添加状态，设置地址的值跟分仓保持一致
              this.reinitSyncRegions();
            }
          });

          this.getApplyList();
          this.getPlatformList();
          this.getUserTypeList();
          this.getChannelList();
          this.getAdsTemplateList();
          this.getGoMethodList();
          this.getWarehourseList();
          this.getRegionData();
          // this.setWarehouseRelatedRegions()

          this.getUspAttrList();
          this.getUspTagList();

          this.getVersionData();

        }

      },

      //处于添加状态时，设置地址的值跟分仓保持一致
      reinitSyncRegions() {
        var selectedRegions = [];
        this.selectedWarehouses.forEach(warehouse => {
          var whProvinces = g_tmpWhInfo[warehouse];
          selectedRegions = selectedRegions.concat(whProvinces);
        });
        this.selectedRegions = selectedRegions;

        this.$nextTick(function () {
            this.bodyLoading = false;
        });
      },

      /* 取出申请位列表 */
      getApplyList() {

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getApplyTree'),
          params: {
            'appid': 1,
            'limit_channel': 1
          }
        }).then(result => {

          if (result.status == 200 && result.data) {
            var list = result.data;
            var tmpList = [];
            for (var i = 0; i < list.length; i++) {

              var selectedApplys = [];		/*  */
              var item = list[i];
              var itemId = item.chl_id;
              var children = item.children;
              var node = {'id': itemId, 'name': item.chl_name};
              var childList = [];
              for (var j = 0; j < children.length; j++) {
                var childItem = children[j];
                var childItemId = childItem['id'];
                var childNode = {'id': childItemId, 'name': childItem['apply_name']};
                childList.push(childNode);
              }

              if (childList.length > 0) {
                node['children'] = childList;
              }
              tmpList.push(node);
            }

            this.applyList = tmpList;


          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取申请位列表失败.',
              type: 'warning'
            });
            return;
          }

          listeners.pub(INIT_APPLY_LIST);

        }, result => {

          this.$toast({
            title: '获取申请位列表失败！',
            type: 'warning'
          });

          // listeners.pub(INIT_APPLY_LIST);

        });
      },

      /* 取出平台列表 */
      getPlatformList() {

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getPlatformList'),
          // params: {
          // 	'appid': 1,
          // 	'limit_channel': 1
          // }
        }).then(result => {

          // this.bodyLoading = false;

          if (result.status == 200 && result.data) {
            var data = result.data;
            var tmpList = [];
            data.forEach(item => {
              var tmpItem = {id: item.value, name: item.key};
              tmpList.push(tmpItem);
            });

            //在前面添加全部平台在前面
            var tmpItem = {id: this.joinId(tmpList, '-'), name: '全部平台'};
            tmpList.unshift(tmpItem);

            this.urlPlatformList = tmpList;


          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取平台列表失败.',
              type: 'warning'
            });
            return;
          }

          listeners.pub(INIT_PLATFORM_LIST);

        }, result => {

          this.$toast({
            title: '获取平台列表失败！',
            type: 'warning'
          });

          // listeners.pub(INIT_PLATFORM_LIST);
        });
      },

      /* 取出用户类型列表 */
      getUserTypeList() {

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getUserTypeList'),
          // params: {
          //  'appid': 1,
          //  'limit_channel': 1
          // }
        }).then(result => {


          if (result && result.data) {    /* 唉！接口返回风格不统一,服 */
            var data = result.data;

            var tmpList;

            tmpList = [];
            data.new_user.forEach(item => {
              var tmpItem = {};
              tmpItem.id = item;
              tmpItem.name = item;
              tmpList.push(tmpItem);
            });
            this.newUserTypes[0].children = tmpList;

            tmpList = [];
            data.old_user.forEach(item => {
              var tmpItem = {};
              tmpItem.id = item;
              tmpItem.name = item;
              tmpList.push(tmpItem);
            });
            this.oldUserTypes[0].children = tmpList;



          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取用户标签列表失败.',
              type: 'warning'
            });
            return;
          }

          listeners.pub(INIT_USER_TAG_LIST);

        }, result => {

          this.$toast({
            title: '获取人群标签列表失败！',
            type: 'warning'
          });

          // listeners.pub(INIT_USER_TAG_LIST);

        });
      },


      /* 取出渠道列表 */
      getChannelList() {

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getChannelList'),
          // params: {
          // 	'appid': 1,
          // 	'limit_channel': 1
          // }
        }).then(result => {

          // this.bodyLoading = false;

          if (result.status == 200 && result.data) {
            var list = result.data;
            var tmpList = [];
            list.forEach(item => {
              if (item.channel_tag) {
                tmpList.push({id: item.channel_tag, name: item.channel_name});
              }
            });
            tmpList = utils.deepCopy(tmpList);
            this.channelList = tmpList;


          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取渠道列表失败.',
              type: 'warning'
            });
            return;
          }

          listeners.pub(INIT_CHANNEL_LIST);

        }, result => {

          this.$toast({
            title: '获取渠道列表失败！',
            type: 'warning'
          });

          // listeners.pub(INIT_CHANNEL_LIST);
        });
      },

      /* 取广告图模板 */
      getAdsTemplateList() {

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getAdsTemplateList'),
          // params: {
          // 	'appid': 1,
          // 	'limit_channel': 1
          // }
        }).then(result => {

          // this.bodyLoading = false;

          if (result.status == 200 && result.data) {
            var list = result.data;
            var tmpList = [];
            list.forEach(function(item) {
              var tmpItem = {};
              tmpItem.id = item.id;
              tmpItem.name = item.name;
              tmpItem.isOperation = item.is_operation ? true : false;
              tmpList.push(tmpItem);
            });
            this.adsTemplateList = tmpList;


          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取广告图模板列表失败.',
              type: 'warning'
            });
            return;
          }

          listeners.pub(INIT_ADSTEMPLATE_LIST);

        }, result => {
          // this.bodyLoading = false;
          this.$toast({
            title: '获取广告图模板列表失败！',
            type: 'warning'
          });

          // listeners.pub(INIT_ADSTEMPLATE_LIST);

        });
      },

      /* 取跳转方式模板 */
      getGoMethodList() {

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getGoMethodList'),
          // params: {
          // 	'appid': 1,
          // 	'limit_channel': 1
          // }
        }).then(result => {

          // this.bodyLoading = false;

          if (result.status == 200 && result.data) {
            var list = result.data;
            var tmpList = [];
            list.forEach(item => {
              var tmpItem = {};
              tmpItem.id = item.key;
              if (item.key == '2') {		/* 看看是否存在默认的普通链接 */
                this.selectedGoMethod = item.key;
              }
              tmpItem.name = item.name;
              // tmpItem.separator = item.targetsep ? item.targetsep : '';
              tmpItem.separator = item.target_sep ? item.target_sep : '';

              var info = item.description;

              var urlInfo = {};
              urlInfo.separator = item.target_sep;
              urlInfo.formatInfos = item.format_info ? utils.deepCopy(item.format_info) : null;
              urlInfo.urls = [{url: ''}];   /* 加上一条默认的 */

              if (typeof info !== 'string') {
                  // tmpItem.urlInfo = null;
                  urlInfo.placeholder = '';

                  var tmpInfo = {};
                  tmpInfo.couponList = info.coupon;
                  tmpInfo.couponList.forEach(item => {
                    item.forEach(subitem => {
                      subitem.text = '';
                      subitem.placeholder = subitem.msg + '(' + (subitem.required ? '必填' : '选填') + ')';
                    });
                  });
                  tmpInfo.buttons = info.button;
                  tmpInfo.buttons.forEach(item => {
                    item.text = '';
                    item.placeholder = item.msg + '(' + (item.required ? '必填' : '选填') + ')';
                  });
                  tmpInfo.image = {};
                  tmpInfo.image.size = info.image.msg;
                  tmpInfo.image.key = info.image.key;
                  tmpInfo.image.type = info.image.type;
                  tmpInfo.image.required = info.image.required;
                  tmpInfo.image.isUpload = false;
                  tmpInfo.image.percent = 1;
                  tmpInfo.image.url = '';
                  tmpInfo.image.surl = '';
                  tmpInfo.image.placeholder = '';
                  tmpInfo.other = info.otherButton[0];
                  tmpInfo.other.isShow = 1;	/* 领券后按钮是否显示 */
                  tmpItem.couponInfo = utils.deepCopy(tmpInfo);		//是红包广告
              } else {
                // tmpItem.msg = info;
                urlInfo.placeholder = item.description;
              }
              // else {
              //   tmpItem.msg = info;

              //   var urlInfo = {};
              //   urlInfo.separator = item.target_sep;
              //   urlInfo.placeholder = item.description;
              //   urlInfo.formatInfos = item.format_info ? utils.deepCopy(item.format_info) : null;
              //   urlInfo.urls = [{url: ''}];   /* 加上一条默认的 */
              //   tmpItem.urlInfo = urlInfo;
              // }

              tmpItem.urlInfo = urlInfo;

              tmpList.push(tmpItem);
            });
            this.goMethodList = tmpList;

            this.handleGoMethodChange();

          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取跳转方式列表失败.',
              type: 'warning'
            });
            return;
          }

          listeners.pub(INIT_GOMETHOD_LIST);

        }, result => {

          this.$toast({
            title: '获取跳转方式列表失败！',
            type: 'warning'
          });
          // listeners.pub(INIT_GOMETHOD_LIST);

        });
      },

      /* 取出人群属性列表 */
      getUspAttrList() {

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getUspAttrList'),
          // params: {
          // 	'appid': 1,
          // 	'limit_channel': 1
          // }
        }).then(result => {

          if (result && result.info) {		/* 唉！接口返回风格不统一,服 */
            var list = result.info;
            var tmpList = [];
            list.forEach(item => {
              // var tmpItem = {};
              // tmpItem.id = item.classid;
              // tmpItem.name = item.property_name;
              // tmpItem.code = item.property_code;
              // tmpItem.value = item.property_value;
              // var children = [];
              if (item.prperty_value_list) {
                item.prperty_value_list.forEach(function(child) {
                  var tmpChild = {};
                  tmpChild.id = child.classid;
                  tmpChild.name = child.property_name;
                  tmpChild.code = child.property_code;
                  tmpChild.value = child.property_value;
                  tmpChild.parentName = item.property_name;
                  // children.push(tmpChild);
                  tmpList.push(tmpChild);
                });
              }
              // tmpItem.children = children;
              // tmpList.push(tmpItem);
            });
            this.uspAttrList = tmpList;


          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取人群属性列表失败.',
              type: 'warning'
            });
            return;
          }

          listeners.pub(INIT_USPATTR_LIST);

        }, result => {

          this.$toast({
            title: '获取人群属性列表失败！',
            type: 'warning'
          });

          // listeners.pub(INIT_USPATTR_LIST);

        });
      },

      /* 取出人群标签列表 */
      getUspTagList() {

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getUspTagList'),
          // params: {
          // 	'appid': 1,
          // 	'limit_channel': 1
          // }
        }).then(result => {


          if (result && result.info) {		/* 唉！接口返回风格不统一,服 */
            var list = result.info;
            var tmpList = [];
            list.forEach(item => {
              var tmpItem = {};
              tmpItem.id = item.id;
              tmpItem.name = item.name;
              tmpItem.uspExpression = item.usp_expression;
              tmpList.push(tmpItem);
            });
            this.uspTagList = tmpList;


          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取人群标签列表失败.',
              type: 'warning'
            });
            return;
          }

          listeners.pub(INIT_USPTAG_LIST);

        }, result => {

          this.$toast({
            title: '获取人群标签列表失败！',
            type: 'warning'
          });

          // listeners.pub(INIT_USPTAG_LIST);

        });
      },

      /* 取出版本信息 */
      getVersionData() {
        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getVersionData'),
          // params: {
          // 	'appid': 1,
          // 	'limit_channel': 1
          // }
        }).then(result => {

          // this.bodyLoading = false;

          if (result.status == 200 && result.data) {
            var list = result.data;
            var tmpList = [];
            list.forEach(item => {
              var tmpItem = {};
              tmpItem.id = item;
              tmpItem.name = item;
              tmpList.push(tmpItem);
            });

            tmpList.sort(editLib.sortVersion);
            // console.log(tmpList)

            var tmpTreeVersions = [];
            //已经从大到小排好序了
            var lastFirstNum = null;
            var groupVersionInfo = null;
            tmpList.forEach(item => {
              var name = item.name;
              if (name.indexOf(editLib.preVerTag) == 0) {
                name = name.substr(editLib.preVerTag.length);
              }
              var firstVerNumStr = name.split('.')[0];
              if (firstVerNumStr != lastFirstNum) {	/* 新的版本类型开始的 */
                if (groupVersionInfo) {		/* 保存上一次的组信息 */
                  tmpTreeVersions.push(groupVersionInfo);
                }
                groupVersionInfo = {};
                groupVersionInfo.id = firstVerNumStr + VERSION_SUFFIX;
                groupVersionInfo.name = firstVerNumStr + '.xx版本';
                var child = {
                  id: item.id,
                  name: item.name
                }
                groupVersionInfo.children = [child];
                lastFirstNum = firstVerNumStr;
              } else {
                var child = {
                  id: item.id,
                  name: item.name
                }
                groupVersionInfo.children.push(child);
              }
            });
            if (groupVersionInfo) {		/* 保存上一次的组信息(最后一个) */
              tmpTreeVersions.push(groupVersionInfo);
            }


            this.versionList = tmpList;
            this.treeVersions = tmpTreeVersions;


          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取版本列表失败.',
              type: 'warning'
            });
            return;
          }

          listeners.pub(INIT_VERSION_DATA);

        }, result => {

          this.$toast({
            title: '获取版本列表失败！',
            type: 'warning'
          });

          // listeners.pub(INIT_VERSION_DATA);

        });
      },


      /* 取分仓列表 */
      getWarehourseList() {

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getWarehouseList'),
          // params: {
          //  'appid': 1,
          //  'limit_channel': 1
          // }
        }).then(result => {

          if (result.status == 200 && result.data) {

            var data = result.data;
            var tmpWarehouselist = [];
            data.forEach(item => {
              var tmpWarehouse = {'id': item.key, 'name': item.name};
              tmpWarehouselist.push(tmpWarehouse);

              g_tmpWhInfo[item.key] = utils.deepCopy(item.province);    //保存起来，分仓切换时用

            });
            this.warehouses = tmpWarehouselist;

            //设置一些默认值
            if (!this.adsId) {
              var idStr = this.joinId(this.warehouses, ',');
              this.selectedWarehouses = idStr.split(',');
              g_tmpLastSelectedWhs = utils.deepCopy(this.selectedWarehouses);
            }

            var urlWarehouseList = utils.deepCopy(this.warehouses);
            //添加所有分仓
            var idStr = this.joinId(this.warehouses, '-');
            urlWarehouseList.unshift({id: idStr, name: '所有分仓'});

            this.urlWarehouseList = urlWarehouseList;


          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取分仓列表失败.',
              type: 'warning'
            });
            return;
          }

          listeners.pub(INIT_WAREHOUSE_LIST);

        }, result => {

          this.$toast({
            title: '获取分仓列表失败！',
            type: 'warning'
          });

          // listeners.pub(INIT_WAREHOUSE_LIST);

        });
      },

      /* 取地区数据 */
      getRegionData() {

        // setTimeout(() => {
        //   listeners.pub(INIT_REGION_DATA);
        //   this.regionData = regionData;
        // }, 100);
        // return;

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getRegionData'),
          // params: {
          // 	'appid': 1,
          // 	'limit_channel': 1
          // }
        }).then(result => {

          if (result.code == 200 && result.data) {

            if (result.data.province && result.data.city && result.data.country) {
              this.regionData = result.data;
            }

          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取地区数据失败.',
              type: 'warning'
            });
            return;
          }

          listeners.pub(INIT_REGION_DATA);

        }, result => {

          this.$toast({
            title: '获取地区数据失败！',
            type: 'warning'
          });

          // listeners.pub(INIT_REGION_DATA);

        });
      },

      // async setWarehouseRelatedRegions () {
      //   const result = await this.fetchWarehouseAndRegionsMap()
      //   const status = result.status
      //   const data = result.data
      //   if (status === 200 && data && data.length > 0) {
      //     let map = {}
      //     data.forEach(item => {
      //       Object.defineProperty(map, item.key, {
      //         configurable: true,
      //         enumerable: true,
      //         writable: true,
      //         value: item.province
      //       })
      //     })
      //     // TODO
      //     console.log(map)
      //   } else {
      //     this.$toast({
      //       title: result.msg ? result.msg : '获取地区数据失败.',
      //       type: 'warning'
      //     });
      //   }
      // },

      // async fetchWarehouseAndRegionsMap () {
      //   return await this.$API({
      //     method: 'get',
      //     url: this.$URL.getUrl('warehouseAndRegionsMap')
      //   })
      // },

      /* 根据申请位取广告运营位 */
      getAdsPostionList(applyId, fromInit) {
        if (fromInit !== true) {
          this.bodyLoading = true;
        }

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getAdsPostionList'),
          params: {
            'id': applyId
          }
        }).then(result => {

          if (result.status == 200 && result.data) {
            var list = result.data;
            var tmpList = [];
            list.forEach(function(item) {
              var tmpItem = {};
              tmpItem.id = item.id;
              tmpItem.name = item.zonename;
              tmpList.push(tmpItem);
            });
            this.adsPositionList = tmpList;


          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取广告位运营列表失败.',
              type: 'warning'
            });
            return;
          }

          if (fromInit !== true) {
            this.bodyLoading = false;
          } else {
            if (g_tmpPositionIds) {    //把广告的运营位信息匹配运营位列表
              this.selectedAdsPositions = g_tmpPositionIds;
              g_tmpPositionIds = null;
            }
            listeners.pub(INIT_APPLY_POSITION_LIST);
          }

        }, result => {

          this.$toast({
            title: '获取广告位运营列表失败！',
            type: 'warning'
          });

        });
      },


      /* 申请位改变 */
      handleApplyChange(selected, fromInit) {

        if (this.selectedApplys && this.selectedApplys.length == 2) {

          var applyId = this.selectedApplys[1];
          /* 取出申请位列表 */
          this.getAdsPostionList(applyId, fromInit);
        }
      },

      /* 跳转地址改变 */
      handleGoMethodChange() {
        if (this.selectedGoMethod) {
          var info = this.parseUrlInfo(this.selectedGoMethod);
          this.urlInfo = info.urlInfo;
          this.couponInfo = info.couponInfo ? info.couponInfo : null
        }
      },

      /* 广告图模板改变 */
      handleAdsTemplateChange(selected, fromInit) {

        if (this.selectedAdsTemplate) {
          this.getAdsTemplateForId(this.selectedAdsTemplate, fromInit);
        }
      },

      /* 分仓改变时 */
      handleWhChange() {
        // console.log(this.selectedRegions)
        var tmpLastSelectedWhs = g_tmpLastSelectedWhs;
        var addWhs = [];
        var removeWhs = [];
        this.warehouses.forEach(whInfo => {
          var hasLast = tmpLastSelectedWhs.includes(whInfo.id);
          var hasNow = this.selectedWarehouses.includes(whInfo.id);
          if (!hasLast && hasNow) {   //之前没有，现在有，添加的
            addWhs.push(whInfo.id);
          } else if (hasLast && !hasNow){   //之前有，现在没有，去除的
            removeWhs.push(whInfo.id);
          } else {  //同时有，同时没有，不用处理
            //do nothing
          }
        });

        //重新设置地区的选择
        //添加的省份
        addWhs.forEach(warehouseId => {
          var whProvinces = g_tmpWhInfo[warehouseId];
          // console.log('addWhs', whProvinces)
          whProvinces.forEach(provinceId => {
            var hasProvinceId = false;
            for (var i = 0; i < this.selectedRegions.length; i++) {
              var regionId = this.selectedRegions[i];
              if (provinceId == regionId) {
                hasProvinceId = true;
                break;  //退出，因为有省份了，省级以下在组件里是不存在的
              } else if (regionId.indexOf(provinceId + '-') == 0) {  //是省以下，为什么要加-；因为怕省份的id为100和1000的情况出现,
                this.selectedRegions.splice(i, 1);
                i--;
              }
            }
            if (!hasProvinceId) {
              this.selectedRegions.push(provinceId);
            }
          });
        });

        //删除的省份
        removeWhs.forEach(warehouseId => {
          var whProvinces = g_tmpWhInfo[warehouseId];
          // console.log('removeWhs', whProvinces)
          whProvinces.forEach(provinceId => {
            for (var i = 0; i < this.selectedRegions.length; i++) {
              var regionId = this.selectedRegions[i];
              if (provinceId == regionId || regionId.indexOf(provinceId + '-') == 0) {
                this.selectedRegions.splice(i, 1);
              }
            }
          });
        });

        g_tmpLastSelectedWhs = utils.deepCopy(this.selectedWarehouses);
        // console.log('this.selectedRegions',this.selectedRegions)

      },

      /* 取广告图模板的具体信息 */
      getAdsTemplateForId(id, fromInit) {

        if (fromInit !== true) {
          this.bodyLoading = true;
        }

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getAdsTemplateForId'),
          params: {
            'id': id
          }
        }).then(result => {

          var tmpAdsTemplateInfo = {};

          if (result.status == 200 && result.msg) {

            var groups = [];
            var data = result.msg;
            var tmpActiveIndexs = [];
            var tmpActiveIndex = 0;
            for (var key in data) {

              var group = {};
              group.name = key;
              group.id = tmpActiveIndex;

              var groupInfo = data[key];
              var tmpPictures = [];
              for (var key2 in groupInfo) {
                var tmpPicture = {};
                tmpPicture.resolution = key2;
                tmpPicture.size = (groupInfo[key2])[0];
                tmpPicture.ext = (groupInfo[key2])[1];
                tmpPicture.placeholder = tmpPicture.ext ? '(格式: ' + tmpPicture.ext + ')' : '';
                tmpPicture.url = '';
                tmpPicture.surl = '';
                tmpPicture.isUpload = false;
                tmpPicture.percent = 1;
                tmpPictures.push(tmpPicture);
              }
              group.pictures = tmpPictures;
              group.individualResolution = (tmpPictures[0] ? tmpPictures[0].resolution : '');
              group.individualPics = [];
              groups.push(group);

              tmpActiveIndexs.push(tmpActiveIndex);
              tmpActiveIndex++;
            }

            tmpAdsTemplateInfo.groups = groups;
            tmpAdsTemplateInfo.templateId = id;
            tmpAdsTemplateInfo.isOperation = this.isSelectedOperation();
            tmpAdsTemplateInfo.activeIndexs = tmpActiveIndexs;
            tmpAdsTemplateInfo.isIndividual = false;

          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取广告图模板失败.',
              type: 'warning'
            });
            return;
          }

          if (fromInit !== true) {
            this.adsTemplateInfo = tmpAdsTemplateInfo;
            this.bodyLoading = false;
          } else {
            if (g_tmpAdsTemplateData) {   //把广告图模板的内容匹配到所选择的广告图模板
              if (g_tmpAdsTemplateData.isIndividual) {  /* 是个性化 */
                var curGroupInfo = g_tmpAdsTemplateData.content;
                tmpAdsTemplateInfo.isIndividual = true;
                //把数据填入个性化模板里面：为什么这样写，看返回数据吧
                tmpAdsTemplateInfo.groups.forEach(group => {
                  // var groupName = group.name;
                  var individualResolution = group.individualResolution;
                  /* 为什么可以用individualResolution来匹配，因为每个icon的图片的尺寸ID是不同的，这个跟建表有关，每个组的尺寸是互不干扰 */

                  var curPictureInfos = curGroupInfo[individualResolution];
                  // console.log(curGroupInfo, individualResolution, curPictureInfos)
                  for (var id in curPictureInfos){
                    var picture = curPictureInfos[id];
                    var individualPic = {};
                    individualPic.categoryName = picture.category_name;
                    individualPic.id = id;
                    individualPic.isDefault = parseInt(picture.is_default);
                    individualPic.picName = picture.pic_name;
                    individualPic.url = picture.pic;
                    individualPic.width = picture.width;
                    individualPic.height = picture.height;
                    group.individualPics.push(individualPic);
                  };
                });
              } else {  /* 不是个性化 */
                tmpAdsTemplateInfo.isIndividual = false;
                //把数据填入图片模板里面
                var curGroups = g_tmpAdsTemplateData.content;
                tmpAdsTemplateInfo.groups.forEach(group => {
                  var groupName = group.name;
                  group.pictures.forEach(picture => {
                    var resolution = picture.resolution;
                    var curPictureInfos = curGroups[groupName][resolution];
                    picture.url = curPictureInfos[2];
                    picture.surl = curPictureInfos[3];
                  });
                });
              }
              g_tmpAdsTemplateData = null;
            }
            this.adsTemplateInfo = tmpAdsTemplateInfo;
            listeners.pub(INIT_ADS_TEMPLATE_DATA);
          }

        }, result => {
          this.$toast({
            title: '获取广告图模板失败！',
            type: 'warning'
          });
          return;
        });
      },

      getAdsInfo(id) {

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getAdsInfo'),
          params: {
            'banner_id': id
          }
        }).then(result => {

          /* 具体返回值见：http://wiki.corp.vipshop.com/pages/viewpage.action?pageId=388924505 */
          if (result.status == 200 && result.data) {
            var data = result.data;
            // plan ad
            this.isPlan = +data.is_plan;
            this.planPersonalID = +data.plan_personal_id;
            this.loopPicFrameID = +data.loop_pic_frame_id;

            this.adsName = data.name;
            this.startTime = new Date(parseInt(data.starttime) * 1000);
            this.endTime = new Date(parseInt(data.endtime) * 1000);

            g_init_event_list = '';
            if (!this.isVisual) {

              g_init_event_list += INIT_APPLY_POSITION_LIST;

              var curApplyId = data.application_id;
              var curSelectedApplys = this.checkApplyId(curApplyId);
              // console.log('curSelectedApplys', curSelectedApplys)
              if (curSelectedApplys) {
                this.selectedApplys = curSelectedApplys;
                var zoneids = [];
                var zonesData = data.zonesData;
                if (zonesData) {
                  zonesData.forEach(zoneObj => {
                    zoneids.push(zoneObj.zone_id);
                  });
                }
                g_tmpPositionIds = zoneids;    //临时记录这个运营位，当运营位列表取回时匹配
              } else {
                //报错吧
                this.$toast({
                  title: '获取广告信息失败，申请位的信息不一致辞！',
                  type: 'warning'
                });
                return false;
              }
            }

            this.adsWeight = data.weight;

            this.selectedGoMethod = data.gomethod;
            var info = this.parseUrlInfo(this.selectedGoMethod);
            if (info.couponInfo) {   // 检查是红包
              var couponInfo = info.couponInfo;
              var curCouponInfo = data.content;
              //模板已取出来,把数据塞进模板
              var buttons = couponInfo.buttons;
              var curButtons = curCouponInfo.button;
              buttons.forEach((button, index) => {
                button.text = curButtons[button.key];
              });

              var couponList = couponInfo.couponList;
              var curCoupons = curCouponInfo.coupon;
              curCoupons.forEach((coupons, index) => {
                var inputs = couponList[index];
                if (!inputs) {
                  inputs = utils.deepCopy(couponList[0]);
                }
                inputs.forEach(input => {
                  input.text = coupons[input.key];
                });
              });

              couponInfo.image.url = curCouponInfo.image;
              couponInfo.other.isShow = curCouponInfo[couponInfo.other.key] ? 1 : 0;

              this.couponInfo = couponInfo;

            }

            var curAdsLinkData = data.adLinkData[0];
            var urlInfo = info.urlInfo;   /* url模板 */
            var urls = urlInfo.urls;

            var defaultUrl = urls[0];
            if (!defaultUrl) {
              defaultUrl = {'url': curAdsLinkData.adlink};
              urls.push(defaultUrl);
            } else {
              defaultUrl.url = curAdsLinkData.adlink;
            }
            this.urlPlatformList.forEach( (platform, index) => {
              if (index > 0) {  /* 因为第一个是全部平台 */
                var curPlatformInfos = curAdsLinkData[platform.id + '_link'];
                if (curPlatformInfos) { /* 有地址信息 */
                  curPlatformInfos.forEach(curPlatformInfo => {
                    var whs = curPlatformInfo.wh.split(',');
                    if (this.haSameAllWh(whs)) {
                      // var wh = (this.urlWarehouseList[0]).id; //把这个ID取出来，重赋值，为了兼容旧的垃圾
                      var url = {'url': curPlatformInfo.adlink, 'platform': platform.id, 'warehouse': whs.join('-')};
                      urls.push(url);
                    } else {  /* 拆开，因为旧的可能存在两个或以上的分仓，新的系统没这样的选项 */
                      whs.forEach(wh => {
                        var url = {'url': curPlatformInfo.adlink, 'platform': platform.id, 'warehouse': wh};
                        urls.push(url);
                      });
                    }
                  });
                }
              }
            });
            this.urlInfo = urlInfo;

            this.selectedAdsTemplate = data.template_id;
            //插入模板信息
            g_init_event_list += (g_init_event_list ? (' ' + INIT_ADS_TEMPLATE_DATA) : INIT_ADS_TEMPLATE_DATA);
            var content = (data.is_pic_category != '1' ? data.templates.msg : data.pic_category);
            var isIndividual = (data.is_pic_category == '1' ? true : false);
            g_tmpAdsTemplateData = {'content': content, 'isIndividual': isIndividual};
            if ((!this.isSelectedOperation()) && g_tmpAdsTemplateData.isIndividual) {   /* 数据有误:不是运营位，但又返回个性化的数据 */
              this.$toast({
                title: '获取广告的数据有误：不是运营位，但返回个性化数据.',
                type: 'warning'
              });
              return;
            }

            //新老客
            var userTypes = data.tag.split(',');   /* 包含新老客 */
            var newUserTypeList = this.newUserTypes[0].children;
            var oldUserTypeList = this.oldUserTypes[0].children;
            var selectedNewUsers = [];
            var selectedOldUsers = [];
            userTypes.forEach(item => {
              if (editLib.isRightUserType(newUserTypeList, item)) {
                selectedNewUsers.push(item);
              } else if (editLib.isRightUserType(oldUserTypeList, item)) {
                selectedOldUsers.push(item);
              }
            });

            // console.log('selectedNewUsers, selectedOldUsers', selectedNewUsers, selectedOldUsers);
            if (selectedNewUsers.length > 0) {
              this.$refs.newUserTypeTree.setCheckedKeys(selectedNewUsers);
            }
            if (selectedOldUsers.length > 0) {
              this.$refs.oldUserTypeTree.setCheckedKeys(selectedOldUsers);
            }


            //人群数据:为什么这样判断，我也不知道
            if ( (data.usp_group || data.usp_property) && data.always_display != '') {   //USP人群
              this.uspType = 1;
              this.selectedUspAttrs = data.usp_property ? data.usp_property.split(',') : [];
              this.selectedUspTags = data.usp_group ? data.usp_group.split(',') : [];
              this.isUspShow = data.always_display && parseInt(data.always_display) ? 1 : 0;
            } else if ((data.is_custom_finance != '' && data.is_custom_finance != '0')
                  || (data.is_pmc != '' && data.is_pmc != '0')
                  || (data.is_freeshipping != '' && data.is_freeshipping != '0')) {  //其它人群

              this.uspType = -1;

              if (data.is_custom_finance != '' && data.is_custom_finance != '0') {
                this.serviceType = 1;
              }

              if (data.is_pmc != '' && data.is_pmc != '0') {
                this.serviceType = 2;
              }

              if (data.is_freeshipping != '' && data.is_freeshipping != '0') {
                this.serviceType = 3;
              }

            } else {  //全部人群
              this.uspType = 0;
            }


            //版本号
            var versionType = parseInt(data.version_type);
            switch(versionType) {

              case -1:   //排除版本
              case 0:   //选中版本
                this.$nextTick(function () {   //或者用 this.$nextTick
                  this.$refs.versionTree.setCheckedKeys(data.version.split(','));
                })
                break;

              case 1:   //版本以上
                this.selectedVersion = (data.version.split(','))[0];
                break;

              case 2:   //全部版本
              default:
                versionType = 2;
                break;
            }
            this.versionType = versionType;


            //曝光打压
            if (data.exposeData && data.exposeData.expose_config_open == 1) {   //开启
              this.isExposeOpen = true;
              var exposeData = data.exposeData.expose_data;
              if (exposeData.is_open_expose == "1") { //开启曝光量的条件
                this.suppressType = 0;
                this.viewTimes = exposeData.expose_cond;
                this.clickTimes = exposeData.click_cond;
              } else {
                this.suppressType = 1;
                this.clickTimes2 = exposeData.click_cond;
              }
            } else {
              this.isExposeOpen = false;
            }

            //分仓
            this.selectedWarehouses = data.warehouse.split(',');
            g_tmpLastSelectedWhs = utils.deepCopy(this.selectedWarehouses);

            this.adsTooltips = data.pictitle;
            this.adsVideoUrl = data.public_field;
            this.adsTimes = parseInt(data.shownum);
            this.adsDuration = parseInt(data.showtime);
            this.whiteListStr = data.midwhitelist;

            this.selectedRegions = data.oxo_district ? data.oxo_district.split(',') : [];

            this.selectedChannels = data.channels ? data.channels.split(',') : [];


            //进一步初始化
            listeners.sub(g_init_event_list, data => {
              listeners.unsub(g_init_event_list);
              this.$nextTick(function () {   //或者用 this.$nextTick
                this.bodyLoading = false;
              });
            });
            if (!this.isVisual) {
              this.handleApplyChange(this.selectedApplys,true);
            }
            this.handleAdsTemplateChange(this.selectedAdsTemplate, true);


          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取广告信息失败.',
              type: 'warning'
            });
            return;
          }

          // this.bodyLoading = false;

        }, result => {

          this.$toast({
            title: '获取广告信息失败！',
            type: 'warning'
          });

          // this.bodyLoading = false;
        });
      },

      saveSettings() {

        var paramObj = {};

        //基本信息设置
        var adsName = utils.trim(this.adsName);
        if (!adsName) {
          this.$toast({
            title: '请输入广告名称！',
            type: 'warning'
          });
          return;
        }
        paramObj.name = adsName;

        var startTime = this.startTime;
        if (!startTime) {
          this.$toast({
            title: '请选择广告名称的开始时间！',
            type: 'warning'
          });
          return;
        }
        var endTime = this.endTime;
        if (!endTime) {
          this.$toast({
            title: '请选择广告名称的结束时间！',
            type: 'warning'
          });
          return;
        }
        if (startTime.getTime() >= endTime.getTime()) {
          this.$toast({
            title: '广告名称的结束时间要大于开始时间！',
            type: 'warning'
          });
          return;
        }
        if (endTime.getTime() - startTime.getTime() > (180 * 24 * 3600 * 1000)) { // 180天
          this.$toast({
            title: '广告名称的结束时间不能大于开始时间180天！',
            type: 'warning'
          });
          return;
        }
        paramObj.starttime = utils.strDate(startTime);
        paramObj.endtime = utils.strDate(endTime);

        if (!this.isVisual) {

          if (this.selectedApplys.length < 1) {
            this.$toast({
              title: '请选择申请位！',
              type: 'warning'
            });
            return;
          }
          paramObj.application_id = this.selectedApplys[1];

          if (this.selectedAdsPositions.length <= 0) {
            this.$toast({
              title: '请选择运营位！',
              type: 'warning'
            });
            return;
          }
          paramObj.zoneids = this.selectedAdsPositions.join(',');
        }

        if (/\./.test(this.adsWeight + '')) {
          this.$toast({
            title: '权重值只支持整数！',
            type: 'warning'
          });
          return;
        }
        paramObj.weight = this.adsWeight;


        //跳转链接设置
        if (!this.selectedGoMethod) {
          this.$toast({
            title: '请选择跳转类型！',
            type: 'warning'
          });
          return;
        }
        paramObj.gomethod = this.selectedGoMethod;

        var info = this.parseUrlInfo(this.selectedGoMethod);
        if (info.couponInfo) {
          var checkResult = editLib.checkAdsCoupon(this.couponInfo);
          if (checkResult.error) {
            this.$toast({
              title: checkResult.errorText,
              type: 'warning'
            });
            return;
          }
          utils.extend(paramObj, editLib.constructAdsCoupon(this.couponInfo));
        }

        var checkResult = editLib.checkAdsUrl(this.urlInfo);
        if (checkResult.error) {
          this.$toast({
            title: checkResult.errorText,
            type: 'warning'
          });
          return;
        }
        utils.extend(paramObj, editLib.constructAdsUrl(this.urlInfo));



        //广告图模板设置
        if (!this.selectedAdsTemplate) {
          this.$toast({
            title: '请选择广告图模板！',
            type: 'warning'
          });
          return;
        }
        paramObj.template_id = this.selectedAdsTemplate;

        var checkResult = editLib.checkAdsTemplate(this.adsTemplateInfo);
        if (checkResult.error) {
          if (checkResult.error) {
            this.$toast({
              title: checkResult.errorText,
              type: 'warning'
            });
            return;
          }
        }
        if (this.adsTemplateInfo.isIndividual) {
          paramObj.is_pic_category = '1';
          utils.extend(paramObj, editLib.constructIndividualPic(this.adsTemplateInfo));
        } else {
          paramObj.is_pic_category = '0';
          utils.extend(paramObj, editLib.constructTemplatePic(this.adsTemplateInfo));
        }


        //新老客设置
        var newTags = this.$refs.newUserTypeTree.getCheckedKeys();
        var oldTags = this.$refs.oldUserTypeTree.getCheckedKeys();
        var tags = [];
        newTags.concat(oldTags).forEach(tag => {
          if (tag != 'u-1' && tag != 'u-2') {
            tags.push(tag);
          }
        });
        paramObj.tag = tags;

        //人群设置:为什么这样判断，我也不知道
        paramObj.usp_property = '';
        paramObj.usp_group = '';
        paramObj.always_display = '';
        paramObj.is_custom_finance = '';
        paramObj.is_pmc = '';
        paramObj.is_freeshipping = '';

        if (this.uspType == 1) {   //USP人群
          if (this.selectedUspAttrs.length <= 0 && this.selectedUspTags.length <= 0) {
            this.$toast({
              title: '人群属性和人群标签不能同时为空！',
              type: 'warning'
            });
            return;
          }

          paramObj.usp_property = this.selectedUspAttrs.join(',');
          paramObj.usp_group = this.selectedUspTags.join(',');
          paramObj.always_display = this.isUspShow ? '1' : '0';

        } else if (this.uspType == -1) {  //其它人群

          if (this.serviceType == 1) {
            paramObj.is_custom_finance = '1';
          }

          if (this.serviceType == 2) {
            paramObj.is_pmc = '1';
          }

          if (this.serviceType == 3) {
            paramObj.is_freeshipping = '1';
          }

        } else {  //全部人群this.uspType == 0;
          //上面已经写成默认值了，do nothing
        }

        //版本号设置
        paramObj.version_type = this.versionType + '';
        if (this.versionType == 2) {  //全部版本
          paramObj.version = '';
        } else if (this.versionType == 1) { //xx版本以上
          if (!this.selectedVersion) {
            this.$toast({
              title: '请选择版本！',
              type: 'warning'
            });
            return;
          }
          paramObj.version = this.selectedVersion;
        } else {  //选中的版本或反选
          var curVersions = this.$refs.versionTree.getCheckedKeys();
          var versions = [];
          curVersions.forEach(version => {
            var lastIndex = version.lastIndexOf(VERSION_SUFFIX);
            if ( (lastIndex < 0) || (lastIndex !== (version.length - VERSION_SUFFIX.length)) ) {   //不是groupname
              versions.push(version);
            }
          });
          if (versions.length <= 0) {
            this.$toast({
              title: '请选择版本！',
              type: 'warning'
            });
            return;
          }
          paramObj.version = versions.join(',');
        }

        //曝光打压设置
        if (this.isExposeOpen) {    //后台需要这样传，我也无语
          paramObj.expose_config_open = '1';
          if (this.suppressType == 0) { //曝光打压
            paramObj.is_open_expose = '1';
            paramObj.is_open_click = '1';
            paramObj.expose_operator = '>=';
            paramObj.click_operator = '<=';
            paramObj.expose_cond = this.viewTimes;
            paramObj.click_cond = this.clickTimes;
          } else {  //点击打压
            paramObj.is_open_expose = '0';
            paramObj.is_open_click = '1';
            paramObj.expose_operator = '>=';
            paramObj.click_operator = '>=';
            paramObj.expose_cond = this.viewTimes;
            paramObj.click_cond = this.clickTimes2;
          }
        } else {
          paramObj.expose_config_open = '0';
          paramObj.is_open_expose = '0';
          paramObj.is_open_click = '0';
          paramObj.expose_operator = '>=';
          paramObj.click_operator = '<=';
          paramObj.expose_cond = this.viewTimes;
          paramObj.click_cond = this.clickTimes;
        }

        //更多设置
        paramObj.warehouse = this.selectedWarehouses;
        paramObj.pictitle = this.adsTooltips;
        paramObj.public_field = this.adsVideoUrl;
        paramObj.shownum = this.adsTimes;
        paramObj.showtime = this.adsDuration;
        paramObj.midwhitelist = this.whiteListStr;
        paramObj.oxo_district = this.selectedRegions;
        paramObj.channels = this.selectedChannels.join(',');


        if (this.adsId) {
          paramObj.id = this.adsId;
          paramObj.is_plan = this.isPlan;
        }
        paramObj.is_visual = this.isVisual ? '1' : '';
        paramObj.zonecode = this.isVisual && this.zoneCode ? this.zoneCode : '';
        paramObj.app_name = '1';

        // console.log('paramObj-----------------------', paramObj);
        // return;
        //保存数据
        g_tmpParamObj = paramObj;
        this.checkZoneAd();
      },

      checkZoneAd() {

        this.bodyLoading = true;
        this.$API({
          method: 'get',
          url: this.$URL.getUrl('checkZoneAd'),
          params: {
           'application_id': g_tmpParamObj.application_id,
           'starttime': g_tmpParamObj.starttime,
           'endtime': g_tmpParamObj.endtime,
           'bannerId': g_tmpParamObj.id ? g_tmpParamObj.id : ''
          }
        }).then(result => {
          if (result.status == 200) {
            if(result.result == 0){
                this.submit();
              }else{
                this.$confirm('该申请位帧数已满是否继续投放?', '提示', {
                  confirmButtonText: '继续',
                  cancelButtonText: '取消',
                  type: 'warning'
                }).then(() => {
                  this.submit();
                }).catch(() => {
                  g_tmpParamObj = null;
                });
              }
          } else {
            this.$toast({
              title: result.msg ? result.msg : '检查申请位帧数失败,无法保存.',
              type: 'warning'
            });
          }
          this.bodyLoading = false;

        }, result => {

          this.$toast({
            title: '检查申请位帧数失败,无法保存！',
            type: 'warning'
          });
          this.bodyLoading = false;

        });
      },

      submit() {

        this.bodyLoading = true;
        var paramObj = g_tmpParamObj;
        this.$API({
          method: 'post',
          url: this.$URL.getUrl('saveAdsInfo'),
          isFormData: true,
          data: paramObj
        }).then(result => {

          if (result.status == 200) {

            this.$toast({
              title: '保存成功.',
              type: 'success'
            });

            //统一状态数据
            if (!this.adsId) {
              this.adsId = result.id;
            }

          } else {
            this.$toast({
              title: result.msg ? result.msg : '保存失败.',
              type: 'warning'
            });
          }

          this.bodyLoading = false;

        }, result => {

          this.$toast({
            title: '保存失败！',
            type: 'warning'
          });

          this.bodyLoading = false;

        });
        g_tmpParamObj = null;
      },

      parseUrlInfo(methodId) {
        let tmpMethodInfo = {};
        for (var i = 0; i < this.goMethodList.length; i++) {
          var item = this.goMethodList[i];
          if (item.id == methodId) {
            tmpMethodInfo.couponInfo = item.couponInfo ? utils.deepCopy(item.couponInfo) : null
            tmpMethodInfo.urlInfo = utils.deepCopy(item.urlInfo)
          }

        }
        return tmpMethodInfo;
      },

      joinId(values, seperator) {
        seperator = seperator ? seperator : ',';
        var idStr = '';
        values.forEach(value => {
          idStr += seperator + value.id;
        });
        if (idStr) {
          return idStr.substr(seperator.length);
        } else {
          return '';
        }
      },

      /* 是否是所有的分仓 */
      haSameAllWh(whs) {
        if (whs.length == this.warehouses.length) {
          for (var i = 0; i < whs.length; i++) {
            var warehouse = this.warehouses[i];
            if (!whs.includes(warehouse.id)) {
              return false;
            }
          }
          return true;
        } else {
          return false;
        }
      },

      /* 检查这个申请位的ID是否存在，存在的话返回[父频道ID，申请位ID] */
      checkApplyId(id) {
        var childId = false;
        var parentId = false;
        for (var i = 0; i < this.applyList.length; i++) {
          var parent = this.applyList[i];
          parentId = parent.id;
          for (var j = 0; j < parent.children.length; j++) {
            var child = parent.children[j];
            if (child.id == id) {
              childId = id;
              break;
            }
          }
          if (childId) {
            break;
          }
        }

        if (childId) {
          return [parentId, childId];
        } else {
          return false;
        }
      },

      isSelectedOperation() {   //广告图模块是否选择了运营位
        for (var i = 0; i < this.adsTemplateList.length; i++) {
          var item = this.adsTemplateList[i];
          if (item.id == this.selectedAdsTemplate) {
            return item.isOperation;
            break;
          }
        }
        return false;
      },

      clickView() {
        var url = utils.trim(this.adsVideoUrl);
        if (utils.isUri(url)) {
          window.open(url, '_blank');
        } else {
          this.$toast({
            title: '视频广告URL不正确，不能打开！',
            type: 'warning'
          });
        }
      },

      goBack() {
        return;
        window.history.go(-1);
      }
    },
    components: {
      region,
      adsUrl,
      adsCoupon,
      adsTemplate,
    }
  };

</script>

<style lang="scss">

  @import "../../../static/styles/_mixin_base.scss";

  .ads-edit-box {
    .source-box {
      position: relative;
      height: 0px;
      z-index: 1000;
      margin: 20px 50px 0 auto;
      padding: 0 0 0 180px;
      color: #606266;

      .inner {
        position: relative;
        margin-right: auto;
        width: 90%;
        max-width: 700px;
      }

      .source {
        position: absolute;
        right: -20px;
        top: -28px;
        z-index: 1000;
      }
    }

    .base-panel {
      width: 1000px;
      margin: 0 auto;
      margin-top: 30px;
      padding-bottom: 20px;
    }

    .base-panel:first-child {
      margin-top: 0;
      padding-bottom: 0;
    }


    .icon-right:before {
      width: 36px;
      height: 36px;
      font-size: 20px;
      line-height: 36px;
      color: #13ce66;
    }

    .prompt-txt {
      margin-top: 5px;
      color: #bbb;
      b {
        color: #909399;
      }
    }

    .title {
      margin: 20px auto 0 auto;
      border-left: 4px solid #666;
      padding-left: 10px;
      text-align: left;
      line-height: 27px;
      font-size: 24px;
      font-weight: normal;
      color: #666;

      .title-inner {
        position: relative;
        margin-right: 50px;
      }

      .title-txt {
        display: inline-block;
        vertical-align: middle;
      }

      .title-time {
        display: inline-block;
        vertical-align: middle;
        background-color: #13CE66;
        color: #fff;
        border-radius: 3px;
        margin-left: 20px;
        padding: 0 10px;
        font-size: 13px;
        line-height: 21px;
      }

      .title-btn-box {
        position: absolute;
        line-height: normal;
        vertical-align: top;
        right: 5px;
        top: -3px;
      }
    }


    .settings-row {
      position: relative;
      margin: 20px 50px 0 auto;
      padding: 0 0 0 180px;
    }


    .settings-wrap {
      .settings-row {
        margin-top: 20px;
      }

      .settings-prompt-row {
        margin-top: 10px;
      }


      .settings-row-txt {
        margin-top: 8px;
      }

      .settings-row-txt2 {
        margin-top: 0px;

        .cnt-box {
          margin-top: 0;
        }
      }
    }

    .settings-label {
      position: absolute;
      left: 0;
      top: 0;
      width: 160px;
      line-height: 30px;
      text-align: right;
      white-space: nowrap;
      color: #666;
    }

    .datetime {
      width: 100%;
    }

    .txt-to {
      /*margin-left: 15px;
      margin-right: 15px;*/
      text-align: center;
      line-height: 32px;
    }


    .settings-cnt {
      color: #606266;
    }

    .star {
      color: #fd2b2b;
    }

    .cnt-box {
      position: relative;
      margin-top: 5px;
      margin-right: auto;
      width: 90%;
      max-width: 700px;
      line-height: 24px;

      .clear {
        position: absolute;
        right: 10px;
        top: 9px;
        color: #bfcbd9;
        font-size: 14px;
        line-height: 14px;
        vertical-align: middle;
        cursor: pointer;
        user-select: none;
        -webkit-user-select: none;
        &:hover {
          color: #5a5e66;
        }
      }

      .full-box {
        width: 100%;
      }

      .number-warp {
        position: relative;
        width: 120px;
      }

      .number-box {
        width: 120px;
      }

      .child-name {
        float: left;
      }

      .parent-name {
        float: right;
        margin-right: 30px;
      }

      .info-icon {
        position: absolute;
        right: -36px;
        top: 4px;
        /*margin-top: -10px;*/
        width: 24px;
        height: 24px;
        color: #8492a6;
        outline: none;
        font-size: 20px;
      }

      .view-icon {
        outline: none;
        cursor: pointer;
      }

      .view-icon:hover {
        color: #1d8ce0;
      }

      .inter-icon {
        position: absolute;
        right: -32px;
        bottom: -23px;
        background: #8492a6;
        width: 24px;
        height: 24px;
        line-height: 24px;
        color: #fff;
        border-radius: 50%;
        text-align: center;
      }

      .number-unit {
        position: absolute;
        top: 0;
        right: 42px;
        line-height: 32px;
      }


      .two-col-box .el-tree .el-tree-node__children {

      }

      .two-col-box .el-tree .el-tree-node__children .el-tree-node {
        float: left;
        width: 50%;
      }

      .five-col-box .el-tree .el-tree-node__children .el-tree-node {
        float: left;
        width: 20%;
      }

      .el-tree .el-tree-node__children .el-tree-node__expand-icon {
        width: 10px;
        padding: 0;
      }

      .el-tree .el-tree-node__children .el-tree-node__content:hover {
        background-color: transparent !important;
      }
    }


    .cnt-box-form {
      padding-top: 4px;
    }

    .usp-prompt {
      color: rgb(153,153,153);
      margin-right: 10px;
    }

    .version-txt {
      margin-left: 5px;
      line-height: 30px;
      color: #606266;
    }

    .expose-row {
      margin-top: 10px;
      margin-bottom: 10px;
      .expose-input {
        width: 300px;
      }
    }

    .role-box {
      padding-right: 200px;
      position: relative;

      .role-list {
        margin: 2px 0 0 0;
        padding: 0;
        list-style: none;

        li {
          float: left;
          width: 50%;
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: nowrap;
          line-height: 28px;
        }
      }

      .unbind-btn {
        position: absolute;
        right: 10px;
        top: -2px;
      }
    }


    .btn-box {
      padding-top: 2px;
    }

    .save-btn {
      width: 180px;
    }

    .cancel-btn {
      margin-left: 30px;
      width: 80px;
    }
  }

</style>