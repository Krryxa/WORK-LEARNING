<template>
  <div class="container-box ads-workflow-box" v-loading="bodyLoading" element-loading-text="拼命加载中">
    <header class="container-header clearfix">
      <div class="top-line-title">
        <el-breadcrumb separator="/">
        <el-breadcrumb-item >广告列表</el-breadcrumb-item>
        <el-breadcrumb-item>工作流权限设置</el-breadcrumb-item>
      </el-breadcrumb>
      </div>
    </header>

    <div class="container-body">
      <div class="base-panel">
        <h2 class="title">基础设置</h2>
        <div class="settings-row">
          <div class="settings-label settings-label-stat"><span class="star">*</span>坑位名称：</div>
          <div class="settings-cnt">
            <div class="group-name-box">
              <el-input v-model="curZoneName" placeholder="请给这个运营位坑位设置一个名称 （格式如：主流人群首页-固定栏目区-好物签到-广告位）" size="mini"></el-input>
              <a class="clear el-icon-close" @click="curZoneName=''"></a>
              <el-tooltip placement="right">
                <div slot="content">坑位（广告位）是用于申请方在一审过后，填写广告内容时选择要投放的广告位。一个申请位会对应多个广告位，请按规范填写，方便申请方快速辨认所需投放的广告位。（格式如：主流人群首页-固定栏目区-好物签到-广告位）</div>
                <div class="info-icon"><i class="el-icon-info"></i></div>
              </el-tooltip>
            </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label settings-label-stat"><span class="star">*</span>设定申请位：</div>
          <div class="settings-cnt">
            <div>
              <template>
                <el-radio-group v-model="applyType" class="settings-label-stat" @change="changeApplyType()">
                  <el-radio :label="1">把该坑位关联到<strong>已有的申请位</strong></el-radio>
                  <el-radio :label="0">把该坑位设定为<strong>新的申请位</strong></el-radio>
                </el-radio-group>
              </template>
            </div>
          </div>
        </div>
        <div class="settings-wrap" v-show="applyType==1">
          <div class="settings-row settings-prompt-row">
            <span class="prompt-txt">（关联到已有申请位中，能让坑位继承该申请位当前已有的审核权限关系）</span>
          </div>
          <div class="settings-row settings-row-txt">
            <div class="settings-label settings-label-stat"><span class="star">*</span>需关联的申请位：</div>
            <div class="settings-cnt">
              <div class="group-name-box">
                <template>
                  <el-cascader :options="applyList" filterable placeholder="单选，或关键字搜索所需关联的已有申请位" size="mini" class="select" v-model="selectedApplys"
                    @change="handleApplyChange">
                  </el-cascader>
                </template>
                <el-tooltip placement="right">
                  <div slot="content">申请位是用于申请方在一开始申请广告资源时选择的，申请位是标识申请方是否正确申请广告资源和赋予审核方审核权限的唯一依据，请按规范选择和填写。</div>
                  <div class="info-icon"><i class="el-icon-info"></i></div>
                </el-tooltip>
              </div>
            </div>
          </div>
        </div>
        <div class="settings-wrap" v-show="applyType!=1">
          <div class="settings-row settings-prompt-row">
            <span class="prompt-txt">（设定为新的申请位，需创建申请位，和设置申请位所属的父频道）</span>
          </div>
          <div class="settings-row settings-row-txt">
            <div class="settings-label settings-label-stat"><span class="star">*</span>新的申请位名称：</div>
            <div class="settings-cnt">
              <div class="group-name-box">
                <el-input v-model="newApplyName" placeholder="请填写申请位名称 （格式如：主流人群首页-固定栏目区-好物签到-申请位）" size="mini"></el-input>
                <el-tooltip placement="right">
                  <div slot="content">申请位是用于申请方在一开始申请广告资源时选择的，申请位是标识申请方是否正确申请广告资源和赋予审核方审核权限的唯一依据，请按规范选择和填写。</div>
                  <div class="info-icon"><i class="el-icon-info"></i></div>
                </el-tooltip>
              </div>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-label settings-label-stat"><span class="star">*</span>申请位所属的父频道：</div>
            <div class="settings-cnt">
              <div class="group-name-box">
                <template>
                  <el-select v-model="selectedpChannel" placeholder="单选，或关键字搜索所需关联的父频道（即APP的频道页面，如【移动】主流人群首页）" size="mini" class="select"  filterable>
                    <el-option
                      v-for="item in pChannelList"
                      :label="item.name"
                      :value=item.id
                      :key="item.id">
                    </el-option>
                  </el-select>
                </template>
                <el-tooltip placement="right">
                  <div slot="content">父频道是用于把申请位归类的，通过父频道，申请方可以在申请广告资源时快速找到申请位。父频道目前按app首页和子频道的方式来定义，所以可按申请位的位置去选择父频道。</div>
                  <div class="info-icon"><i class="el-icon-info"></i></div>
                </el-tooltip>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="authority-panel">
        <h2 class="title">
          <div class="title-inner">
            <div class="title-txt">审核权限设置</div>
          </div>
        </h2>
        <div class="settings-row">
          <div class="settings-label settings-label-stat">一审（权重）审核方：</div>
          <div class="settings-cnt">
            <div class="group-name-box">
              <template v-if="myFirstRoles.length == 0">
              <el-select v-model="selectedFirstRoles" placeholder="多选，或关键字搜索负责该申请位一审（即广告权重审核）的角色组名称或OA账号（英文全名）" size="mini" class="select"  filterable multiple :filter-method="filterFirstRoles" :disabled=isExamOff>
                <el-option
                  v-for="item in firstRoles"
                  :label="item.name"
                  :value=item.id
                  :key="item.id"
                  >
                </el-option>
              </el-select>
            </template>

            <div class="role-box" v-else>
              <ul class="role-list clearfix">
                <li v-for="(item, index) in myFirstRoles" :key="index">{{item.name}}</li>
              </ul>
              <el-button class="unbind-btn" type="text" @click="unbindFirstRoles">【解除现有权限并重新设置】</el-button>
            </div>
            <el-tooltip placement="right">
              <div slot="content">一审二审权限是以用户角色组的方式来赋予的，在分配权限前，请明确该申请位对应的审核人员所在的角色组后再赋予。（角色组一般按部门&职责来划分归组。）</div>
              <div class="info-icon"><i class="el-icon-info"></i></div>
            </el-tooltip>
          </div>
          </div>
        </div>
        <div class="settings-row">
          <div class="settings-label settings-label-stat">二审（内容）审核方：</div>
          <div class="settings-cnt">
            <div class="group-name-box">
              <template v-if="mySecondRoles.length == 0">
              <el-select v-model="selectedSecondRoles" placeholder="多选，或关键字搜索负责该申请位二审（即广告内容审核）的角色组名称或OA账号（英文全名）" size="mini" class="select" @change="handleSecondChange" filterable multiple :filter-method="filterSecondRoles" :disabled=isExamOff>
                <el-option
                  v-for="item in secondRoles"
                  :label="item.name"
                  :value=item.id
                  :key="item.id">
                </el-option>
              </el-select>
            </template>

            <div class="role-box" v-else>
              <ul class="role-list clearfix">
                <li v-for="(item, index) in mySecondRoles" :key="index">{{item.name}}</li>
              </ul>
              <el-button class="unbind-btn" type="text" @click="unbindSecondRoles">【解除现有权限并重新设置】</el-button>
            </div>

            <el-tooltip placement="right">
              <div slot="content">一审二审权限是以用户角色组的方式来赋予的，在分配权限前，请明确该申请位对应的审核人员所在的角色组后再赋予。（角色组一般按部门&职责来划分归组。）</div>
              <div class="info-icon"><i class="el-icon-info"></i></div>
            </el-tooltip>

          </div>
          </div>
        </div>
        <div class="settings-row">
        <span class="prompt-txt">（注：以上【解除现有权限并重新设置】一旦点击，就会被立刻解除，不通过【确定】按钮，请谨慎操作）<br />（如找不到对应的审核角色组，请找产品经理咨询或创建）</span>
        </div>
      </div>
    </div>

    <!--底部条-->
    <footer class="container-footer clearfix">
      <div class="btn-box">
        <el-button type="primary" class="save-btn" @click="saveSettings()"><strong>保存</strong></el-button>
        <el-button class="cancel-btn" @click="goBack()">取消</el-button>
      </div>
    </footer>
  </div>
</template>

<script>
var raceAdsLsKey = "ads-race-ids";
var visualRaceAdsLsKey = "ads-race-visual_ids";

import utils from "../../../libs/utils";
import uri from "../../../libs/uri";
import storage from "../../../libs/storage";
// window.storage = storage;

var g_applyRoles = null; //[后台数据];
var g_pChannelRoles = null; //[后台数据];

export default {
  data() {
    return {
      bodyLoading: false,

      applyType: 1 /* 1代表现在的申请位，0代表新的申请位 */,
      zoneCode: "",
      curZoneName: "",

      applyList: [] /* 申请位列表 */,
      selectedApplys: [] /*  */,

      newApplyName: "" /* 新申请位的名字 */,
      pChannelList: [] /* 父频道列表 */,
      selectedpChannel: "",

      firstRoles: [],
      selectedFirstRoles: [],

      secondRoles: [],
      selectedSecondRoles: [],

      /* 用来记录我现在的状态 */
      myApplyInfo: {
        id: 0,
        name: "",
        pChannelId: 0,
        pChannelName: ""
      },
      myApplyId: 0 /* 申请位ID */,
      myFirstRoles: [] /* 我已经选择的第一角色 */,
      mySecondRoles: [] /* 我已经选择的第二角色 */
    };
  },

  computed: {
    isExamOff() {
      if (this.applyType == 1 && this.selectedApplys.length != 2) {
        return true;
      } else {
        return false;
      }
    }
  },

  mounted() {
    var zoneCode = uri.query("zoneCode", true);
    if (zoneCode) {
      this.zoneCode = zoneCode;
      this.init();
    } else {
      this.$alert("哎呀，zoneCode没带过来", "提示", {
        confirmButtonText: "确定",
        type: "warning"
      });
    }
  },
  methods: {
    init() {
      this.bodyLoading = true;

      /* 取出zonecode的名称 */
      this.$API({
        method: "get",
        url: this.$URL.getUrl("getZoneInfo"),
        params: {
          zone_code: this.zoneCode
        }
      }).then(
        result => {
          this.bodyLoading = false;

          if (result.status == 200 && result.data) {
            this.curZoneName = result.data.zonename;
            var applyInfo = result.data.application_info;
            if (applyInfo && parseInt(applyInfo.id) > 0) {
              this.myApplyInfo.id = parseInt(applyInfo.id);
              this.myApplyInfo.name = applyInfo.apply_name;
              this.myApplyInfo.pChannelId = parseInt(
                applyInfo.application_chl_id
              );
              this.myApplyInfo.pChannelName = applyInfo.chl_name;
            }
            console.log(this.myApplyInfo);
            this.changeApplyType();
          } else {
            this.zoneCode = "";
            this.$toast({
              title: result.msg ? result.msg : "获取zoneCode信息失败.",
              type: "warning"
            });
          }
        },
        result => {
          this.bodyLoading = false;
          this.zoneCode = "";
          this.$toast({
            title: "zoneCode不对，取不出信息！",
            type: "warning"
          });
        }
      );
    },

    changeApplyType() {
      this.firstRoles = [];
      this.selectedFirstRoles = [];
      this.secondRoles = [];
      this.selectedSecondRoles = [];

      this.myFirstRoles = [];
      this.mySecondRoles = [];

      if (this.applyType == 1) {
        //添加到现有的申请位
        if (this.applyList.length <= 0) {
          this.selectedApplys = [];
          this.getApplyList();
        } else {
          this.handleApplyChange();
        }
      } else {
        //添加到新的申请位
        if (this.pChannelList.length <= 0) {
          this.selectedpChannel = "";

          this.getPChannelList();
        } else {
          this.getPChannelRoles();
        }
      }
    },

    getApplyList() {
      this.bodyLoading = true;

      /* 取出申请位列表 */
      this.$API({
        method: "get",
        url: this.$URL.getUrl("getApplyTree"),
        params: {
          appid: 1,
          limit_channel: 1
        }
      }).then(
        result => {
          this.bodyLoading = false;

          if (result.status == 200 && result.data) {
            var list = result.data;
            var tmpList = [];
            var hasRecord = false;
            for (var i = 0; i < list.length; i++) {
              var selectedApplys = []; /*  */
              var item = list[i];
              var itemId = parseInt(item.chl_id);
              // var itemId = i + 1;
              if (
                this.myApplyInfo.pChannelId > 0 &&
                itemId == this.myApplyInfo.pChannelId
              ) {
                selectedApplys.push(itemId);
              }
              var children = item.children;
              var node = { value: itemId, label: item.chl_name };
              var childList = [];
              for (var j = 0; j < children.length; j++) {
                var childItem = children[j];
                var childItemId = parseInt(childItem["id"]);
                var childNode = {
                  value: childItemId,
                  label: childItem["apply_name"]
                };
                childList.push(childNode);

                if (
                  this.myApplyInfo.id > 0 &&
                  this.myApplyInfo.id == childItemId
                ) {
                  if (selectedApplys.length == 1) {
                    selectedApplys.push(childItemId);
                  } else {
                    console.log(itemId, childItemId);
                    alert("返回数据有误，父频道和申请位不一致");
                  }
                }
              }

              if (selectedApplys.length == 1) {
                /* 有父频道，没有申请位，把申请位加上 */
                childList.unshift({
                  value: this.myApplyInfo.id,
                  label: this.myApplyInfo.name
                });
                hasRecord = true;
              } else if (selectedApplys.length == 2) {
                //已经存在
                hasRecord = true;
              }

              if (childList.length > 0) {
                node["children"] = childList;
              }
              tmpList.push(node);
            }

            if (this.myApplyInfo.pChannelId > 0 && !hasRecord) {
              /* 可能由于权限问题，此记录在列表的没有返回，那么也把它插入去 */
              var node = {
                value: this.myApplyInfo.pChannelId,
                label: this.myApplyInfo.pChannelName
              };
              node["children"] = [
                { value: this.myApplyInfo.id, label: this.myApplyInfo.name }
              ];
              tmpList.unshift(node);
            }

            if (this.myApplyInfo.pChannelId > 0) {
              this.selectedApplys = [
                this.myApplyInfo.pChannelId,
                this.myApplyInfo.id
              ];
            }
            this.applyList = tmpList;

            this.handleApplyChange();
          } else {
            this.$toast({
              title: result.msg ? result.msg : "获取申请位列表失败.",
              type: "warning"
            });
          }
        },
        result => {
          this.bodyLoading = false;
          this.$toast({
            title: "获取申请位列表失败！",
            type: "warning"
          });
        }
      );
    },

    getPChannelList() {
      /* 取出父频道列表 */
      this.$API({
        method: "get",
        url: this.$URL.getUrl("getPChannelList"),
        params: {
          is_limit: 1
        }
      }).then(
        result => {
          this.bodyLoading = false;

          if (result.status == 200 && result.options) {
            var list = result.options;
            var tmpList = [];
            for (var i = 0; i < list.length; i++) {
              var item = list[i];
              var children = item.children;
              var node = { id: parseInt(item.value), name: item.name };
              tmpList.push(node);
            }

            this.pChannelList = tmpList;

            this.getPChannelRoles();
          } else {
            this.$toast({
              title: result.msg ? result.msg : "获取申请位列表失败.",
              type: "warning"
            });
          }
        },
        result => {
          this.bodyLoading = false;
          this.$toast({
            title: "获取申请位列表失败！",
            type: "warning"
          });
        }
      );
    },

    handleApplyChange() {
      /* 取角色列表 */

      console.log("this.selectedApplys: ", this.selectedApplys);

      if (this.selectedApplys && this.selectedApplys.length == 2) {
        this.bodyLoading = true;

        var applyId = this.selectedApplys[1];
        /* 取出申请位列表 */
        this.$API({
          method: "get",
          url: this.$URL.getUrl("getRoleList"),
          params: {
            application_id: parseInt(applyId)
          }
        }).then(
          result => {
            this.bodyLoading = false;

            var firstList = [];
            var secondList = [];
            if (result.status == 200 && result.data) {
              var list = result.data;

              //保存一个副本，以便搜索
              g_applyRoles = list;

              var firstInfo = this.filterRoles(1, null, true);
              this.firstRoles = firstInfo[0];
              this.myFirstRoles = firstInfo[1];

              var secondInfo = this.filterRoles(2, null, true);
              this.secondRoles = secondInfo[0];
              this.mySecondRoles = secondInfo[1];
            } else {
              this.$toast({
                title: result.msg ? result.msg : "获取角色列表失败.",
                type: "warning"
              });
            }
          },
          result => {
            this.bodyLoading = false;
            this.$toast({
              title: "获取角色列表失败！",
              type: "warning"
            });
          }
        );
      }
    },

    getPChannelRoles() {
      g_pChannelRoles = g_pChannelRoles
        ? g_pChannelRoles
        : g_applyRoles ? g_applyRoles : null;

      if (!g_pChannelRoles) {
        /* 取出父频道时角色列表 */
        this.$API({
          method: "get",
          url: this.$URL.getUrl("getRoleList")
        }).then(
          result => {
            this.bodyLoading = false;

            var firstList = [];
            var secondList = [];
            // var myFirstRoles = [];
            // var mySecondRoles = [];
            if (result.status == 200 && result.data) {
              var list = result.data;

              //保存一个副本，以便搜索
              g_pChannelRoles = list;

              this.firstRoles = this.filterRoles(1)[0];
              this.secondRoles = this.filterRoles(2)[0];
            } else {
              this.$toast({
                title: result.msg ? result.msg : "获取角色列表失败.",
                type: "warning"
              });
            }
          },
          result => {
            this.bodyLoading = false;
            this.$toast({
              title: "获取角色列表失败！",
              type: "warning"
            });
          }
        );
      } else {
        this.firstRoles = this.filterRoles(1)[0];
        this.secondRoles = this.filterRoles(2)[0];
      }
    },

    filterRoles(which, searchTxt, hasSelected) {
      var source;
      var selectedKey;
      if (this.applyType == 1) {
        source = g_applyRoles;
      } else {
        hasSelected = false; /* 不用取是否已经选择上 */
        source = g_pChannelRoles;
      }

      if (which == 1) {
        selectedKey = "first_roles";
      } else {
        selectedKey = "second_roles";
      }

      searchTxt = searchTxt ? searchTxt : "";
      searchTxt = searchTxt.replace(/^\s+|\s+$/g, "");

      var allRoles = [];
      var selectedRoles = [];
      if (searchTxt) {
        searchTxt = searchTxt.toLowerCase();
        for (var key in source) {
          var item = source[key];
          var id = parseInt(key);
          var name = item["role_name"];
          if (name.toLowerCase().indexOf(searchTxt) >= 0) {
            allRoles.push({ id: id, name: name });
            if (hasSelected && item[selectedKey]) {
              selectedRoles.push({ id: id, name: name });
            }
          } else {
            /* 看OA列表是否有搜索的内容 */
            var oaList = item["oa"] || [];
            for (var i = 0; i < oaList.length; i++) {
              var oaName = oaList[i];
              if (oaName.toLowerCase().indexOf(searchTxt) >= 0) {
                allRoles.push({ id: id, name: name });
                if (hasSelected && item[selectedKey]) {
                  selectedRoles.push({ id: id, name: name });
                }
                break; /* 退出本次循环 */
              }
            }
          }
        }
      } else {
        for (var key in source) {
          var item = source[key];
          var id = parseInt(key);
          var name = item["role_name"];
          allRoles.push({ id: id, name: name });
          if (hasSelected && item[selectedKey]) {
            selectedRoles.push({ id: id, name: name });
          }
        }
      }

      console.log([allRoles, selectedRoles]);
      return [allRoles, selectedRoles];
    },

    filterFirstRoles(searchTxt) {
      searchTxt = searchTxt ? searchTxt : "";
      searchTxt = searchTxt.replace(/^\s+|\s+$/g, "");

      this.firstRoles = this.filterRoles(1, searchTxt)[0];
    },

    getExamData(which) {
      if (this.applyType == 1) {
        return g_applyRoles[which - 1];
      } else {
        return g_pChannelRoles[which - 1];
      }
    },

    handleSecondChange() {
      console.log(this.selectedSecondRoles);
    },

    filterSecondRoles(searchTxt) {
      searchTxt = searchTxt ? searchTxt : "";
      searchTxt = searchTxt.replace(/^\s+|\s+$/g, "");

      this.secondRoles = this.filterRoles(2, searchTxt)[0];
    },

    unbindFirstRoles() {
      this.bodyLoading = true;

      var selectedApplys = this.selectedApplys;
      /* 取出zonecode的名称 */
      this.$API({
        method: "get",
        url: this.$URL.getUrl("unbindRoles"),
        params: {
          delete_flag: 1,
          application_id: selectedApplys[1]
        }
      }).then(
        result => {
          this.bodyLoading = false;

          if (result.status == 200) {
            this.myFirstRoles = [];
          } else {
            this.$toast({
              title: result.msg ? result.msg : "解绑一审（权重）审核方失败.",
              type: "warning"
            });
          }
        },
        result => {
          this.bodyLoading = false;
          this.$toast({
            title: "解绑一审（权重）审核方失败！",
            type: "warning"
          });
        }
      );
    },

    unbindSecondRoles() {
      this.bodyLoading = true;

      var selectedApplys = this.selectedApplys;
      /* 取出zonecode的名称 */
      this.$API({
        method: "get",
        url: this.$URL.getUrl("unbindRoles"),
        params: {
          delete_flag: 2,
          application_id: selectedApplys[1]
        }
      }).then(
        result => {
          this.bodyLoading = false;

          if (result.status == 200) {
            this.mySecondRoles = [];
          } else {
            this.$toast({
              title: result.msg ? result.msg : "解绑二审（权重）审核方失败.",
              type: "warning"
            });
          }
        },
        result => {
          this.bodyLoading = false;
          this.$toast({
            title: "解绑二审（权重）审核方失败！",
            type: "warning"
          });
        }
      );
    },

    saveSettings() {
      if (!this.zoneCode) {
        this.$alert("哎呀，zoneCode不对,不能保存啊", "提示", {
          confirmButtonText: "确定",
          type: "warning"
        });
        return;
      }

      var paramObj = {};

      var zoneName = utils.trim(this.curZoneName);
      if (zoneName.length < 2) {
        var txt = "坑位名称不能少于2个字！";
        if (zoneName.length == 0) {
          txt = "坑位名称不能为空，且不能少于2个字！";
        }
        this.$toast({
          title: txt,
          type: "warning"
        });
        return false;
      }

      var applyType = this.applyType;
      if (applyType == 1) {
        //添加到现胡的申请位
        if (this.selectedApplys.length != 2) {
          this.$toast({
            title: "请选择一个申请位",
            type: "warning"
          });
          return false;
        }
        var applyId = parseInt(this.selectedApplys[1]);
        paramObj["application_id"] = applyId;
      } else {
        //添加新申请位
        var newApplyName = this.newApplyName;
        if (newApplyName.length < 2) {
          var txt = "新的申请位名称不能少于2个字！";
          if (this.newApplyName.length == 0) {
            txt = "新的申请位名称不能为空，且不能少于2个字！";
          }
          this.$toast({
            title: txt,
            type: "warning"
          });
          return false;
        }
        paramObj["application_name"] = newApplyName;

        if (!this.selectedpChannel) {
          this.$toast({
            title: "请选择申请位的一个父频道",
            type: "warning"
          });
          return false;
        }
        var pChannelId = parseInt(this.selectedpChannel);
        paramObj["application_chl_id"] = pChannelId;
      }
      paramObj["is_update"] = applyType;

      paramObj["zonecode"] = this.zoneCode;
      paramObj["zonename"] = zoneName;

      if (this.selectedFirstRoles.length > 0) {
        paramObj["review_first_roles"] = this.selectedFirstRoles.join(",");
      }

      if (this.selectedSecondRoles.length > 0) {
        paramObj["review_second_roles"] = this.selectedSecondRoles.join(",");
      }

      this.bodyLoading = true;

      this.$API({
        method: "post",
        url: this.$URL.getUrl("saveAdsWorkflow"),
        isFormData: true,
        data: paramObj
      }).then(
        result => {
          if (result.status == 200) {
            this.$toast({
              title: "保存成功, 即将生效, 正在刷新页面",
              type: "success"
            });

            setTimeout(function() {
              window.location.reload();
            }, 1500);
          } else {
            this.bodyLoading = false;

            var errMsg = result.msg ? result.msg : "保存失败, 请联系产品经理.";
            this.$toast({
              title: errMsg,
              type: "warning"
            });
          }
        },
        result => {
          this.bodyLoading = false;
          var errMsg = result.msg ? result.msg : "保存失败, 请联系产品经理!";
          this.$toast({
            title: errMsg,
            type: "warning"
          });
        }
      );
    },

    goBack() {
      window.history.go(-1);
    }
  }
};
</script>

<style lang="scss">
.ads-workflow-box {
  button {
    font-family: "Microsoft YaHei", "Helvetica Neue", "Helvetica", "PingFang SC", "Hiragino Sans GB", "\5FAE\8F6F\96C5\9ED1", "Arial", "sans-serif";
  }
  
  .authority-panel {
    margin-top: 80px;
    padding-bottom: 20px;
  }

  .icon-right:before {
    width: 36px;
    height: 36px;
    font-size: 20px;
    line-height: 36px;
    color: #13ce66;
    /* background-color: #13ce66; */
  }

  .prompt-txt {
    margin-top: 5px;
    color: #bbb;
  }

  .title {
    margin: 20px auto 0 auto;
    border-left: 4px solid #666;
    padding-left: 10px;
    text-align: left;
    line-height: 27px;
    font-size: 24px;
    font-weight: normal;
    color: #666;

    .title-inner {
      position: relative;
      margin-right: 50px;
    }

    .title-txt {
      display: inline-block;
      vertical-align: middle;
    }

    .title-time {
      display: inline-block;
      vertical-align: middle;
      background-color: #13ce66;
      color: #fff;
      border-radius: 3px;
      margin-left: 20px;
      padding: 0 10px;
      font-size: 13px;
      line-height: 21px;
    }

    .title-btn-box {
      position: absolute;
      line-height: normal;
      vertical-align: top;
      right: 5px;
      top: -3px;
    }
  }

  .settings-row {
    position: relative;
    margin: 40px 50px 0 auto;
    padding: 0 0 0 180px;
  }

  .settings-wrap {
    .settings-row {
      margin-top: 35px;
    }

    .settings-prompt-row {
      margin-top: 10px;
    }

    .settings-row-txt {
      margin-top: 20px;
    }
  }

  .settings-label {
    position: absolute;
    left: 0;
    top: 0;
    width: 160px;
    text-align: right;
    white-space: nowrap;
  }

  .settings-label-stat {
    line-height: 30px;
  }

  .settings-cnt {
  }

  .star {
    color: #fd2b2b;
  }

  .group-name-box {
    position: relative;
    margin-top: 5px;
    margin-right: auto;
    width: 90%;
    max-width: 700px;

    .clear {
      position: absolute;
      right: 10px;
      top: 9px;
      color: #bfcbd9;
      font-size: 14px;
      line-height: 14px;
      vertical-align: middle;
      cursor: pointer;
      user-select: none;
      -webkit-user-select: none;
      &:hover {
        color: #5a5e66;
      }
    }

    .select {
      width: 100%;
    }

    .info-icon {
      position: absolute;
      right: -36px;
      top: 6px;
      /*margin-top: -10px;*/
      width: 24px;
      height: 24px;
    }
  }

  .role-box {
    padding-right: 200px;
    position: relative;

    .role-list {
      margin: 2px 0 0 0;
      padding: 0;
      list-style: none;

      li {
        float: left;
        width: 50%;
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
        line-height: 28px;
      }
    }

    .unbind-btn {
      position: absolute;
      right: 10px;
      top: -2px;
    }
  }

  .btn-box {
    padding-top: 2px;
  }

  .save-btn {
    width: 180px;
  }

  .cancel-btn {
    margin-left: 30px;
    width: 80px;
  }
}
</style>