<template>
  <div class='info'>
    <div class="item g-eidt-item">
      <h3 class="title g-left">排期活动：</h3>
      <div class="content g-right">
        <el-select v-model="validated_data.plan" placeholder="可选择来自规划日历的排期活动">
          <el-option
            v-for="item in options"
            :label="item.label"
            :value="item.value"
            :key="item.value">
          </el-option>
        </el-select>
      </div>
    </div>
    <div class="item g-eidt-item">
      <h3 class="title g-left"><span>*</span>广告名称：</h3>
      <div class="content g-right">
        <el-input
          placeholder="用于本系统，不显示在前端页面"
          v-model="validated_data.ad_name"
        ></el-input>
      </div>
    </div>
    <div class="item g-eidt-item">
      <h3 class="title g-left"><span>*</span>上线时间：</h3>
      <div class="content g-right">
        <el-date-picker
          v-model="date.start"
          type="date"
          placeholder="选择日期"
          :picker-options="pickerOptions">
        </el-date-picker>
        <span class='date-txt'>至</span>
        <el-date-picker
          v-model="date.end"
          type="date"
          placeholder="选择日期"
          :picker-options="pickerOptions">
        </el-date-picker>
      </div>
    </div>
    <div class="item g-eidt-item">
      <h3 class="title g-left"><span>*</span>广告权重：</h3>
      <div class="content g-right">
        <el-input
          v-model="validated_data.ad_weight"
        ></el-input>
        <span class="u-details">
          <span>?</span>
          <span>0-10的数字，数字越大优先级越高</span>
          <i class="el-icon-caret-bottom"></i>
        </span>
      </div>
    </div>
    <div class="item g-eidt-item">
      <h3 class="title g-left"><span>*</span>用户标签：</h3>
      <div class="content g-right">
        <SelectBox
          :placeholder = "user_tag.placeholder"
          :isInput = "user_tag.isInput"
          :groupData = "user_tag.data"
          :isSearch = "user_tag.isSearch"
          :title = "user_tag.title"
          :isShowResultInBar = "user_tag.isShowResultInBar"
          :isShowResult = "user_tag.isShowResult"
        ></SelectBox>
      </div>
    </div>
    <div class="item g-eidt-item">
      <h3 class="title g-left">USP人群：</h3>
      <div class="content g-right">
        <SelectBox
          :placeholder = "usp_group.placeholder"
          :isInput = "usp_group.isInput"
          :groupData = "usp_group.data"
          :isSearch = "usp_group.isSearch"
          :title = "usp_group.title"
          :isShowResultInBar = "usp_group.isShowResultInBar"
          :isShowResult = "usp_group.isShowResult"
        ></SelectBox>
      </div>
    </div>
    <div class="item g-eidt-item">
      <h3 class="title g-left"><span>*</span>选择分仓：</h3>
      <div class="content g-right">
        <el-checkbox-group v-model="warehouse">
          <el-checkbox label="北京BJ"></el-checkbox>
          <el-checkbox label="成都CD"></el-checkbox>
          <el-checkbox label="上海SH"></el-checkbox>
          <el-checkbox label="南海NH"></el-checkbox>
          <el-checkbox label="华中HZ"></el-checkbox>
        </el-checkbox-group>
      </div>
    </div>
    <div class="item g-eidt-item">
      <h3 class="title g-left"><span>*</span>投放地区：</h3>
      <div class="content g-right">
        <el-radio-group v-model="area">
          <el-radio label="0">所有地区</el-radio>
          <el-radio label="1">部分地区</el-radio>
        </el-radio-group>
        <MultiSelection
          v-if="area == 1"
            :array.sync="array"
            :num.sync="2"
        ></MultiSelection>
      </div>
    </div>
    <div class="item g-eidt-item">
      <h3 class="title g-left"><span>*</span>跳转方式：</h3>
      <div class="content g-right">
        <el-select v-model="way">
          <el-option
            v-for="item in options"
            :label="item.label"
            :value="item.value"
            :key="item.value">
          </el-option>
        </el-select>
      </div>
    </div>
    <div class="item g-eidt-item">
      <h3 class="title g-left"><span>*</span>跳转地址：</h3>
      <div class="content address g-right">
        <div class="wrap">
          <h4>默认地址<span class="del">删除</span></h4>
          <el-input
            placeholder="请填写URL链接"
            v-model="address">
          </el-input>
        </div>
        <a class="link" href="">+ 增加链接</a>
        <a class="link" href="">导入链接</a>
      </div>
    </div>
  </div>
</template>

<script>
  import SelectBox from 'com/selectBox/index';
  import MultiSelection from 'com/multiSelection/index';

  export default {
    data() {
      return {
        date: {
          start: '',
          end: ''
        },
        warehouse: '',
        area: '0',
        way: '',
        user_tag: {
          placeholder: '全部',
          isShowResult: false,
          isShowResultInBar: true,
          isInput: true,
          isSearch: false,
          data: [{
            group_name: '新客',
            group_cnt: [{'label': '全部', 'value': 0, 'isAll': true}, {'label': 'A', 'value': 1, 'isAll': false}, {'label': 'A1', 'value': 2, 'isAll': false}, {'label': 'A2', 'value': 3, 'isAll': false}, {'label': 'A3', 'value': 4, 'isAll': false}, {'label': 'A4', 'value': 5, 'isAll': false}, {'label': 'B', 'value': 6, 'isAll': false}]
          }, {
            group_name: '老客',
            group_cnt: [{'label': '全部', 'value': 0, 'isAll': true}, {'label': 'C11', 'value': 1, 'isAll': false}, {'label': 'C12', 'value': 2, 'isAll': false}, {'label': 'C13', 'value': 3, 'isAll': false}, {'label': 'C10', 'value': 3, 'isAll': false}, {'label': 'C1-1', 'value': 3, 'isAll': false}, {'label': 'C1-2', 'value': 0, 'isAll': false}, {'label': 'C1-3', 'value': 0, 'isAll': false}, {'label': 'C2-1', 'value': 0, 'isAll': false}, {'label': 'C2-2', 'value': 0, 'isAll': false}, {'label': 'C2-3', 'value': 0, 'isAll': false}, {'label': 'C2-4', 'value': 0, 'isAll': false}, {'label': 'C2-5', 'value': 0, 'isAll': false}, {'label': 'C2-6', 'value': 0, 'isAll': false}, {'label': 'CX', 'value': 0, 'isAll': false}, {'label': 'C', 'value': 0, 'isAll': false}, {'label': 'C3', 'value': 0, 'isAll': false}]
          }]
        },
        usp_group: {
          placeholder: '全部',
          isShowResult: true,
          isShowResultInBar: false,
          isInput: true,
          isSearch: false,
          data: [{
            group_name: '新客',
            group_cnt: [{'label': '全部', 'value': 0, 'isAll': true}, {'label': 'USP人群2', 'value': 1, 'isAll': false}, {'label': 'USP人群3', 'value': 2, 'isAll': false}, {'label': 'USP人群4', 'value': 3, 'isAll': false}, {'label': 'USP人群5', 'value': 4, 'isAll': false}, {'label': 'USP人群6', 'value': 5, 'isAll': false}, {'label': 'USP人群1', 'value': 6, 'isAll': false}]
          }]
        },
        groupData: [
          {
            group_name: '潮州牛肉火锅',
            group_cnt: [{'label': '全部', 'value': 0, 'isAll': true}, {'label': 'C11', 'value': 1, 'isAll': false}, {'label': 'C12', 'value': 2, 'isAll': false}, {'label': 'C13', 'value': 3, 'isAll': false}, {'label': 'C10', 'value': 3, 'isAll': false}, {'label': 'C1-1', 'value': 3, 'isAll': false}, {'label': 'C1-2', 'value': 0, 'isAll': false}, {'label': 'C1-3', 'value': 0, 'isAll': false}, {'label': 'C2-1', 'value': 0, 'isAll': false}, {'label': 'C2-2', 'value': 0, 'isAll': false}, {'label': 'C2-3', 'value': 0, 'isAll': false}, {'label': 'C2-4', 'value': 0, 'isAll': false}, {'label': 'C2-5', 'value': 0, 'isAll': false}, {'label': 'C2-6', 'value': 0, 'isAll': false}, {'label': 'CX', 'value': 0, 'isAll': false}, {'label': 'C', 'value': 0, 'isAll': false}, {'label': 'C3', 'value': 0, 'isAll': false}]
          },
          {
            group_name: '潮州咸水粿',
            group_cnt: [{'label': '全部', 'value': 0, 'isAll': true}]
          }
        ],
        array: [
          {
            label: '植物',
            checked: false,
            subs: [
              {
                label: '树木',
                checked: false,
                subs: []
              },
              {
                label: '花花',
                checked: false,
                subs: []
              }
            ]
          },
          {
            label: '水果',
            checked: false,
            subs: [
              {
                label: '香蕉',
                checked: false,
                subs: []
              },
              {
                label: '苹果',
                checked: false,
                subs: []
              }
            ]
          },
          {
            label: '建筑',
            checked: false,
            subs: [
              {
                label: '中国',
                checked: false,
                subs: []
              },
              {
                label: '日本',
                checked: false,
                subs: []
              },
              {
                label: '埃及',
                checked: false,
                subs: []
              }
            ]
          }
        ],
        options: [
          {
            value: '选项1',
            label: '黄金糕'
          },
          {
            value: '选项2',
            label: '双皮奶'
          },
          {
            value: '选项3',
            label: '蚵仔煎'
          },
          {
            value: '选项4',
            label: '龙须面'
          },
          {
            value: '选项5',
            label: '北京烤鸭'
          }
        ],
        value8: '',
        link_cnt: ['北京', '成都', '上海', '南海', '华中', 'android', 'iphone', 'ipad', 'wap', 'androidpad', 'pc', 'shop_winphone', 'windowspad', 'windowsphone', 'shop_weixin_wap'],
        isEditing: true, // 是否打开快捷编辑弹窗
        validated_data: { // 表单验证数据
          ad_plan: '',
          ad_name: '',
          ad_time: '',
          ad_weight: '',
          ad_show_tag: '',
          ad_extend_txt: '', // 扩展字段
          ad_turn_way: '',
          ad_link: ''
        },
        title: '新增地址',
        address: ''
      };
    },
    props: {
      // isEditing: {  // 显示弹窗
      // 	type: Boolean,
      // 	default() {
      // 		return false;
      // 	}
      // },
      ad_name: {  // 广告名称
        type: String,
        default() {
          return '';
        }
      },
      ad_tip: {  // 广告提示
        type: String,
        default() {
          return '';
        }
      },
      ad_show_time: {  // 显示时间
        type: String,
        default() {
          return '';
        }
      },
      ad_show_times: {  // 显示次数
        type: String,
        default() {
          return '';
        }
      },
      ad_lack: {  // 缺省广告
        type: Boolean,
        default() {
          return false;
        }
      },
      ad_turn_way: {  // 跳转方式
        type: String,
        default() {
          return '';
        }
      },
      ad_link: {  // 链接地址
        type: String,
        default() {
          return '';
        }
      }
    },
    methods: {
      test_ev() {
        this.isEditing = !this.isEditing;
      },
      cancelEdit() {
        this.isEditing = false;
      },
      checkName() {
        if (!this.$vuerify.check(['validated_data.ad_name'])) {
          this.$message.error('错了哦');
        }
      },
      checkTip() {
        if (!this.$vuerify.check(['validated_data.ad_tip'])) {
          this.$message.error('错了哦');
        }
      },
      checkExtendTxt() {
        if (!this.$vuerify.check(['validated_data.ad_extend_txt'])) {
          this.$message.error('错了哦');
        }

      },
      checkTime() {
        if (!this.$vuerify.check(['validated_data.ad_show_time'])) {
          this.$message.error('错了哦');
        }
      },
      checkTimes() {
        if (!this.$vuerify.check(['validated_data.ad_show_times'])) {
          this.$message.error('错了哦');
        }
      },
      confirmEdit() {
        if (!this.$vuerify.check([])) {
          this.$message.error('出错了哦');
        } else {
          this.$message('接口呢');
        }
      },
      getSelectedData(data) {
        console.log(data);
      },
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() < Date.now() - 8.64e7;
        }
      }
    },
    vuerify: {
      'validated_data.ad_name': [
        'required',
        {
          test: /\w{4,}/
        }
      ],
      'validated_data.ad_tip': [
        'required',
        {
          test: /\w{4,}/
        }
      ],
      'validated_data.ad_extend_txt': [
        'required',
        {
          test: /\w{4,}/
        }
      ],
      'validated_data.ad_show_time': [
        'required',
        {
          test: /^(0|[1-9][0-9]*)$/
        }
      ],
      'validated_data.ad_show_times': [
        'required',
        {
          test: /^(0|[1-9][0-9]*)$/
        }
      ]
    },
    components: {
      SelectBox,
      MultiSelection
    }
  };
</script>

<style lang="scss">
  .info{
    .item {
      margin-top: 20px;
      margin-bottom: 20px;
      .title, .content {
        font-size: 14px;
        min-height: 36px;
        line-height: 36px;
      }
      .title {
        text-align: right;
        span {
          color: red;
        }
      }
      .content {
        position: relative;
        width: 90%;
        &.address {
          width: 90%;
          .wrap{
            border-radius: 4px;
            background-color: #f2f2f2;
            padding: 0 10px 20px;
          }
          h4 {
            font-weight: normal;
          }
          .del {
            float: right;
            color: red;
            cursor: pointer;
          }
          .link {
            color: #20a0ff;
            margin-right: 30px;
          }
        }
        .date-txt {
            padding: 0 10px;
        }
      }
    }
    .m-multi-selection {
      min-width: 500px;
      .u-box {
        width: 130px;
        margin-right: 10px;
      }
      .u-list {
        height: 120px;
      }
      .u-btn {
        margin-top: 26px;
        margin-right: 10px;
      }
    }
    .u-details {
        position: absolute;
        top: 10px;
        left: 101%;
    }
  }
</style>