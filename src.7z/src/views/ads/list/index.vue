<template>
  <div :class="['container-box', 'ads-list-box', {'ads-list-adv-box': isOpenAdv}]" v-loading="bodyLoading" element-loading-text="拼命加载中">
    <header class="container-header clearfix">
      <div class="top-line-title fl">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item :to="{ path: '/list' }" v-if="inVisualPage">可视化投放</el-breadcrumb-item>
          <el-breadcrumb-item>广告列表({{total_banners}})</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <search
        :curZoneId="curZoneId"
        @event-search="handleSearch"
        @event-size="handleAdvUi"
      ></search>
    </header>

    <div class="container-body">
      <div class="ads-button-row clearfix">
        <div class="row-left fl">
          <el-tooltip placement="right">
            <div slot="content">
              <div class="ads-list-tips-box">
                <div>如需复制多个广告，请先对当前浏览器进行如下设置</div>
                <a href="http://dwz.cn/6qoDV7" target="_blank">http://dwz.cn/6qoDV7</a>
              </div>
            </div>
            <el-button class="default-btn" size="mini" :disabled="multipleSelection.length <= 0 || multipleSelection.length > 10" @click="copyRow" >复制</el-button>
          </el-tooltip>
          <el-button class="default-btn" size="mini" :disabled="multipleSelection.length <= 0" @click="copyToClipboard" v-if="inVisualPage">复制至剪切板</el-button>
          <el-button class="default-btn" size="mini" :disabled="multipleSelection.length < 1" @click="addRacing" v-if="!pageInfo.bk">加入赛马</el-button>
          <el-button class="default-btn" size="mini" :disabled="multipleSelection.length < 1" @click="addPersonalGroup" v-if="!pageInfo.bk">加入个性化（仅运营位）</el-button>
        </div>
        <div class="row-right fr">
          <el-button class="default-btn" size="mini" @click="addTestRow">新建（Test）</el-button>
          <el-button class="default-btn" size="mini" @click="openWorkflow" v-if="hasFLPermit">开通工作流投放</el-button>
          <el-button class="default-btn" size="mini" @click="clipboardStat.show=true" v-if="inVisualPage">打开剪切板</el-button>
          <el-button class="default-btn" size="mini" @click="addRow">新建</el-button>
          <el-button class="del-btn" type="text" size="mini" :disabled="multipleSelection.length <= 0" @click="delConfirm">删除</el-button>
        </div>
      </div>
      <div class="list-box">
        <!--列表层-->
        <el-table
          class="main-el-table"
          :data="tableData"
          @selection-change="handleSelectionChange"
          :row-class-name="tableRowClassName"
          header-row-class-name="g-table-header"
          cell-class-name="g-table-cell"
          height="100%"
          ref="multipleTable"
        >
          <!-- column -->
          <el-table-column
            type="selection"
            width="50"
          ></el-table-column>
          <!-- column -->
          <el-table-column
            label="广告ID"
            align="center"
            width="95"
          >
            <template slot-scope="scope"><span class="txt-pointer" @click="clickEdit(scope.row)">{{scope.row.id}}</span></template>
          </el-table-column>
          <!-- column -->
          <el-table-column
            label="广告图"
            align="center"
            width="150"
          >
            <template slot-scope="scope"><pop-icon :rowData="scope.row" :key="scope.row.imageurl" class="txt-pointer" @click="clickEdit(scope.row)"></pop-icon></template>
          </el-table-column>
          <!-- column -->
          <el-table-column
            label="广告名称"
            align="center"
            width="400"
          >
            <template slot-scope="scope">
              <div class="name-row">
                <span class="txt-pointer" @click="clickEdit(scope.row)">{{scope.row.name}}</span>
              </div>
            </template>
          </el-table-column>
          <!-- column -->
          <el-table-column
            label="上下线时间"
            align="center"
            min-width="180"
          >
            <template slot-scope="scope">
              <div>
                <div class="nowrap"><span class="txt-pointer" @click="clickEdit(scope.row)">{{ scope.row.starttime }}</span></div>
                <div class="nowrap"><span class="txt-pointer" @click="clickEdit(scope.row)">{{ scope.row.endtime }}</span></div>
              </div>
            </template>
          </el-table-column>
          <!-- column -->
          <el-table-column
            label="USP属性/人群"
            min-width="150"
            align="center"
          >
            <template slot-scope="scope">
              <div>
                <el-tooltip v-if="scope.row.usp_property_name" class="item" effect="dark" :content="scope.row.usp_property_name" placement="right">
                  <div class="tip-line-box">
                      <span class="tip-txt" @click="clickEdit(scope.scope.row)">{{scope.row.usp_property_name}}</span>
                  </div>
                </el-tooltip>
                <span v-else>-</span>
                <el-tooltip v-if="scope.row.uspnames" class="item" effect="dark" :content="scope.row.uspnames" placement="right">
                  <div class="tip-line-box">
                    <span class="tip-txt" @click="clickEdit(scope.row)">{{scope.row.uspnames}}</span>
                  </div>
                </el-tooltip>
                <span class="tip-default" v-else>-</span>
              </div>
            </template>
          </el-table-column>
          <!-- column -->
          <el-table-column
            label="申请位"
            min-width="150"
            align="center"
          >
            <template slot-scope="scope">
              <div>
                <el-tooltip v-if="scope.row.apply_name" class="item" effect="dark" :content="scope.row.apply_name" placement="right">
                  <div class="tip-box">
                    <span class="txt-pointer" @click="clickEdit(scope.row)">{{scope.row.apply_name}}</span>
                  </div>
                </el-tooltip>
                <span class="tip-default" v-else>-</span>
              </div>
            </template>
          </el-table-column>
          <!-- column -->
          <el-table-column
            label="权重"
            align="center"
            width='100'
          >
            <template slot-scope="scope"><span class="txt-pointer" @click="clickEdit(scope.row)">{{scope.row.weight}}</span></template>
          </el-table-column>
          <!-- column -->
          <el-table-column
            label="创建/更新人"
            align="center"
            min-width="120"
          >
            <template slot-scope="scope">
              <el-tooltip effect="dark" placement="right">
                <div slot="content">更新：{{scope.row.editetime}}</div>
                <div>
                  <div class="nowrap"><span class="txt-pointer" @click="clickEdit(scope.row)">{{ scope.row.author }}</span></div>
                  <div class="nowrap"><span class="txt-pointer" @click="clickEdit(scope.row)">{{ scope.row.editor }}</span></div>
                </div>
              </el-tooltip>
            </template>
          </el-table-column>
          <!-- column -->
          <el-table-column
            label="广告类型"
            align="center"
            min-width="100"
          >
            <template slot-scope="scope">
              <div>
                <div>
                  <el-tag :type="getIntroduct(scope.row.introduct_id)" size="small">{{scope.row.introduct}}</el-tag>
                </div>
                <div v-if="scope.row.isRacing" class="racing-box">
                  <el-tag type="success" class="racing-label" size="small">赛马广告</el-tag>
                </div>
                <div v-if="scope.row.isPersonal">
                  <el-tag class="personal-label" size="small">个性化广告</el-tag>
                </div>
              </div>
            </template>
          </el-table-column>
          <!-- column -->
          <el-table-column
            label="状态"
            align="center"
            min-width="110"
          >
            <template slot-scope="scope">
              <div>
                <el-switch
                  v-model="scope.row.status"
                  active-color="#13ce66"
                  inactive-color="#c0ccda"
                  @change="changeState(scope.row)">
                </el-switch>
              </div>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>

    <!--右边快速编辑弹出层-->
    <transition name="rightIn">
      <div class="clipboard-panel"
        v-show='inVisualPage && clipboardStat.show'
      >
        <!--关闭按钮-->
        <i class="el-icon-close clipboard-close"
          @click="hideClipboard"
        ></i>
        <h2 class="clipboard-title">剪切板({{clipboardStat.data.length}}/{{maxCopyTotal}})</h2>
        <!--列表层-->
        <el-table
          class="clipboard-el-table"
          :data="clipboardStat.data"
          :row-class-name="tableRowClassName"
          header-row-class-name="g-table-header"
          cell-class-name="g-table-cell"
          height="100%"
        >
          <!-- column -->
          <el-table-column
            label="广告图"
            align="center"
            width="150"
          >
            <template slot-scope="scope">
              <div class="col-photo">
                <img alt=""
                  :src="scope.row.imageurl"
                  @error="scope.row.imageurl = getImg('no-img.png')"
                >
              </div>
            </template>
          </el-table-column>
          <!-- column -->
          <el-table-column
            label="广告名称"
            align="center"
            width="200"
          >
            <template slot-scope="scope">
              <div class="name-row">{{ scope.row.name}}</div>
            </template>
          </el-table-column>
          <!-- column -->
          <el-table-column
            label="上下线时间"
            align="center"
            width="190"
          >
            <template slot-scope="scope">
              <div>
                <div class="nowrap">{{ scope.row.starttime }}</div>
                <div class="nowrap">{{ scope.row.endtime }}</div>
              </div>
            </template>
          </el-table-column>
          <!-- column -->
          <el-table-column
            label="操作"
            align="center"
            min-width="155"
          >
            <template slot-scope="scope">
              <div class="edit-box">
                <el-button size="mini" class="default-btn default-btn2" @click="pasteClipboard(scope.row)">粘贴</el-button>
                <el-button size="mini" class="del-btn" type="text" @click="delClipboard(scope.row)">删除</el-button>
              </div>
            </template>
          </el-table-column>
        </el-table>

        <div class="clipboard-footer">
          <el-button size="mini" class="default-btn  default-btn2" @click="pasteClipboard()" :disabled="clipboardStat.data.length <= 0">全部粘贴</el-button>
          <el-button size="mini" class="del-btn" type="text" @click="delClipboard()" :disabled="clipboardStat.data.length <= 0">全部删除</el-button>
        </div>
      </div>
    </transition>

    <!--底部条-->
    <footer class="container-footer clearfix">
      <div class="fl bottom-msg">
        已选<span>{{multipleSelection.length}}</span>项，共<span>{{tableData.length}}</span>项
      </div>
      <div class="fr page-warp">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pageInfo.page"
          :page-sizes="[20, 50]"
          :page-size="pageInfo.pagesize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="count">
        </el-pagination>
      </div>
    </footer>
  </div>
</template>

<script>
  import popIcon from 'com/popIcon/index';

  import search from 'com/search/index';


  import clipboard from '../../../libs/clipboard';

  import utils from '../../../libs/utils';
  import uri from '../../../libs/uri';


  const Q_ZONECODE = 'zoneCode';
  const Q_ZONEID = 'zoneid';
  const Q_BK = 'bk';		/* 是否规档广告 */

  const scrollName = 'scrollName';

  import storage from '../../../libs/storage';

  const raceAdsLsKey = 'ads-race-ids';
  const visualRaceAdsLsKey = 'ads-race-visual_ids';

  export default {
    data() {
      return {
        isShow: false,
        nowImg: '',
        hasChoose: false,
        tableData: [
          // {
          // 	status: false
          // }
        ],

        curZoneId: '',

        isOpenAdv: false,	/* 是否打开高级搜索 */

        maxCopyTotal: 10,
        count: 0,
        bodyLoading: false,
        showDetele: false,
        inVisualPage: false,		/* 是否在可视化列表页面 */
        hasFLPermit: false,			/* 是否有工作流权限 */
        multipleSelection: [],
        // searchBuffer: {
        // 	starttime_begin: '',
        // 	starttime_end: '',
        // 	endtime_begin: '',
        // 	endtime_end: '',
        // 	base_zone_id: '', 		// 广告位基础id
        // 	zone_id: '', 			// 广告位id
        // 	application_chl_id: '', // 父频道
        // 	banner_name: '', 		// 广告名称
        // 	author: '', 			// 创建人
        // 	search_name: '', 		// 关键字
        // 	page: 1,
        // 	pagesize: 20,
        // 	zonecode: uri.query(Q_ZONECODE, true)
        // },

        curSearchInfo: {

        },

        pageInfo: {
          page: 1,
          pagesize: 20,
          zonecode: null,
          zoneId: null,
          bk: null	 /* 是否规档广告 */
        },

        clipboardStat: {				// 快速编辑区
          show: false,			// 是否显示
          loading: false,			// 是否显示loading
          data: []				// 当前编辑的数据
        },
        total_banners:0,  // 符合条件的广告记录数
        copyIds: []  // 复制的ids
      };
    },
    computed: {},

    mounted() {

      if (uri.has(Q_ZONECODE, true)) {
        this.inVisualPage = true;
        this.pageInfo.zonecode = uri.query(Q_ZONECODE, true);

        this.getFLSettings();

      } else if (uri.query(Q_ZONEID, true)) {
        this.pageInfo.zoneId = uri.query(Q_ZONEID, true);
        this.curZoneId = this.pageInfo.zoneId;
      } else if (uri.query(Q_BK, true)) {
        this.pageInfo.bk = uri.query(Q_BK, true);
      } else {

      }
      this.updateClipboard();

      this.getList();

      // console.log('list ..................');
      window.$list = this;
    },

    updated() {
      // console.log('updated list ..................');
      this.$wfire(scrollName, 1);
    },

    methods: {
      // 获取图片路径
      getImg(name) {
        return this.$URL.getImgUrl() + name;
      },
      // 显示tag类型
      getIntroduct(val) {
        var type = parseInt(val);
        switch (type) {
          case 1: 	//'工作流广告'
            return 'success';
          case -1: 	//'可视化广告'
            return 'primary';
          case 0: 	//'普通广告'
          default:
            return 'info';
        }
      },

      getFLSettings() {
        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getFLSettings')
        }).then(result => {
          if (result.status == 200 && result.data && result.data.is_permit) {
            this.hasFLPermit = true;
                  }
        }, result => {

        });
      },

      // 获取列表
      getList(fromSearch) {

        this.bodyLoading = true;

        var paramObj = {};
        paramObj.starttime_begin = utils.strDate(this.curSearchInfo.startTimeBegin);
        paramObj.starttime_end = utils.strDate(this.curSearchInfo.startTimeEnd);
        paramObj.endtime_begin = utils.strDate(this.curSearchInfo.endTimeBegin);
        paramObj.endtime_end = utils.strDate(this.curSearchInfo.endTimeEnd);
        // paramObj.base_zone_id = this.curSearchInfo.base_zone_id; 		// 广告位基础id 用于获取zone_id
        paramObj.zone_id = this.curSearchInfo.zoneId; 			// 广告位id
        paramObj.application_id = this.curSearchInfo.applicationId; // 父频道
        paramObj.banner_name = this.curSearchInfo.bannerName; 		// 广告名称
        paramObj.author = this.curSearchInfo.author; 			// 创建人
        paramObj.search_name = this.curSearchInfo.keyName; 		// 关键字
        // paramObj.banner_id = this.curSearchInfo.banner_id;
        paramObj.banner_id_begin = this.curSearchInfo.bannerIdBegin;
        paramObj.banner_id_end = this.curSearchInfo.bannerIdEnd;
        paramObj.page = fromSearch ? 1 : this.pageInfo.page;
        paramObj.pagesize = this.pageInfo.pagesize;
        paramObj.zonecode = this.pageInfo.zonecode;

        if (this.pageInfo.zoneId) {		/* 是否从广告位列表进来, 因为广告位列表进来，这个是斩不开放高级搜索 */
          paramObj.zone_id = this.pageInfo.zoneId;
        }

        paramObj.bk = this.pageInfo.bk;

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('adsList'),
          params: paramObj
        }).then(result => {

          this.bodyLoading = false;

          if (result.status == 200) {

            var resData = result.data;

            this.tableData = resData.map(row => {
              row.status = (!!row.status);
              row.isRacing = (row.racing_id !== '0');
              row.isPersonal = +row.personal_id !== 0;
              return row;
            });
            this.tableData = resData;
            this.count = Number(result.total) * Number(this.pageInfo.pagesize);
            if (fromSearch) {
              this.pageInfo.page = 1;
            }
            this.total_banners = result.total_banners;
          } else {
            console.log(result.msg);
          }
          // setTimeout(function(){this.isRotate = false;},2000);
        }, result => {
          this.bodyLoading = false;
          console.log(result.msg);
        });

      },
      // 多选触发函数
      handleSelectionChange(val) {
        this.multipleSelection = val;

        if (this.multipleSelection.length > 0) {
          this.hasChoose = true;
        } else {
          this.hasChoose = false;
        }
      },
      handleSizeChange(val) {
        if (this.pageInfo.pagesize !== val) {
          this.pageInfo.pagesize = val;
          this.getList();
        }
      },
      //	分页触发函数
      handleCurrentChange(val) {
        this.pageInfo.page = val;
        this.getList();
      },
      //	显示奇偶行样式{row, rowIndex}
      tableRowClassName(info) {
        // console.log(arguments);
        if (info.rowIndex % 2 !== 0) {
          return 'info-row';
        }
        return '';
      },
      //	广告状态显示
      tableRowType(state) {
        if (state && state === 1) {
          return 'circle-check';
        } else if (state === 2) {
          return 'time';
        } else {
          return 'circle-close';
        }
      },
      //	放大图片
      popImg(val, id) {
        if (id !== 0) {
          let obj = this.tableData.find(s => {
            return s.id === id;
          });
          this.nowImg = obj.imageurl;
        }
        this.clipboardStat.show = false;
        this.isShow = val;
      },
      // 改变状态列表
      showStateList(row) {
        row.hasList = !row.hasList;
      },
      //	改变状态
      changeState(row) {
        var val = row.status;
        this.$API({
          method: 'get',
          url: this.$URL.getUrl('updateStatus'),
          params: {
            id: row.id,
            status: val
          }
        }).then(result => {
          row.hasList = false;
          if (result.status == 200) {
            var msg, type;
            if (val) {
              msg = '广告已重新打开';
              type = 'success';
            } else {
              msg = '广告已关闭，不会在线上生效';
              type = 'warning';
            }
            this.$toast({
              'title': msg,
              'type': type
            });
          } else {
            row.status = (!row.status);
            var msg = '状态' + (val ? '开启' : '关闭') + '失败';
            this.$toast({
              title: (result.msg ? result.msg : msg),
              type: 'warning',
              duration: 2000
            });
          }
        }, result => {
          row.hasList = false;
          row.status = (!row.status);
          var msg = '状态' + (val ? '开启' : '关闭') + '失败';
          this.$toast({
            title: msg,
            type: 'warning',
            duration: 2000
          });
        });
      },


      handleSearch(searchInfo) {
        // console.log('searchInfo-----------:', searchInfo);
        this.curSearchInfo = searchInfo;
        // this.searchInfo = searchInfo;
        // console.log(searchInfo);
        this.pageInfo.page = 1;
        this.getList(true);
      },

      handleAdvUi(isOpen) {
        this.isOpenAdv = isOpen;
      },

      // 复制
      copyRow() {
        if (this.hasChoose) {
          if (this.multipleSelection.length <= 10) {
            var url;
            for (let i = 0; i < this.multipleSelection.length; i++) {
              var row = this.multipleSelection[i];
              if (row.introduct_id == -1) {	// '可视化广告'
                url = '/index.php?c=banners&m=redirect_form&model=banners&isAuth=true&id=' + row.id + '&op=copy';
              } else {
                url = '/index.php?c=banners&m=form&op=copy&isAuth=true&model=banners&id=' + row.id;
              }

              var limitSizeRatio = this.getRatio();
              if (limitSizeRatio) {
                url += '&limitsizeratio=' + limitSizeRatio;
              }
              window.open(url, '_blank');
            }

          } else {
            this.$toast({
              title: '只能选择10行要复制的数据。',
              type: 'warning'
            });
          }
        }
        this.$refs.multipleTable.clearSelection();
      },

      /* 复制到剪切板 */
      copyToClipboard() {
        if (this.multipleSelection.length > 0) {
          console.log(this.multipleSelection);
          if (clipboard.add(this.multipleSelection)) {
            this.$toast({
              title: '复制成功，请在剪切板查看',
              type: 'success'
            });
          } else {
            this.$toast({
              title: '剪切板的上限为10个，目前已超过上限，请先清理剪切板',
              type: 'warning'
            });
          }
        } else {
          this.$toast({
            title: '请选择要复制到剪切板的广告',
            type: 'warning'
          });
        }

        this.updateClipboard();
        this.$refs.multipleTable.clearSelection();
      },

      addRow() {
        var url;
        if (this.pageInfo.zonecode) {
          url = '/index.php?c=banners&m=form&model=banners&is_visual=1&zonecode=' + this.pageInfo.zonecode;
        } else {
          url = '/index.php?c=banners&m=form&model=banners&isAuth=true';
        }

        var limitSizeRatio = this.getRatio();
        if (limitSizeRatio) {
          url += '&limitsizeratio=' + limitSizeRatio;
        }
        window.open(url, '_blank');
      },

      addTestRow() {
        var url;
        var limitSizeRatio = this.getRatio();
        if (this.pageInfo.zonecode) {
          // console.log(1)
          url = '/new_ads/dist/#/ads-edit?isVisual=1&zoneCode=' + this.pageInfo.zonecode;
          if (limitSizeRatio) {
            url += '&limitsizeratio=' + limitSizeRatio;
          }
        } else {
          // console.log(2)
          url = '/new_ads/dist/#/ads-edit';
          if (limitSizeRatio) {
            url += '?limitsizeratio=' + limitSizeRatio;
          }
        }
        window.open(url, '_blank');
      },

      openWorkflow() {
        var url = '/new_ads/dist/#/workflow' + '?zoneCode=' + this.pageInfo.zonecode;
              window.open(url);
      },

      addRacing() {
        if (this.hasChoose) {
          if (this.multipleSelection.length <= 10) {
            var raceData = {};
            var racingId = 0;
            var personalId = 0;
            var hasVisual = false;
            var closeId = 0;

            for (let m in this.multipleSelection) {
              var rowData = this.multipleSelection[m];
              raceData[rowData.id] = {introductId: rowData.introduct_id, name: rowData.name};
              if (rowData.isRacing) {
                racingId = rowData.id;
                break;
              }

              if (+rowData.personal_id) {
                personalId = rowData.id;
                break;
              }

              if (!rowData.status) {
                closeId = rowData.id;
                break;
              }

              if (parseInt(rowData.introduct_id) == -1) {
                hasVisual = true;
              }
            }

            if (racingId) {
              this.$message({
                message: '广告(' + racingId + ')已经加入赛马，请重新选择',
                type: 'warning'
              });
              return;
            }

            if (personalId) {
              this.$message({
                message: '广告(' + personalId + ')已经加入个性化，请重新选择',
                type: 'warning'
              });
              return;
            }

            if (closeId) {
              this.$message({
                message: '广告(' + closeId + ')已经是关闭状态，不能做赛马绑定，请重新选择',
                type: 'warning'
              });
              return;
            }


            if (hasVisual && !this.inVisualPage) {
              this.$message({
                message: '可视化广告赛马，请在可视化投放里设置',
                type: 'warning'
              });
              return;
            }

            // window.localStorage.setItem('ads-race-ids', JSON.stringify(raceData));
            // var url = '/index.php?c=race&m=set_rule';
            // window.open(url, '_blank');
            // var hash = '#/race-settings' + (this.zoneCode ? ('?zoneCode=' + this.zoneCode) + '');
            // 带查询参数，变成 /register?plan=private
            var query = {};
            if (this.inVisualPage) {		/* 来自可视化列表 */
              query.zoneCode = this.pageInfo.zonecode;
              query.fromVisual = 'true';
              // storage.set(visualRaceAdsLsKey, raceData, 24 * 3600);
              window.localStorage.setItem(visualRaceAdsLsKey, JSON.stringify(raceData));	/* 因为旧系统还在用，所以只能这样写 */
            } else {		/* 来自普通广告列表 */
              // storage.set(raceAdsLsKey, raceData, 24 * 3600);
              window.localStorage.setItem(raceAdsLsKey, JSON.stringify(raceData));		/* 因为旧系统还在用，所以只能这样写 */
            }

            this.$router.push({'path': 'race-settings', 'query': query});

          } else {
            this.$toast({
              title: '只能选择10条广告加入赛马。',
              type: 'warning'
            });
          }
        }
        this.$refs.multipleTable.clearSelection();
      },

      addPersonalGroup () {
        // as same as the race ad.
        const selectedAds = this.multipleSelection;
        if (selectedAds.length <= 10) {
          let checkedIndex = -1;
          const checkList = {
            raceAds: [],
            personalAds: [],
            filedAds: [],
            visibleAds: [],
          };
          const messageMap = (key) => {
            return (adID) => {
              return {
                raceAds: `广告（${ adID }）已经加入赛马，请重新选择！`,
                personalAds: `广告（${ adID }）已经加入个性化，请重新选择！`,
                filedAds: `广告（${ adID }）已经是关闭状态，不能做个性化绑定，请重新选择！`,
                visibleAds: '可视化广告赛马，请在可视化投放里设置！',
              }[key];
            };
          };
          // collect the check info
          selectedAds.forEach(item => {
            checkList.raceAds.push(!!+item.racing_id);
            checkList.personalAds.push(!!+item.personal_id);
            checkList.filedAds.push(!+item.status);
            checkList.visibleAds.push(+item.introduct_id < 0);
          });
          // check selected ads
          for (let key in checkList) {
            if (this.inVisualPage && key === 'visibleAds') {
              continue;
            } else {
              checkedIndex = checkList[key].indexOf(true);
              if (checkedIndex > -1) {
                let adID = selectedAds[checkedIndex].id;
                this.$message({
                  type: 'warning',
                  message: messageMap(key)(adID),
                });
                break;
              }
            }
          }
          // no any porblems to do
          if (checkedIndex < 0) {
            // save ads' info to localstorage
            const storage = window.localStorage;
            if (this.inVisualPage) {
              // TODO, and I don't know the visual page's logic
            } else {
              // TODO, need to confirm
            }
            const key = 'adsInfoForPersonalGroup';
            storage.setItem(key, JSON.stringify(selectedAds));
            this.$router.push({'path': 'personal-content/add'});
          }
        }
        else {
          this.$message({
            type: 'warning',
            message: '只能选择10条广告加入个性化！',
          });
          this.$refs.multipleTable.clearSelection();
        }
      },

      delConfirm() {
        if (this.multipleSelection.length <= 1) {
          this.$confirm('确定删除当前所选中的' + this.multipleSelection.length + '条广告吗?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.deleteData();
          }).catch(() => {
            // this.$message({
            // 	type: 'info',
            // 	message: '已取消删除'
            // });
          });
        } else {
          this.$alert('为防止误操作，广告删除功能只支持一次删除一个。', '提示', {
            confirmButtonText: '确定'
          });
        }
      },

      // 删除
      deleteData() {
        this.showDetele = false;
        if (this.hasChoose) {
          if (this.multipleSelection.length > 0) {
            this.deleteDataCallback();
          } else {
            this.$toast({
              title: '请勾选要删除的数据。',
              type: 'warning'
            });
          }
        }
      },
      deleteDataCallback() {
        this.bodyLoading = true;
        let arr = [];
        this.multipleSelection.map(s => {
          arr.push(s.id);
        });
        this.$API({
          method: 'post',
          url: this.$URL.getUrl('deleteBanners'),
          params: {
            'id': arr[0],
            'del': 1
          }
        }).then(result => {
          if (result.status == 200) {
            this.getList();
            this.$toast({
              title: '删除成功',
              type: 'success'
            });
          } else {
            this.bodyLoading = false;
            this.$toast({
              title: (result.msg ? result.msg : '删除失败'),
              type: 'warning'
            });
          }
        }, result => {
          this.bodyLoading = false;
          this.$toast({
            title: '删除失败',
            type: 'warning'
          });
        });
      },
      // 显示快速编辑
      clickEdit(row, event) {
        console.log(row);
        if (row.racing_id > 0) {
          this.$alert('这个广告已绑定了赛马，无法进行编辑，请在“赛马分组列表”中找到对应赛马组后，在里面进行编辑。', '提示', {
            confirmButtonText: '确定'
          });
        }
        else if (row.isPersonal) {
          this.$alert('这个广告已绑定了个性化，无法进行编辑，请在“个性化分组列表”中找到对应个性化组后，在里面进行编辑。', '提示', {
            confirmButtonText: '确定'
          });
        }
        else {

          var url;
          if (row.introduct_id == -1) {	// '可视化广告'
            url = '/index.php?c=banners&m=redirect_form&model=banners&isAuth=true&id=' + row.id;
          } else {
            url = '/index.php?c=banners&m=form&model=banners&isAuth=true&id=' + row.id;
          }

          var limitSizeRatio = this.getRatio();
          if (limitSizeRatio) {
            url += '&limitsizeratio=' + limitSizeRatio;
          }
          window.open(url, '_blank');
        }
      },

      updateClipboard() {
        // setTimeout(() => {
        // 	this.clipboardStat.data = clipboard.list();
        // }, 0);
        this.clipboardStat.data = clipboard.list();
      },

      pasteClipboard(row) {

        var idStr = '';
        if (row) {
          idStr = row.id;
        } else {
          var list = this.clipboardStat.data;
          if (list.length <= 0) {
            return;
          }

          list.forEach(function(row) {
            idStr += ',' + row.id;
          });

          idStr = idStr.substr(1);
        }

        this.bodyLoading = true;
        this.$API({
          method: 'get',
          url: this.$URL.getUrl('pasteBanners'),
          params: {
            'bannerid': idStr,
            'zonecode': this.pageInfo.zonecode
          }
        }).then(result => {
          if (result.status == 200) {
            this.pageInfo.page = 1;
            this.getList();
            this.$toast({
              title: '广告粘贴成功，正在更新列表',
              type: 'success'
            });
          } else {
            this.bodyLoading = false;
            this.$toast({
              title: (result.msg ? result.msg : '广告粘贴失败'),
              type: 'warning'
            });
          }
        }, s => {
          this.bodyLoading = false;
          this.$toast({
            title: '广告粘贴失败',
            type: 'warning'
          });
        });
      },

      delClipboard(row) {
        if (row) {
          clipboard.del(row.id);
          // this.updateClipboard();
          /* 这样写体验好 */
          var rows = this.clipboardStat.data;
          for (var i = 0; i < rows.length; i++) {
            var curRow = rows[i];
            if (curRow['id'] === row.id) {
              rows.splice(i, 1);
              i--;
            }
          }
        } else {
          clipboard.clear();
          this.clipboardStat.data = [];
        }
      },

      // 关闭快速编辑
      hideClipboard() {
        this.clipboardStat.show = false;
      },

      getRatio() {
        var limitSizeRatio = uri.query('limitsizeratio', true);
        var radioReg = /^\d+(\.\d{1,2})?$/;
        if (limitSizeRatio && radioReg.test(limitSizeRatio)) {
          return limitSizeRatio;
        } else {
          return '';
        }
      }

    },
    components: {
      popIcon,
      search
    }
  };
</script>

<style lang="scss">
  $opacity : opacity .5s cubic-bezier(.23,1,.32,1) .1s;
  $transform : transform .3s cubic-bezier(.23,1,.32,1) .1s;

  .el-tooltip__popper {
    max-width: 200px;
    line-height: 20px;
  }

  .container-header .u-search-wrap .u-search-normal.shorten {
    width: 300px;
    /*display: flex;*/
    /*justify-content: center;*/
    /*align-items: center;*/
  }

  .container-header .u-search-wrap .u-search-normal.shorten .el-input-group{
    margin-left: 4px;
  }

  .container-header .u-search-wrap .btn-search-advance{
    color: #6B6B6B;
    /*margin-left: 16px;*/
  }

  .ads-list-tips-box {
    /*padding: 10px;*/
    text-indent: left;
    color: #ddd;
    line-height: 20px;
  }

  .ads-list-tips-box a {
    display: block;
    color: #ddd;
  }

  .ads-list-box {

    transition: padding-top 0.3s;

    .default-btn {
      min-width: 95px;
      color: #20a0ff;
        border-color: #20a0ff;

        &:hover {
        background: #4db3ff;
          border-color: #4db3ff;
          color: #fff;
        }
    }

    .default-btn[disabled] {
      color: #e4e4e4;
      border-color: #e4e4e4;
      background: #fff;
    }

    .del-btn {
      color: #6B6B6B !important;
      text-decoration: underline !important;
    }

    .del-btn[disabled] {
      color: #E4E4E4 !important;
      text-decoration: none !important;
    }

    .txt-pointer {
      cursor: pointer;
    }

    .nowrap {
      white-space: nowrap;
    }

    .name-row {
      padding: 10px 0;
    }

    .tip-box {
      overflow : hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
    }

    .tip-default {
      display: block;
      text-align: center;
    }

    .tip-line-box {
      overflow : hidden;
      text-overflow: ellipsis;
      white-space: nowrap;

      .tip-txt {
        display: block;
        overflow : hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        cursor: pointer;
      }
    }

    .ads-button-row {
      position: absolute;
      width: 100%;
      left: 0;
      top: 0;
      padding: 8px 0;

      .row-left {
        text-align:left;
      }
      .row-right {
        text-align:right;
        padding-right: 15px;
      }
      .row-mid {
        padding:0 0 0 15%;
        text-align:left;
        color:#1f2d3d;
        font-size:16px;
        line-height:25px;

        span {
          color:red;
          padding:0 3px;
        }
        .item{
          font-size: 14px;
        }

        .el-badge__content.is-fixed {
          top: 11px;
            right: -7px;
        }
      }
    }

    .list-box {
      padding-top: 50px;
      box-sizing: border-box;
      -webkit-box-sizing: border-box;
      height: 100%;
    }

    .el-tag {
      font-size:13px;
      min-width: 77px;
    }

    .racing-label {
      margin-top: 5px;
      background: #ffcc33;
      border-color: #ffb139;
      color: #ff7107;
    }

    .personal-label {
      margin-top: 5px;
      background-color: #fef0f0;
      border-color: #fbc6c7;
      color: #f9a8a9;
    }


    .row-state {
      margin:0 3px;
      vertical-align:middle;
    }
    .main-el-table {

      width: 100%;
      height: 100%;
      /*border-radius:5px 5px 0 0;*/

      .state-btn-warp {

        position:relative;
        height:82px;

        .state-btn-border {
          border-radius: 10px;
          height:34px;
          position: absolute;
          top: 12px;
          width: 94px;
          margin-left:-47px;
          left: 50%;
          z-index: 3;
          transition: height .5s cubic-bezier(.23,1,.32,1) .1s;

          &:hover {
            border:1px solid #BCBCBC;
          }
        }
        .state-btn-border.border-show{
          height:66px;
        }

        .state-btn{
          cursor:pointer;
          position:absolute;
          top:4px;
          left:0px;
          text-align:center;
          width:100%;
          z-index:2;
          height:27px;
        }

        .state-list {
          top:35px;
          transition: $transform,$opacity;
          width: 77px;
        }
        .fade-leave-active {
          transform:translateY(-26px);
          opacity:0;
        }
        .fade-enter {
          transform:translateY(-26px);
          opacity:0;
        }
        .el-icon-caret-bottom,.el-icon-caret-top{
          vertical-align: middle;
        }
      }

      .info-row {
        background-color: #fcfcfc;

        &:hover {
          background-color: #eff2f7;
        }
      }
      .ad-photo {
        width: 117px;
        height:50px;
        overflow:hidden;
        margin:10px auto;
        position:relative;
        background: rgba(0,0,0,0.4);

        img {
          display:block;
          height:100%;
          pointer-events:none;
          margin:0 auto;
        }

        .ad-cover {
          background: rgba(0, 0, 0, 0.72);
          width:100%;
          height:100%;
          position:absolute;
          top:0px;
          left:0px;
          transition: $opacity;
          opacity:0;
        }
        .ad-view-name {
          position:absolute;
          bottom:0px;
          left:0px;
          width:95%;
          height:22px;
          line-height:23px;
          padding:0 0 0 5%;
          font-weight: 400;
            color: #fff;
            text-align:left;
            overflow:hidden;
            font-size:12px;
          transition: $transform;
          transform:scaleY(0);

        }
        .cover-msg {
          color:#fff;
          font-size:12px;
          transition: $transform,$opacity;
          transform:translateY(5px);
          opacity:0;
        }

        &:hover {
          .ad-cover {
            opacity:1;
          }
          .ad-view-name {
            transform:scaleY(1);
          }
        }
      }
      .ad-name {
        font-size:12px;
        padding:5px 0;
        height:24px;
        overflow:hidden;

        a {
          color:#1f2d3d;

          &:hover {
            color:#1d8ce0
          }
        }
      }
      .el-icon-circle-check {
        color:#00be9b;
        vertical-align:middle;

        &:before{
          font-size:23px;
        }
      }
      .el-icon-circle-close {
        color:#ff413d;
        vertical-align:middle;

        &:before {
          font-size:23px;
        }
      }
      .el-icon-time {
        vertical-align:middle;

        &:before {
          font-size:23px;
        }
      }
      .ad-view-box {
        position:absolute;
        text-align: center;
          width: 100%;
        transition: $transform,$opacity;
        transform:translateY(6px);

        .icon-txt {
          font-size:13px;
          line-height: 16px;
          margin: 0px 0 0 0;
          display: block;
          color:#fff;
          cursor: pointer;
        }

        /*&:hover {
          transform:translateY(0px);

          .cover-msg {
            opacity:1;
            transform:translateY(0px);
          }
        }*/

        .el-icon-view {
          color:#fff;
          vertical-align:middle;
          /*cursor: default;*/
          cursor: pointer;

          &:before {
            font-size:18px;
          }
        }
      }
    }

    .bottom-msg {
      font-size:14px;
      color:#8492A6;
      min-width:15%;

      span {
        color:red;
        padding:0 3px;
      }
    }

    .page-warp {
      padding: 8px 10px 0 0;
      width:50%;
    }
    .el-pagination {
      text-align:right;
      /*padding:10px 0 0 0;*/
    }
    .el-pagination__total {
      display:none;
    }
  }

  .ads-list-adv-box {
    padding-top: 130px !important;
  }

  /*快速编辑*/
  .clipboard-panel {
    width: 700px;
    position: fixed;
    right: 0;
    top: 0;
    padding-top: 40px;
    padding-bottom: 50px;
    height: 100%;
    border: 1px solid #d3dce6;
    border-right: none;
    background-color: white;
    z-index: 1000;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;

    .clipboard-title {
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      height: 40px;
      line-height: 40px;
      text-align: center;
      font-size: 18px;
      font-weight: normal;
      white-space: nowrap;
      color: #666666;
    }

    .clipboard-footer {
      position: absolute;
        width: 100%;
        padding-right: 20px;
        left: 0;
        bottom: 0;
        height: 49px;
        line-height: 46px;
        border-top: 1px solid rgb(239, 242, 246);
        overflow: hidden;
        background-color: #f2f2f2;
        text-align: right;

        box-sizing: border-box;
        -webkit-box-sizing: border-box;;
    }

    .clipboard-close{
      position: absolute;
      left: 20px;
      top: 14px;
      font-size: 16px;
        color: #d3dce6;
      cursor: pointer;
      z-index: 3;

      &:hover {
        color: #58B7FF;
      }
    }

    .clipboard-el-table {
      border-left: none;
      width: 100%;
      height: 100%;
      font-size: 13px;
      line-height: 22px;
      .cell {
        padding-left: 8px;
          padding-right: 8px;
      }
    }

    .col-photo {
        width: 100px;
        height:43px;
        overflow:hidden;
        margin:10px auto;
        position:relative;
        /*background: rgba(0,0,0,0.4);*/

        img {
          display:block;
          height:100%;
          pointer-events:none;
          margin:0 auto;
        }
    }

    .edit-box {
      white-space: nowrap;
      padding-right: 10px;
    }

    .default-btn2 {
      min-width: auto;
    }


    /*loading*/
    .clipboard-loading {
      position: absolute !important;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      width: 100%;
      height: 100%;
      z-index: 5;
    }
  }

  /*右边进入和出去的动画*/
  .rightIn-enter-active,
  .rightIn-leave-active {
    transition: transform .3s ease-in-out;
    }

  .rightIn-enter,
  .rightIn-leave-active {
      transform: translate3d(100%, 0, 0);
    }

  @-webkit-keyframes rotate{
    0%{-webkit-transform:rotate(0deg);}
    100%{-webkit-transform:rotate(180deg);}
  }

</style>