<template>
  <div class="container-box dashboard-box" v-loading="bodyLoading" element-loading-text="拼命加载中">
    <header class="container-header clearfix">
      <div class="top-line-title">
        <el-breadcrumb separator="/" >
          <el-breadcrumb-item >数据看板（Dashboard）</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="tabs-nav clearfix">
        <div v-bind:class="[(curTabIndex == 1) ? 'is-active' : '', 'nav-item']" @click="switchTabs(1)">使用占比</div>
        <div v-bind:class="[(curTabIndex == 2) ? 'is-active' : '', 'nav-item']" @click="switchTabs(2)">提升效果</div>
      </div>
    </header>
    <div class="container-body">
      <div class="tabs-content">
        <div class="tab-panel" v-show="curTabIndex == 1">
          <div class="common-box">
            <h2 class="title">每日</h2>
            <el-radio-group class="cdn-wrap" v-model="curDay" size="small" @change="changeDay()">
              <el-radio-button label="0">今天</el-radio-button>
              <el-radio-button label="-1">昨天</el-radio-button>
              <el-radio-button label="-2">前天</el-radio-button>
            </el-radio-group>
            <div class="stats-box clearfix">
              <dl class="stats-panel" v-for="([prop, label], index) in dayKvMap" :key="index">
                <dt>{{ label }}</dt>
                <dd>
                  <span>{{ dayData[prop] }}</span>
                  <b v-if="+dayData[prop]" @click="exportIds(prop, dayData)">导出ID</b>
                  <b v-else>无数据</b>
                </dd>
              </dl>
            </div>
          </div>
          <div class="common-box">
            <h2 class="title">
              每周
            </h2>
            <el-date-picker
              size="small"
              class="cdn-wrap"
              v-model="curMonth"
              type="month"
              style="width: 120px;"
              placeholder="选择月"
              @change="changeMonth()">
            </el-date-picker>
            <div class="table-box">
              <!--列表层-->
              <el-table
                :data="weekData"
                border
                header-row-class-name="g-table-header"
                cell-class-name="g-table-cell"
              >
                <template v-for="([prop, label], index) in weekKvMap">
                  <!-- clickable column -->
                  <el-table-column
                    v-if="/total$/img.test(prop)"
                    :key="index"
                    :label="label"
                    :prop="prop"
                    align="center"
                    class-name="export-cell"
                  >
                    <template slot-scope="scope">
                      <span>{{ scope.row[prop] }}</span>
                      <b v-if="+scope.row[prop]" @click="exportIds(prop, scope.row)">导出ID</b>
                      <b v-else>无数据</b>
                    </template>
                  </el-table-column>
                  <!-- first column -->
                  <el-table-column
                    v-else-if="'time'===prop"
                    :key="index"
                    :label="label"
                    :prop="prop"
                    width="180"
                    align="center"
                  ></el-table-column>
                  <!-- normal column -->
                  <el-table-column
                    v-else
                    :key="index"
                    :label="label"
                    :prop="prop"
                    align="center"
                  ></el-table-column>
                </template>
              </el-table>
            </div>
          </div>
          <div class="common-box">
            <h2 class="title">
              每月
            </h2>
            <el-date-picker
              size="small"
              class="cdn-wrap"
              v-model="curYear"
              align="right"
              type="year"
              style="width: 120px;"
              placeholder="选择年"
              @change="changeYear()">
            </el-date-picker>
            <div class="table-box">
              <!--列表层-->
              <el-table
                :data="monthData"
                border
                header-row-class-name="g-table-header"
                cell-class-name="g-table-cell"
              >
                <template v-for="([prop, label], index) in monthKvMap">
                  <!-- clickable column -->
                  <el-table-column
                    v-if="/total$/img.test(prop)"
                    :key="index"
                    :label="label"
                    :prop="prop"
                    align="center"
                    class-name="export-cell"
                  >
                    <template slot-scope="scope">
                      <span>{{ scope.row[prop] }}</span>
                      <b v-if="+scope.row[prop]" @click="exportIds(prop, scope.row)">导出ID</b>
                      <b v-else>无数据</b>
                    </template>
                  </el-table-column>
                  <!-- first column -->
                  <el-table-column
                    v-else-if="'name'===prop"
                    :key="index"
                    :label="label"
                    :prop="prop"
                    width="180"
                    align="center"
                  ></el-table-column>
                  <!-- normal column -->
                  <el-table-column
                    v-else
                    :key="index"
                    :label="label"
                    :prop="prop"
                    align="center"
                  ></el-table-column>
                </template>
              </el-table>
            </div>
          </div>
        </div>
        <div class="tab-panel" v-show="curTabIndex == 2">
          <div class="common-box">
            <h2 class="title">条件</h2>
            <div class="settings-row">
              <div class="settings-label">广告类型：</div>
              <div class="settings-cnt">
                <el-radio class="radio" v-model="adsType" label="1">自动赛马</el-radio>
              </div>
            </div>
            <div class="settings-row">
              <div class="settings-label label-small">切换时间：</div>
              <div class="settings-cnt">
                <div class="datetime-box clearfix">
                  <el-date-picker
                    type="datetime"
                    placeholder="选择开始时间"
                    v-model="switchInfo.start"
                    size="small"
                    class="datetime"
                  ></el-date-picker>
                  <span class="to">至</span>
                  <el-date-picker
                    type="datetime"
                    placeholder="选择结束时间"
                    v-model="switchInfo.end"
                    size="small"
                    class="datetime"
                  ></el-date-picker>
                  <el-button type="default" class="check-btn"
                    @click="getRaceData()"
                    size="small"
                  >查询</el-button>
                </div>
              </div>
            </div>
          </div>
          <div class="common-box">
            <h2 class="title">
              数据
            </h2>
            <div class="table-box">
              <!--列表层-->
              <el-table
                :data="raceData"
                border
                header-row-class-name="g-table-header"
                cell-class-name="g-table-cell"
                :row-class-name="isLast"
              >
                <!-- column -->
                <el-table-column
                  label="序号"
                  align="center"
                  prop="index"
                >
                </el-table-column>
                <!-- column -->
                <el-table-column
                  label="赛马分组名"
                  align="center"
                  prop="name"
                >
                </el-table-column>
                <!-- column -->
                <el-table-column
                  label="切换时排名第一的点击率"
                  align="center"
                  prop="highestClickPercent"
                >
                </el-table-column>
                <!-- column -->
                <el-table-column
                  label="切换时排名最后的点击率最低"
                  align="center"
                  prop="lowestClickPercent"
                >
                </el-table-column>
                <!-- column -->
                <el-table-column
                  label="切换时点击率提升值"
                  align="center"
                  prop="upPecent"
                >
                </el-table-column>
                <!-- column -->
                <el-table-column
                  label="切换时销售额提升值"
                  align="center"
                  prop="salesPecent"
                >
                </el-table-column>
              </el-table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--底部条-->
    <!-- <footer class="container-footer clearfix">
      <div class="btn-box">
        <el-button type="primary" class="save-btn" @click="saveSettings()"><strong>保存</strong></el-button>
        <el-button class="cancel-btn" @click="goBack()">取消</el-button>
      </div>
    </footer> -->
  </div>
</template>

<script>
  import * as API from 'newAPI';
  import utils from '@/libs/utils';
  // import storage from '../../libs/storage';
  // window.storage = storage;
  //
  var MODULE_NUM = 3;		/* 这个用于初始化时记录模块加载是否完毕 */
  var curLoadNum = 0;

  export default {
    data() {
      return {

        bodyLoading: false,

        curDay: '0',
        curMonth: utils.strDate(utils.newDate(), 'month'),
        curYear: utils.strDate(utils.newDate(), 'year'),

        isFirstOpenTab2: true,
        curTabIndex: 1,
        adsType: '1',
        switchInfo: {start: '', end: ''},

        kvMap: {
          'total': '在线广告总数',
          'racing_total': '赛马总数',
          'racing_rate': '赛马占比',
          'auto_racing_total': '自动赛马总数',
          'auto_racing_rate': '自动赛马占比',
          'custom_total': '个性化广告总数',
          'custom_rate': '个性化占比',
          'expose_total': '曝光打压总数',
          'expose_rate': '曝光打压占比',
          'pmc_total': 'pmc总数',
          'pmc_rate': 'pmc占比',
          'imgauto_total': '图片自动生成占比',
          'imgauto_rate': '图片自动生成占比',
        },

        dayData: {
          "total": '--',
          "pmcTotal": '--',
          "customTotal": '--',
          "racingTotal": '--',
          "autoRacingTotal": '--',
          "exposeTotal": '--',
          "imgautoTotal": '--',
        },

        weekData: [
              //   {
                // "time": "09月04日-09月10日",
                // "total": 183,
                // "pmcTotal": 8,
                // "pmcRatio": 8,
                // "customTotal": 10,
                // "customRatio": 10,
                // "racingTotal": 5,
                // "racingRatio": 5,
                // "autoRacingTotal": 1,
                // "autoRacingRatio": 1,
                // "exposeTotal": 0,
                // "exposeRatio": 0
              //   }
              ],

        monthData: [
              //   {
                // "name": "1月",
                // "total": 183,
                // "pmcTotal": 8,
                // "pmcRatio": 8,
                // "customTotal": 10,
                // "customRatio": 10,
                // "racingTotal": 5,
                // "racingRatio": 5,
                // "autoRacingTotal": 1,
                // "autoRacingRatio": 1,
                // "exposeTotal": 0,
                // "exposeRatio": 0
              //   }
              ],

        raceData: [
              // {
              // 	"index": 1,
              // 	"name": "我的测试赛马",             //赛马名字
              // 	"highestClickPercent": "80",        //最高点击率
              // 	"lowestClickPercent": "0.9009",     //最低点击率
              // 	"upPecent": 79                    //点击提升率
              // 	"salesPecent": 79                    //切换时销售额提升值
              // }
              ]
      };
    },

    computed: {
      dayKvMap () {
        var kvMap = JSON.parse(JSON.stringify(this.kvMap));
        for (var key in kvMap) {
          /rate$/img.test(key) && (delete kvMap[key]);
        }
        return Object.entries(kvMap);
      },
      weekKvMap () {
        return Object.entries(Object.assign({
          'time': '周期',
        }, this.kvMap));
      },
      monthKvMap () {
        return Object.entries(Object.assign({
          'name': '月份',
        }, this.kvMap));
      },
    },

    mounted() {
      // var d = utils.newDate();
      // this.curDay = '0';
      // this.curMonth = utils.strDate(d, 'month');
      // this.curYear = utils.strDate(d, 'year');
      curLoadNum = 0;

      this.bodyLoading = true;
      this.changeDay();
      this.changeMonth();
      this.changeYear();

      this.switchInfo.start = utils.firstDate();
      this.switchInfo.end = new Date();
      // console.log('this.switchInfo', this.switchInfo);
    },
    methods: {

      openLoading() {
        if (curLoadNum >= MODULE_NUM) {
          this.bodyLoading = true;
        }
      },

      closeLoading() {

        curLoadNum++;

        if (curLoadNum >= MODULE_NUM) {
          this.bodyLoading = false;
        }
      },

      switchTabs(index) {
        if (this.curTabIndex != index) {
          this.curTabIndex = index;
          if (this.curTabIndex == 2 && this.isFirstOpenTab2) {
            this.isFirstOpenTab2 = false;
            this.getRaceData();
          }
        }
      },

      changeDay() {
        var curDay = parseInt(this.curDay);
        var d = utils.newDate(curDay);
        var dateStr = utils.strDate(d, 'date');
        console.log(dateStr);

        this.openLoading();

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('viewDashboardDay'),
          params: {
            'day': dateStr
          }
        }).then(result => {

          this.closeLoading();

          if (result.status == 200 && result.data) {
            var resultData = result.data;
            var dayData = {};

            for (var key in resultData) {
              dayData[key] = resultData[key];
            }

            this.dayData = dayData;

          } else if (result.status == 302) {
            this.goLogin();
          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取信息失败.',
              type: 'warning'
            });
          }
        }, result => {
          this.closeLoading();
          this.$toast({
            title: '获取信息失败！',
            type: 'warning'
          });
        });
      },

      changeMonth() {
        var monthStr = utils.strDate(this.curMonth, 'month');
        console.log(monthStr);

        this.openLoading();

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('viewDashboardMonth'),
          params: {
            'month': monthStr
          }
        }).then(result => {

          this.closeLoading();

          if (result.status == 200 && result.data) {

            var weekDataList = [];

            var list = result.data;

            list.forEach(function(item) {
              var rowInfo = {};

              rowInfo['time'] = item.begin_time + '-' + item.end_time;

              for (var key in item.data) {
                rowInfo[key] = item.data[key];
              }

              weekDataList.push(rowInfo);
            });


            console.log(weekDataList);
            this.weekData = weekDataList;

          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取信息失败.',
              type: 'warning'
            });
          }
        }, result => {
          this.closeLoading();
          this.$toast({
            title: '获取信息失败！',
            type: 'warning'
          });
        });

      },

      changeYear() {
        var yearStr = utils.strDate(this.curYear, 'year');
        console.log(yearStr);

        this.openLoading();

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('viewDashboardYear'),
          params: {
            'year': yearStr
          }
        }).then(result => {

          this.closeLoading();

          if (result.status == 200 && result.data) {

            var monthDataList = [];

            var list = result.data;
            list.forEach(function(item) {
              var rowInfo = {};

              rowInfo['name'] = item.name;

              for (var key in item.data) {
                rowInfo[key] = item.data[key];
              }

              monthDataList.push(rowInfo);
            });

            this.monthData = monthDataList;

          } else {
            this.$toast({
              title: result.msg ? result.msg : '获取信息失败.',
              type: 'warning'
            });
          }
        }, result => {
          this.closeLoading();
          this.$toast({
            title: '获取信息失败！',
            type: 'warning'
          });
        });
      },

      getRaceData() {
        // console.log(this.switchInfo);

        var start = this.switchInfo.start;
        if (start) {
          start = Math.floor(start.getTime()/1000);
        } else {
          this.$toast({
            title: ('请选择切换时间的开始时间'),
            type: 'warning'
          });
          return;
        }

        var end = this.switchInfo.end;
        if (end) {
          end = Math.floor(end.getTime()/1000);
        } else {
          this.$toast({
            title: ('请选择切换时间的结束时间'),
            type: 'warning'
          });
          return;
        }

        // console.log("start, end", start, end);

        if (end <= start) {
          this.$toast({
            title: ('切换时间的开始时间必须要大于结束时间'),
            type: 'warning'
          });
          return;
        }


        this.openLoading();

        this.raceData = [];

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getRacingSwitchRecord'),
          params: {
            'start_time': start,
            'end_time': end
          }
        }).then(result => {

          this.closeLoading();

          if (result.status == 200 && result.data && result.data.list) {

            var raceData = [];

            var recordData = result.data;
            var list = recordData.list;
            list.forEach(function(item, index) {
              var rowInfo = {};
              rowInfo["index"] = index + 1 + '';
              rowInfo["name"] = item.name;
              rowInfo["highestClickPercent"] = item.highest_click_percent + '%';
              rowInfo["lowestClickPercent"] = item.lowest_click_percent + '%';
              rowInfo["upPecent"] = item.upPecent + '%';
              rowInfo["salesPecent"] = item.upSalesPecent + '%';

              raceData.push(rowInfo);
            });

            if (list.length > 0) {
              //加上平均行
              var rowInfo = {};
              rowInfo["index"] = '平均';
              rowInfo["isLast"] = 1;
              rowInfo["name"] = '';
              rowInfo["highestClickPercent"] = recordData.avarage_highest_click_percent + '%';
              rowInfo["lowestClickPercent"] = recordData.avarage_lowest_click_percent + '%';
              rowInfo["upPecent"] = '' + recordData.avarage_click_percent + '%';
              rowInfo["salesPecent"] = recordData.avarage_sales_percent + '%';
              raceData.push(rowInfo);
            }

            this.raceData = raceData;

          } else if (result.status == 202) {
            this.raceData = [];
            this.$toast({
              title: result.msg ? result.msg : '获取信息失败.',
              type: 'warning'
            });
          } else {
            this.raceData = [];
            this.$toast({
              title: result.msg ? result.msg : '获取信息失败.',
              type: 'warning'
            });
          }
        }, result => {
          this.closeLoading();
          this.$toast({
            title: '获取信息失败！',
            type: 'warning'
          });
        });


      },

      //	显示奇偶行样式{row, rowIndex}
      isLast(info) {
        // console.log(arguments);
        if (info.row.isLast) {
          return 'is-last';
        }
        return '';
      },

      goLogin() {
        var url = 'https://cas.oa.vipshop.com:8443/login?service=' + encodeURIComponent(window.location.href);
        window.location.href=url;
      },

      exportIds (typeStr, row) {
        const startTimestamp = row.start_timestamp;
        const endTimestamp = row.end_timestamp;
        if (typeStr !== 'total') {
          let typeArr = typeStr.split('_');
          typeStr = typeArr.splice(0, typeArr.length - 1).join('_');
        }
        const url = API.dashboard.exportIds() + `&type=${typeStr}&start_timestamp=${startTimestamp}&end_timestamp=${endTimestamp}`;
        window.open(url);
      },
    }
  };
</script>

<style lang="scss">
  .dashboard-box {

    .tabs-nav {
      position: absolute;
      bottom: -1px;
      left: 50%;
      margin-left: -118px;
      z-index: 901;

      .nav-item {
        float: left;
        width: 118px;
        line-height: 40px;
        border: 1px solid transparent;
        transition: all .3s cubic-bezier(.645,.045,.355,1);
        color: #8391a5;
        text-align: center;
        cursor: pointer;
        user-select: none;
      }

      .nav-item.is-active {
        border: 1px solid #e0e6ed;
          border-bottom-color: #fff;
          border-radius: 4px 4px 0 0;
          color: #20a0ff;
          cursor: default;
      }
    }

    .settings-row {
      position: relative;
      margin: 25px 50px 0 auto;
      padding: 0 0 0 150px;
    }

    .settings-label {
      position: absolute;
      left: 0;
      top: 0;
      width: 140px;
      text-align: right;

    }

    .label-small {
      line-height: 30px;
    }

    .datetime-box {
      .datetime {
        float: left;
      }

      .to {
        float: left;
        line-height: 30px;
        margin: 0 12px;
      }

      .check-btn {
        margin-left: 25px;
        width: 76px;
      }
    }

    .settings-cnt {
    }

    .common-box {
      position: relative;
      margin-top: 50px;
    }

    .common-box:first-child {

      margin-top: 20px;
    }

    .stats-box {
      margin: 20px 14px 0 14px;
    }

    .table-box {
      margin: 20px 20px 0 20px;

      .export-cell {
        b {
          display: none;
          font-weight: normal;
          color: #1E90FF;
          cursor: pointer;
        }

        &:hover {
          span {
            display: none;
          }

          b {
            display: block;
          }
        }
      }
    }

    .cdn-wrap {
      position: absolute;
      top: 2px;
      right: 22px;
    }

    .is-last {
      color: #fc0;;
    }

    $panelNum: 6;
    .stats-panel {
      margin: 0;
      padding: 0;
      text-align: center;
      display: inline;
      float: left;
      width: (100.0/$panelNum) + '%';

      $borderColor: #eff2f7;
      dt {
        display: block;
        margin: 0 6px;
        padding: 0 5px;
        background: #eff2f7;
        line-height: 40px;
        height: 38px;
        white-space: nowrap;
        color: #666666;
        border-right: 1px solid $borderColor;
        border-top: 1px solid $borderColor;
        border-left: 1px solid $borderColor;
      }

      dd {
        display: block;
        margin: 0 6px;
        padding: 0;
        line-height: 40px;
        font-size: 26px;
        color: #fc0;
        border-right: 1px solid $borderColor;
        border-bottom: 1px solid $borderColor;
        border-left: 1px solid $borderColor;

        b {
          display: none;
          font-size: 14px;
          color: #1E90FF;
          cursor: pointer;
        }

        &:hover {
          span {
            display: none;
          }

          b {
            display: block;
          }
        }
      }
    }

    .stats-panel:last-child {
      margin-right: -$panelNum + px;
    }



    .title {
      margin: 0 auto 0 auto;
      border-left: 4px solid #666;
      padding-left: 10px;
      text-align: left;
      line-height: 27px;
      font-size: 24px;
      font-weight: normal;
      color: #666;
    }



  }

</style>