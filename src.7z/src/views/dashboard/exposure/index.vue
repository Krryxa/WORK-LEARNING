<template>
  <section class="wrapper">
    <header class="header">
      <span class="title">曝光打压数据查询（Alpha版本）</span>
    </header>
    <main class="main">
      <section class="section">
        <el-form class="form" :model="adIdForm" ref="adIdForm" :rules="rules" label-width="80px" label-position="right" size="small">
          <section>
            <h1>原广告</h1>
            <p>（即权重最高的广告ID，且数据的时间维度以此广告的开始结束时间为准）</p>
            <el-form-item label="广告ID：" prop="originalAdId">
              <el-input v-model="adIdForm.originalAdId" placeholder="请填入广告ID"></el-input>
            </el-form-item>
          </section>
          <section>
            <h1>新广告</h1>
            <p>（即权重较低的广告ID，如有多个请填写多个广告ID，可乱序）</p>
            <section>
              <el-form-item class="reset" label="广告ID：" prop="newAdId">
                <el-input v-model="adIdForm.newAdId" placeholder="请填入广告ID"></el-input>
              </el-form-item>
              <el-button class="circle" type="primary" icon="el-icon-plus" @click="addNewId"></el-button>
            </section>
            <section v-for="(adId, index) in adIdForm.newAdIds" :key="index">
              <el-form-item label="广告ID：">
                <el-input v-model="adIdForm.newAdIds[index]" placeholder="请填入广告ID"></el-input>
              </el-form-item>
              <el-button class="circle" type="danger" icon="el-icon-minus" @click="removeNewId(index)"></el-button>
            </section>
          </section>
          <el-form-item>
            <el-button type="primary" @click="submitForm('adIdForm')">查阅并显示数据</el-button>
            <el-button @click="resetForm('ruleForm')">取消</el-button>
          </el-form-item>
        </el-form>
      </section>
      <section class="section">
        <h1>数据汇总</h1>
        <el-table :data="dashboardData" border stripe>
          <el-table-column
            v-for="(fileds, index) in tableFileds"
            :key="index"
            :prop="fileds[0]"
            :label="fileds[1]">
          </el-table-column>
        </el-table>
        <el-form class="form" label-width="80px" label-position="right" size="small">
          <el-form-item>
            <el-button @click="exportData" :disabled="isExportButtonDisabled">导出Excel</el-button>
            <el-button @click="linkToWiki">数据计算逻辑说明</el-button>
          </el-form-item>
        </el-form>
      </section>
    </main>
  </section>
</template>

<script>
import * as API from 'newAPI';

export default {
  data () {
    const inputRules = [
      { required: true, message: '请填入广告ID', trigger: 'blur' },
      // { type: 'number', message: '请输入正确的广告ID', trigger: ['blur', 'change'] },
    ];
    return {
      adIdForm: {
        originalAdId: '',
        newAdId: '',
        newAdIds: [],
      },
      rules: {
        originalAdId: inputRules,
        newAdId: inputRules,
      },
      dashboardKvMap: {
        origin_exposePV: '原广告曝光PV',
        new_exposePV: '新广告曝光PV',
        origin_exposeUV: '原广告曝光UV',
        new_exposeUV: '新广告曝光UV',
        origin_clickPV: '原广告点击PV',
        new_clickPV: '新广告点击PV',
        origin_clickUV: '原广告点击UV',
        new_clickUV: '新广告点击UV',
        total_exposePV: '总曝光PV',
        total_exposeUV: '总曝光UV',
        total_clickPV: '总点击PV',
        total_clickUV: '总点击UV',
        expose_click_flow: '曝光打压获取UV流量',
        new_click_rate: '打压后的点击率',
        origin_click_rate: '无打压点击率',
        click_promote_rate: '点击率提升值',
        click_suppress_rate: '广告打压率',
        money_promote_rate: '销售额增幅',
        origin_userCnt: '原广告客户数',
        new_userCnt: '新广告客户数',
        user_promote_rate: '客户转化率提升值',
      },
      dashboardData: []
    }
  },
  computed: {
    newAdIdParam () {
      const newAdIds = [ this.adIdForm.newAdId, ...this.adIdForm.newAdIds ];
      const validAdIds = [];
      newAdIds.forEach(item => {
        item !== '' && validAdIds.push(item);
      });
      return validAdIds.join(',');
    },
    tableFileds () {
      return Object.entries(this.dashboardKvMap);
    },
    isExportButtonDisabled () {
      return !(this.adIdForm.originalAdId && this.newAdIdParam && this.dashboardData.length > 0);
    },
  },
  methods: {
    addNewId () {
      this.adIdForm.newAdIds.push('');
    },
    removeNewId (index) {
      this.adIdForm.newAdIds.splice(index, 1);
    },
    submitForm (formName) {
      this.$refs[formName].validate(async valid => {
        if (valid) {
          const res = await API.dashboard.fetchExposureDatas({
            origin_id: this.adIdForm.originalAdId,
            new_id: this.newAdIdParam,
          });
          if (res.status === 200 && Object.entries(res.data).length > 0) {
            this.dashboardData = [ res.data ];
          } else {
            this.$message.error(res.msg);
          }
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    exportData () {
      const originalAdId = this.adIdForm.originalAdId;
      const newAdIds = this.newAdIdParam;
      const url = API.dashboard.exportExposureUrl() + `&origin_id=${originalAdId}&new_id=${newAdIds}`;
      window.open(url);
    },
    linkToWiki () {
      window.open('http://wiki.corp.vipshop.com/pages/viewpage.action?pageId=388274647');
    }
  }
}
</script>

<style lang="scss">
.wrapper {
  position: relative;
  min-width: 1000px;
  height: 100%;
  margin: 0 auto;

  .header {
    height: 50px;
    border-bottom: 1px solid #DCDFE6;

    &::before {
      content: '';
      width: 1%;
      height: 100%;
      display: inline-block;
      vertical-align: middle;
    }

    .title {
      display: inline-block;
      vertical-align: middle;
    }
  }

  .main {
    position: relative;

    .section {
      border-bottom: 1px solid #DCDFE6;
      padding-bottom: 25px;

      &:last-child {
        border-bottom: none;
      }

      h1 {
        font-size: 24px;
        text-indent: 30px;
        margin-bottom: 5px;
        
        &::before {
          content: '';
          padding-right: 5px;
          margin-right: 5px;
          background-color: #909399;
        }
      }

      p {
        text-indent: 30px;
        color: #909399;
        margin-top: 5px;
      }

      .circle {
        padding: 6px;
        border-radius: 50%;
      }

      .el-form-item {
        display: inline-block;
        width: 60%;
        margin: 10px auto;
        padding-left: 90px;
      }
    }

    .form {
      width: 100%;
      margin: 0 auto;
    }
  }
}
</style>
