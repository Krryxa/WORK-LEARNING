<template>
  <div class="main">
    <el-table
      class="table"
      :data="allGroups"
      height="100%">
      <el-table-column
        prop="id"
        label="分组ID"
        align="center"
        header-align="center"
        width="100">
      </el-table-column>
      <el-table-column
        prop="name"
        label="分组名称"
        align="center"
        header-align="center">
      </el-table-column>
      <el-table-column
        prop="adNames"
        label="广告名"
        align="center"
        header-align="center">
        <template slot-scope="scope">
          <div v-for="(adName, index) in scope.row.adNames" :key="index">{{ adName }}</div>
        </template>
      </el-table-column>
      <el-table-column
        prop="dates"
        label="上下线时间"
        align="center"
        header-align="center">
        <template slot-scope="scope">
          <div v-for="(date, index) in scope.row.dates" :key="index">{{ date }}</div>
        </template>
      </el-table-column>
      <el-table-column
        prop="zoneNames"
        label="广告位"
        align="center"
        header-align="center">
        <template slot-scope="scope">
          <div v-for="(zoneName, index) in scope.row.zoneNames" :key="index">{{ zoneName }}</div>
        </template>
      </el-table-column>
      <el-table-column
        prop="operator"
        label="创建/更新人"
        align="center"
        header-align="center">
      </el-table-column>
      <el-table-column
        label="操作"
        align="center"
        header-align="center">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="primary"
            @click="handleEdit(scope.row.id)">编辑</el-button>
          <el-button
            size="mini"
            type="danger"
            @click="handleDelete({ id: scope.row.id })">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';

export default {
  computed: {
    ...mapGetters([
      'allGroups'
    ]),
  },
  methods: {
    ...mapActions({
      handleDelete: 'deleteGroup',
    }),
    handleEdit (id) {
      this.$router.push({ path: `/personal-content/edit/${ id }` });
    },
  }
};
</script>

<style lang="scss" scoped>
.main {
  position: absolute;
  top: 50px;
  bottom: 65px;
  width: 100%;

  .table {
    height: 100%;
  }
}
</style>
