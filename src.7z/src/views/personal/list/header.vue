<template>
  <el-row type="flex">
    <el-col :span="4" class="title">
      <span>个性化分组列表（{{ total }}）</span>
    </el-col>
    <el-col :span="4" :offset="16">
      <el-input placeholder="搜索分组名称或ID"
        :value="searchContent"
        @change="updateMessage"
        @keyup.enter.native="seachGroupList({ name: searchContent })">
        <el-button slot="append"
          icon="el-icon-search"
          @click="seachGroupList({ name: searchContent })">
        </el-button>
      </el-input>
    </el-col>
  </el-row>
</template>

<script>
import { mapState, mapActions, mapMutations } from 'vuex';

export default {
  computed: {
    ...mapState({
      total: state => state.personalList.total,
      searchContent: state => state.personalList.searchContent,
    }),
  },
  methods: {
    ...mapActions([
      'seachGroupList',
    ]),
    updateMessage (searchContent) {
      this.$store.commit('changeSearchContent', { searchContent });
    },
  }
}
</script>

<style lang="scss" scoped>
.title {
  // the ghost element
  &::before {
    content: '';
    display: inline-block;
    width: 1%;
    height: 100%;
    vertical-align: middle;
  }

  span {
    display: inline-block;
    vertical-align: middle;
  }
}
</style>
