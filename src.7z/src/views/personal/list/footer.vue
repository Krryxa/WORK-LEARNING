<template>
  <div class="footer">
    <el-pagination
      class="pagination"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :page-sizes="[ 20, 30, 40, 50 ]"
      :page-size="pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total">
    </el-pagination>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex';

export default {
  computed: {
    ...mapState({
      total: state => state.personalList.total,
      currentPage: state => state.personalList.currentPage,
      pageSize: state => state.personalList.pageSize,
    }),
  },
  methods: {
    handleSizeChange (pageSize) {
      this.$store.commit('changePageSize', { pageSize: pageSize });
      this.getGroupList();
    },
    handleCurrentChange (currentPage) {
      this.$store.commit('changeCurrentPage', { currentPage: currentPage });
      this.getGroupList();
    },
    ...mapActions([
      'getGroupList'
    ]),
  },
  created () {
    this.getGroupList();
  }
}
</script>

<style lang="scss" scoped>
.footer {
  position: absolute;
  bottom: 20px;
  width: 100%;

  .pagination {
    padding-right: 20px;
    text-align: right;
  }
}
</style>
