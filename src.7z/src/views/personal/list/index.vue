<template>
  <div class="wrapper">
    <ads-header></ads-header>
    <ads-main></ads-main>
    <ads-footer></ads-footer>
  </div>
</template>

<script>
import AdsHeader from './header';
import AdsMain from './main';
import AdsFooter from './footer';

import * as API from 'newAPI';

export default {
  components: {
    AdsHeader, AdsMain, AdsFooter
  },
}
</script>

<style scoped>
.wrapper {
  position: relative;
  height: 100%;
}
</style>
