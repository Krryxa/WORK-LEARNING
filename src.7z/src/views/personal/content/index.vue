<template>
  <div class="wrapper">
    <header class="header">
      <el-breadcrumb class="breadcrumb" separator="/">
        <el-breadcrumb-item :to="{ path: '/personal-list' }">个性化分组列表</el-breadcrumb-item>
        <el-breadcrumb-item>个性化广告</el-breadcrumb-item>
      </el-breadcrumb>
    </header>
    <main class="main">
      <h1>个性化投放</h1>
      <el-form class="form" label-width="120px" label-position="right" size="small">
        <el-form-item label="个性化分组：" required>
          <el-radio-group v-model="groupRadio" :disabled="isNotEditable">
            <el-radio :label="0">新建分组</el-radio>
            <el-radio :label="1">加入到已有分组中</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item>
          <el-input
            v-show="groupRadio === 0"
            v-model="groupName"
            :disabled="isNotEditable"
            placeholder="请填写个性化分组名"></el-input>
          <el-select
            v-if="isVisible"
            v-show="groupRadio === 1"
            v-model="groupIDFromRemote"
            filterable
            remote
            :remote-method="getGroupList"
            @change="handleChangeGroupName"
            placeholder="请选择"
            style="width:100%;">
            <el-option
              v-for="item in groupOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="个性化状态：" required>
          个性化时间：{{ startTime }} -- {{ endTime }}
        </el-form-item>
        <el-form-item>
          <el-table :data="allAds" border>
            <el-table-column
              prop="name"
              label="个性化广告"
              align="center"
              header-align="center">
            </el-table-column>
            <el-table-column
              label="分类标签"
              align="center"
              header-align="center">
              <template slot-scope="scope">
                <el-cascader
                  expand-trigger="hover"
                  :options="scope.row.categoryOptions"
                  v-model="scope.row.category"
                  placeholder="请选择，也可搜索试试"
                  filterable
                  style="width:100%;">
                </el-cascader>
              </template>
            </el-table-column>
            <el-table-column
              label="操作"
              align="center"
              header-align="center"
              width="160">
              <template slot-scope="scope">
                <el-tooltip content="编辑完广告后，请重新【保存】当前个性化组，以便更新同步到个性化组" placement="left">
                  <el-button
                    size="mini"
                    type="primary"
                    @click="handleEditButton(scope.row.id)">编辑</el-button>
                </el-tooltip>
                <el-button
                  size="mini"
                  type="danger"
                  @click="handleDeleteButton(scope.$index)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-form-item>
      </el-form>
    </main>
    <footer class="footer">
      <el-button class="saveButton" type="primary" @click="saveAction">保存</el-button>
      <el-button @click="handleCancleButton">取消</el-button>
    </footer>
  </div>
</template>

<script>
import * as API from 'newAPI';

export default {
  data () {
    return {
      groupInfo: {},
      groupName: '',
      startTime: '',
      endTime: '',
      groupRadio: 0,
      groupIDFromRemote: '',
      groupOptions: [],
      allCategories: [],
      //
      allAdsFromStorage: [],
      prevAds: [],
    }
  },
  computed: {
    isAddState () {
      return /add/i.test(this.$route.path)
    },
    isEditable () {
      return this.isAddState;
    },
    isNotEditable () {
      return !this.isEditable;
    },
    isVisible () {
      return this.isEditable;
    },
    groupID () {
      return this.$route.params.id || 0;
    },
    groupNameFromRemote () {
      let groupName = '';
      for (let item of this.groupOptions) {
        groupName = +item.value === +this.groupIDFromRemote ? item.label : '';
      }
      return groupName;
    },
    allAds () {
      const originAds = this.groupInfo.banners_info || this.allAdsFromStorage;
      const ads = [];
      // first render is `undefined` when initial status, that would have a error
      if (originAds && originAds.length > 0) {
        originAds.forEach(item => {
          ads.push({
            id: item.banner_id || item.id,
            name: item.name || item.apply_name,
            categoryOptions: JSON.parse(JSON.stringify(this.categoryOptions)),
            category: item.category_id ? this.getCascaderPath(item.category_id) : [],
          });
        });
      }
      if (this.isAddState) {
        if (this.groupRadio) {
          ads.push(...this.prevAds);
        } else {
          if (this.prevAds.length > 0) {
            ads.splice(0, +Infinity, ...this.prevAds);
          }
        }
      }
      return ads;
    },
    categoryOptions () {
      const originCategories = this.allCategories;
      let categories = [];
      if (typeof originCategories !== 'undefined') {
        categories = [...this.cascaderOptionsFormat(originCategories)];
      }
      return categories;
    },
    saveParams () {
      return {
        action: this.isAddState ? 'add' : 'edit',
        id: this.isAddState && this.groupRadio ? this.groupIDFromRemote : this.groupID,
        name: this.groupRadio ? this.groupNameFromRemote : this.groupName,
        banner_ids: this.allAds.map(item => item.id).join(','),
        category_ids: this.allAds.map(item => item.category[ item.category.length - 1 ]).join(','),
      };
    },
  },
  watch: {
    groupInfo (curVal) {
      this.groupName = curVal.name;
    },
  },
  methods: {
    cascaderOptionsFormat (originDatas) {
      let catSet = new Set();
      for (let item of originDatas) {
        let cat = {
          label: item.name,
        };
        if (typeof item.children === 'undefined') {
          cat.value = item.category_id;
        } else {
          cat.value = item.name;
          cat.children = this.cascaderOptionsFormat(item.children);
        }
        catSet.add(cat);
      }
      return [...catSet];
    },
    getCascaderPath (id) {
      const cats = this.categoryOptions;
      const path = [];
      let recursion;
      (recursion = (datas, prevNodes = []) => {
        for (let item of datas) {
          prevNodes.push(item.value);
          if (item.value == id) {
            // matched
            path.push(...prevNodes);
            break;
          } else {
            if (item.children) {
              recursion(item.children, JSON.parse(JSON.stringify(prevNodes)));
              prevNodes.pop();
            } else {
              // the tail node
              prevNodes.pop();
              continue;
            }
          }
        }
      })(cats);
      return path;
    },
    checkSaveParams () {
      const saveParams = this.saveParams;
      // check category_ids
      const catIDs = saveParams.category_ids.split(',');
      if (catIDs.indexOf('') >= 0) {
        this.$message({
          type: 'warning',
          message: '分类标签不能为空！',
        });
        return false;
      }
      if (this.isAddState) {
        if (this.groupRadio) {
          // check `id`
          if (!+saveParams.id) {
            this.$message({
              type: 'warning',
              message: '个性化分组名称不能为空！',
            });
            return false;
          }
        } else {
          // check `name`
          if (!saveParams.name) {
            this.$message({
              type: 'warning',
              message: '个性化分组名称不能为空！',
            });
            return false;
          }
          if (this.allAds.length < 2) {
            this.$message({
              type: 'warning',
              message: '至少要2条广告加入个性化！',
            });
            return false;
          }
        }
      }
      return true;
    },
    handleEditButton (id) {
      // redirect api
      window.open(`/index.php?c=banners&m=redirect_form&model=banners&isfrom=personal&isAuth=true&id=${id}`);
    },
    handleDeleteButton (index) {
      const allAds = this.allAds;
      if (allAds.length > 2) {
        allAds.splice(index, 1);
        this.getGroupTime();
      } else {
        this.$message({
          type: 'warning',
          message: '至少要2条广告加入个性化！',
        });
      }
    },
    handleCancleButton () {
      this.$router.push({ path: '/personal-list' });
    },
    async handleChangeGroupName (newGroupID) {
      const res = await API.personalGroup.fetchGroupInfo({ id: newGroupID });
      // save orgin ad
      if (this.prevAds.length === 0) {
        this.prevAds.splice(0, +Infinity, ...this.allAds);
      }
      this.groupInfo = res.data;
      this.getGroupTime();
    },
    async getGroupList (query = '') {
      const params = Object.assign({}, { name: query });
      const res = await API.personalGroup.fetchGroupsList(params);
      this.groupOptions = res.data.map(item => {
        return {
          label: item.name,
          value: item.id,
        };
      });
    },
    async getGroupTime () {
      const ids = this.allAds.map(item => item.id).join(',');
      const res = await API.personalGroup.fetchGroupTime({ ids: ids });
      this.startTime = res.data.start_time;
      this.endTime = res.data.end_time;
    },
    async saveAction () {
      if (this.checkSaveParams()) {
        const res = await API.personalGroup.saveGroupInfo(this.saveParams);
        if (res.status === 200) {
          this.$message({
            type: 'success',
            message: '保存成功！',
          });
          if (this.isAddState) {
            const groupID = res.save_id || 0;
            if (groupID) {
              this.$router.push({ path: `/personal-content/edit/${groupID}` });
            } else {
              this.$router.push({ path: '/personal-list' });
            }
          }
        } else {
          this.$message({
            type: 'error',
            message: res.msg,
          });
        }
      }
    },
    async init () {
      // the add page
      if (/add/i.test(this.$route.path)) {
        // get ads' info from localstorage
        const storage = window.localStorage;
        const key = 'adsInfoForPersonalGroup';
        const adsInfo = JSON.parse(storage.getItem(key));
        this.allAdsFromStorage = [...adsInfo];
        // storage.removeItem(key);
        // fetch datas from remote
        if (this.allAds.length > 1) {
          this.getGroupTime();
        }
        this.getGroupList();
        const categories = await API.personalGroup.fetchCategories();
        this.allCategories = [...categories.data];
      }
      // the edit page
      else {
        const [ groupInfo, categories ] = await this.$axios.all([
          API.personalGroup.fetchGroupInfo({ id: this.groupID }),
          API.personalGroup.fetchCategories(),
        ]);
        this.groupInfo = groupInfo.data;
        this.allCategories = [...categories.data];
        this.getGroupTime();
      }
    }
  },
  // created () {
  //   this.init();
  // },
  beforeRouteEnter (to, from, next) {
    next(vm => {
      vm.init();
    });
  },
}
</script>

<style lang="scss" scoped>
.wrapper {
  position: relative;
  width: 1000px;
  height: 100%;
  margin: 0 auto;

  .header {
    height: 50px;
    border-bottom: 1px solid #DCDFE6;

    &::before {
      content: '';
      display: inline-block;
      width: 1%;
      height: 100%;
      vertical-align: middle;
    }

    .breadcrumb {
      display: inline-block;
      vertical-align: middle;
    }
  }

  .main {
    position: absolute;
    top: 50px;
    bottom: 90px;
    width: 100%;
    overflow: scroll;

    .form {
      width: 90%;
      margin: 0 auto;
    }
  }

  .footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    padding: 10px 0 18px 0;
    border-top: 1px solid #DCDFE6;
    text-align: center;

    .saveButton {
      width: 150px;
    }
  }
}
</style>
