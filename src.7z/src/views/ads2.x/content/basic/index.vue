<template>
  <main class="main">
    <h1>{{ title }}</h1>
    <el-form-item label="广告名称：" prop="name" :required="isRequired">
      <el-input v-model="name" placeholder="建议按规范格式命名（见右侧提示），以便查找和统计数据"></el-input>
    </el-form-item>
    <el-form-item label="上线时间：" prop="period" :required="isRequired">
      <el-date-picker
        v-model="period"
        type="datetimerange"
        range-separator="至"
        start-placeholder="选择开始时间"
        end-placeholder="选择结束始时间(不能超过半年)"
        :default-time="['10:00:00', '10:00:00']">
      </el-date-picker>
    </el-form-item>
    <el-form-item label="频道申请位：" prop="channelApplicationSpace">
      <el-cascader
        ref="channelApplicationSpace"
        :options="channelApplicationSpaceOptions"
        :props="channelApplicationSpaceProps"
        v-model="channelApplicationSpace"
        @focus="handleFocus"
        @change="handleChange"
        filterable
      ></el-cascader>
    </el-form-item>
    <el-form-item label="广告运营位：" prop="adOperationSpace">
      <el-select v-model="adOperationSpace">
        <el-option
          v-for="item in adOperationSpaceOptions"
          :key="item"
          :label="item.label"
          :value="item.value"
        ></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="权重值：" prop="weight">
      <el-input-number
      v-model="weight"
      controls-position="right"
      :min="0"
      :max="20"></el-input-number>
    </el-form-item>
  </main>
</template>

<script>
export default {
  data () {
    return {
      title: '基本信息',
      isRequired: true,
      
      name: '',

      period: '',

      channelApplicationSpace: [],
      channelApplicationSpaceOptions: [
        {
          chl_id: "24",
          chl_name :"Pattyzhou",
          children: [
            {
              id: "273",
              apply_name: "Pattyzhou",
              apply_total: "6"
            },
          ],
        }
      ],
      channelApplicationSpaceProps: {
        label: 'chl_name',
        value: 'chl_id',
        children: 'children',
      },

      adOperationSpace: '',
      adOperationSpaceOptions: [],

      weight: 0,
    }
  },
  methods: {
    handleFocus (event) {
      const isFetch = this.$refs['channelApplicationSpace'].options.length === 0;
      if (isFetch) {
        console.log('fetch application space..');
      } else {
        // nothing to do..
      }
    },
    handleChange (curVal) {
      const oldVal = this.$refs['channelApplicationSpace'].value;
      if (oldVal.join(',') !== curVal.join(',')) {
        console.log('fetch operation space..');
      } else {
        // nothing to do..
      }
    },
  }
}
</script>

<style lang="scss" scoped>
.main {
  position: relative;
  margin-bottom: 80px;

  h1 {
    font-size: 24px;
    text-indent: 30px;
    font-weight: 400;

    &::before {
      content: '';
      padding-right: 5px;
      margin-right: 10px;
      background-color: #909399;
    }
  }
}
</style>
