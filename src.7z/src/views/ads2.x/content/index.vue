<template>
  <section class="wrapper ads2x-content">
    <header class="header">
      <span class="title">广告列表</span>
    </header>
    <main class="main">
      <el-form label-width="160px" size="small">
        <basic></basic>
        <resource></resource>
        <target></target>
        <set-more></set-more>
      </el-form>
    </main>
  </section>
</template>

<script>
import Basic from './Basic';
import Resource from './Resource';
import Target from './Target';
import SetMore from './SetMore';

export default {
  data () {
    return {
      //
    }
  },
  components: {
    Basic, Resource, Target, SetMore,
  },
};
</script>

<style lang="scss">
.ads2x-content {
  &.wrapper {
    position: relative;
    // width: 1000px;
    height: 100%;
    margin: 0 auto;
    overflow-y: scroll;

    .header {
      height: 50px;
      border-bottom: 1px solid #DCDFE6;

      &::before {
        content: '';
        width: 1%;
        height: 100%;
        display: inline-block;
        vertical-align: middle;
      }

      .title {
        display: inline-block;
        vertical-align: middle;
      }
    }

    .main {
      position: relative;
      width: 1000px;
      height: auto;
      margin: 0 auto;
    }
  }
}

</style>
