<template>
  <main class="main">
    <h1>{{ title }}</h1>
    <!-- 分仓 -->
    <el-form-item label="分仓：">
      <el-checkbox-group v-model="warehouse">
        <el-checkbox :label="item.id" v-for="(item,index) in warehousesMock" :key="index">{{item.name}}</el-checkbox>
      </el-checkbox-group>
    </el-form-item>
    <!-- 文字提示 -->
    <el-form-item label="文字提示：">
      <el-row>
        <el-col :span="22">
          <el-input v-model="textTips" placeholder="如为文字广告，请输入文字信息，这里也支持其他场景的文字字段" size="small"></el-input>
        </el-col>
      </el-row>
    </el-form-item>
    <!-- 视频广告URL -->
    <el-form-item label="视频广告URL：">
      <el-row>
        <el-col :span="22">
          <el-input v-model="videoUrl" placeholder="如为动态视频广告，请输入视频URL（只支持腾讯云视频URL）" size="small"></el-input>
          <div class="ads-info-icon cur-pointer"><i class="el-icon-view" @click="clickView"></i></div>
        </el-col>
      </el-row>
    </el-form-item>
    <!-- 启动视频次数 -->
    <el-form-item label="启动视频次数：">
      <el-input-number controls-position="right" size="small" v-model="videoStartupTime" :step="1" :min="0"></el-input-number>
      <span class="number-unit">次</span>
      <el-tooltip placement="right">
        <div slot="content" class="g-ads-tooltip">只用于启动页视频，每个用户最多能看到本广告的次数</div>
        <div class="ads-info-icon"><i class="el-icon-info"></i></div>
      </el-tooltip>
    </el-form-item>
    <!-- 轮播显示时长 -->
    <el-form-item label="轮播显示时长：">
      <el-input-number controls-position="right" size="small" v-model="carouselStopTime" :step="1" :min="0"></el-input-number>
      <span class="number-unit">秒</span>
      <el-tooltip placement="right">
        <div slot="content" class="g-ads-tooltip">轮播广告每帧显示的时长</div>
        <div class="ads-info-icon"><i class="el-icon-info"></i></div>
      </el-tooltip>
    </el-form-item>
    <!-- 白名单 -->
    <el-form-item label="白名单：">
      <el-row>
        <el-col :span="22">
          <el-input type="textarea" :rows="1" v-model="whitelist" placeholder='仅支持mid，可输入最多10个用户mid，用英文逗号 "," 隔开' size="small"></el-input>
          <el-tooltip placement="right">
            <div slot="content" class="g-ads-tooltip">设置白名单后，本广告必然会对白名单用户显示。如只想对白名单用户展示，其他用户不显示，则请在USP人群标签处选择“白名单专用”标签</div>
            <div class="ads-info-icon"><i class="el-icon-info"></i></div>
          </el-tooltip>
        </el-col>
      </el-row>
    </el-form-item>
    <!-- 地区 -->
    <districts></districts>
    <!-- 渠道 -->
    <channel></channel>
    <div class="line200"></div>
  </main>
</template>

<script>
import utils from '@/libs/utils';
import Districts from './Districts';
import Channel from './Channel';

export default {
  data () {
    return {
      title: '更多设置',
      warehouse: [], // 分仓
      textTips: '', // 文字提示
      videoUrl: '', // 视频URL
      videoStartupTime: 0, // 启动视频次数
      carouselStopTime: 4, // 轮播显示时长
      whitelist: '', // 白名单
      // 模拟
      warehousesMock: [
        {
          id: 'VIP_NH',
          name: '南海',
        },
        {
          id: 'VIP_SH',
          name: '上海',
        },
        {
          id: 'VIP_CD',
          name: '成都',
        },
        {
          id: 'VIP_BJ',
          name: '北京',
        },
        {
          id: 'VIP_HZ',
          name: '华中',
        },
      ],
    };
  },
  created () {
    this.getWareHouses();
  },
  methods: {
    // 获取分仓数据
    getWareHouses () {
      // 默认勾选所有数据
      this.warehouse = this.warehousesMock.map(val => val.id);
    },
    // 打开视频链接
    clickView () {
      let url = utils.trim(this.videoUrl);
      if (utils.isUri(url)) {
        window.open(url, '_blank');
      } else {
        this.$toast({
          title: '视频连接格式错误，请重新检查并重新填写正确连接。',
          type: 'warning'
        });
      }
    },
  },
  components: {
    Districts, Channel,
  },
};
</script>

<style lang="scss" scoped>
.line200 {
  height: 500px;
}
.number-unit {
  position: absolute;
  top: 0;
  left: 74px;
  line-height: 32px; 
}
.cur-pointer {
  cursor: pointer;
}
</style>
