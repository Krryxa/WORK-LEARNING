<template>
  <div class="el-transfer-panel district-panel">
    <div class="el-transfer-panel__header">
      <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">{{title}}</el-checkbox>
      <span class="check-number">{{checkedCities.length}}/{{districtListMock.length}}</span>
    </div>
    <div class="el-transfer-panel__body">
      <div class="el-transfer-panel__filter el-input el-input--small el-input--prefix">
        <input type="text" v-model="searchWord" autocomplete="off" placeholder="请输入搜索内容" class="el-input__inner">
        <span class="el-input__prefix"><i class="el-input__icon el-icon-search"></i></span>
      </div>
      <el-checkbox-group v-model="checkedCities" v-if="districtListMock.length > 0" @change="handleCheckedChange">
        <el-checkbox v-for="city in districtListMock" class="el-transfer-panel__item" :label="city.id" :key="city.id">{{city.text}}</el-checkbox>
      </el-checkbox-group>
      <p class="no-data" v-else>无数据</p>
    </div>
    <div class="vip-footer">
      <el-button type="text" :disabled="checkedCities.length > 0 ? false : true" size="small" round>
        <span>{{operation}}</span>
      </el-button>
    </div>
  </div>
</template>

<script>

export default {
  props: {
    title: {
      type: String,
    },
    districtList: { // 父组件传递的区域数据
      type: Array,
    },
    operation: {
      type: String,
    },
  },
  data () {
    return {
      districtListMock: [], // 展示的数据 （搜索会自动修改这个数组）
      checkedCities: [], // 已选择，数据格式：[区域id,id,id...]
      isIndeterminate: false,
      checkAll: false,
      searchWord: '',
      buttonAble: true,
    };
  },
  created () {
    this.getDistrict();
  },
  watch: {
    searchWord (newWord, oldWord) {
      if (newWord === '') {
        // 搜索框为空，重新获取数据
        this.getDistrict();
      } else {
        // 搜索框不为空，就过滤掉数据，保留搜索的数据
        this.districtListMock = this.districtListMock.filter(val => val.text.includes(newWord));
      }
    },
    // 当点击省级或市级，自动监听并更新市级或区级的列表
    districtList () {
      this.getDistrict();
      // 如果区域数据为空，则已选择的数据也要清空
      if (this.districtList.length === 0) {
        this.checkedCities = [];
      }
    },
  },
  methods: {
    // 获取区域数据
    getDistrict () {
      this.districtListMock = this.districtList;
    },
    // 单选
    handleCheckedChange (value) {
      let checkedCount = value.length;
      this.checkAll = checkedCount === this.districtListMock.length;
      this.isIndeterminate = checkedCount > 0 && checkedCount < this.districtListMock.length;
      // 子传父
      this.$emit('check-district', value);
    },
    // 全选
    handleCheckAllChange (val) {
      this.checkedCities = val ? this.districtListMock.map(val => val.id) : [];
      this.isIndeterminate = false;
    },
  },
  components: {
  },
};
</script>

<style lang="scss" scoped>
.district-panel {
  width: 170px;
  .el-checkbox-group {
    height: 191px;
    overflow: auto;
  }
  .check-number {
    position: absolute;
    right: 15px;
    top: 0;
    color: #909399;
    font-size: 12px;
    font-weight: 400;
  }
  .no-data {
    margin: 0;
    height: 30px;
    line-height: 30px;
    padding: 6px 15px 0;
    color: #909399;
    text-align: center;
  }
  .vip-footer {
    position: relative;
    margin: 0;
    padding: 5px 0;
    text-align: center;
    border: 1px solid #ebeef5;
  }
}
</style>
