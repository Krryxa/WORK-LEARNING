<template>
  <div>
    <el-form-item label="地区：">
      <transfer :title="title[0]" :operation="operation[0]" :district-list="provinceList" @check-district="checkProvince"></transfer>
      <transfer :title="title[1]" :operation="operation[1]" :district-list="cityList" @check-district="checkCity"></transfer>
      <transfer :title="title[2]" :operation="operation[2]" :district-list="country"></transfer>
      <span class="inner-center el-icon-d-arrow-right"></span>
      <transfer :title="title[3]" :operation="operation[3]" style="width: 220px" :district-list="selectDistrict"></transfer>
    </el-form-item>
  </div>
</template>

<script>
import Transfer from './Transfer';

export default {
  data () {
    return {
      title: ['省份', '城市', '区域', '选中地区'],
      operation: ['添加选中省份', '添加选中城市', '添加选中区域', '删除选中地区'],
      provinceList: [], // 省级数据
      cityList: [], // 市级数据
      country: [], // 区级数据

      selectDistrict: [], // 选中的区域id数据

      districtListMock: {  // 模拟数据
        "province": {
          "101101": "北京市",
          "101102": "天津市",
          "101103": "河北省",
          "101104": "山西省",
          "101105": "内蒙古自治区",
          "102101": "辽宁省",
          "102102": "吉林省",
        },
        "city": {
          "101101": [
            {
              "id": 101101101112,
               "text": "通州区"
            },                       
            {
              "id": 101101101111,
              "text": "房山区"
            }
          ],
          "101102": [
            {
              "id": 101102101111,
              "text": "西青区"
            },
            {
              "id": 101102101112,
              "text": "津南区"
            }
          ]
        },
        "country": {
          "101101101112": [
            {
              "id": 106105142126,
              "text": "和布克赛尔蒙古自治县"
            },
            {
              "id": 106105142125,
              "text": "裕民县"
            },
          ],
          "101101101111": [
            {
              "id": 106105143124,
              "text": "哈巴河县"
            },
            {
              "id": 106105143125,
              "text": "青河县"
            }
          ]
        },
      },
    };
  },
  created () {
    this.getProvince();
  },
  methods: {
    // 获取省级数据
    getProvince () {
      for (let key in this.districtListMock['province']) {
        this.provinceList.push({
          id: key,
          text: this.districtListMock['province'][key],
        });
      }
    },
    // 获取市级数据，子组件自定义的穿梭框传回的数据，val：[区域id,id,id...]
    checkProvince (val) {
      let id = val[val.length-1];
      let flag = true;
      for (let key in this.districtListMock['city']) {
        if (id === key) {
          // 匹配到的id，将对应的市级数据传递到子组件
          this.cityList = this.districtListMock['city'][key];
          flag = false;
          break;
        }  
      }
      // 如果市级没有匹配到，市级和区级都显示为空
      if (flag) {
        this.cityList = [];
        this.country = [];
      }
    },
    // 获取县级数据，子组件自定义的穿梭框传回的数据，val：[区域id,id,id...]
    checkCity (val) {
      let id = val[val.length-1];
      let flag = true;
      for (let key in this.districtListMock['country']) {
        if (id.toString() === key) {
          // 匹配到的id，将对应的区级数据传递到子组件
          this.country = this.districtListMock['country'][key];
          flag = false;
          break;
        }
      }
      // 区级没有匹配到，显示为空
      if (flag) {
        this.country = [];
      }
    },
  },
  components: {
    Transfer,
  },
};
</script>

<style lang='scss' scoped>
.inner-center {
  margin: 0 5px;
}
</style>
