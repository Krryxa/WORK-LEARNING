<template>
  <div>
    <el-form-item label="渠道：">
      <el-transfer
        filterable
        filter-placeholder="请输入搜索内容"
        v-model="launchingChannels"
        :props="{key: 'id', label: 'name'}"
        :titles="['渠道', '已选中']"
        :data="channelList">
      </el-transfer>
    </el-form-item>
  </div>
</template>

<script>
export default {
  data () {
    return {
      // 传递的数据，选中的渠道
      launchingChannels: [],
      // 展示的数据集合
      channelList: [],
      // mock
      channelMock: [
        {
	      "channel_id": "2",
		  "channel_name": "中华万年历正式版",
		  "channel_tag": ":hq0f7oyc:pfd6xwzt:zhwnl",
		  "author": "冯展宇"
	    }, {
		  "channel_id": "3",
		  "channel_name": "百度",
		  "channel_tag": ":cbadb924:e7d68952:baidu_andorid",
		  "author": "啦啦啦"
        }, {
          "channel_id": "13",
          "channel_name": "安卓市场最终版",
          "channel_tag": "MobileAds:cbadb924:e7d68952:hiapk_andorid",
          "author": "汪龙飞"
        }, {
          "channel_id": "14",
          "channel_name": "百度品专",
          "channel_tag": ":723583e1:eadpo2zj:android",
          "author": "vico"
        },
      ],
    };
  },
  created () {
    this.getChannelList();
  },
  methods: {
    getChannelList () {
      for (let val of this.channelMock) {
        this.channelList.push({
          id: val.channel_tag,
          name: val.channel_name,
        });
      }
    },
  },
  components: {
  },
};
</script>

<style lang='scss' scoped>

</style>
