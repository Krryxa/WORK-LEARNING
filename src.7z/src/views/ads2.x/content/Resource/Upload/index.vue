<template>
  <el-form-item label="上传图片：" class="upload">
    <el-row>
      <el-col :span="12">
        <!-- <el-button type="primary" size="small">批量上传</el-button> -->
        <!-- <span>（图片格式为"jpg/png/gif"，单张不超过450K）</span> -->
        <!-- TODO: 确认批量上传的逻辑 -->
        <el-upload
          ref="batchUpload"
          action="https://jsonplaceholder.typicode.com/posts/"
          :multiple="false"
          :show-file-list="false"
          :before-upload="handleBeforeBatchUpload"
          :on-success="handleBatchUploadSuccess"
          :on-error="handleBatchUploadError">
          <el-button size="small" type="primary" :disabled="isDisabeld">批量上传</el-button>
          <span slot="tip" class="el-upload__tip">（图片格式为"jpg/png/gif"，单张不超过450kb）</span>
        </el-upload>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="22">
        <image-template></image-template>
        <!-- <el-collapse v-model="imageAreas" size="mini">
          <el-collapse-item name="1">
            <template slot="title">
              <header>
                <span>iPhone</span>
              </header>
            </template>
            <main>
              <ul class="list-wrapper">
                <li class="list-cnt">
                  <el-upload
                    class="avatar-uploader"
                    action="https://jsonplaceholder.typicode.com/posts/"
                    :multiple="false"
                    :show-file-list="false"
                    :before-upload="handleBeforeSingleUpload"
                    :on-success="handleSingleUploadSuccess"
                    :on-error="handleSingleUploadError">
                    <img v-if="imageUrl" :src="imageUrl" class="avatar">
                    <template v-else>
                      <i class="el-icon-plus avatar-uploader-icon"></i>
                      <span class="avatar-subtitle">（格式：jpg）</span>
                    </template>
                  </el-upload>
                  <h6 class="ratio-txt">640*960</h6>
                  <section class="icon-cnt">
                    <i class="el-icon-plus icon"></i>
                    <span>（格式：jpg）</span>
                  </section>
                  <h6 class="ratio-txt">640*960</h6>
                </li>
                <li class="list-cnt">
                  <section class="icon-cnt">
                    <i class="el-icon-plus icon"></i>
                    <span>（格式：jpg）</span>
                  </section>
                  <h6 class="ratio-txt">640*960</h6>
                </li>
                <li class="list-cnt">
                  <section class="icon-cnt">
                    <i class="el-icon-plus icon"></i>
                    <span>（格式：jpg）</span>
                  </section>
                  <h6 class="ratio-txt">640*960</h6>
                </li>
                <li class="list-cnt">
                  <section class="icon-cnt">
                    <i class="el-icon-plus icon"></i>
                    <span>（格式：jpg）</span>
                  </section>
                  <h6 class="ratio-txt">640*960</h6>
                </li>
                <li class="list-cnt">
                  <section class="icon-cnt">
                    <i class="el-icon-plus icon"></i>
                    <span>（格式：jpg）</span>
                  </section>
                  <h6 class="ratio-txt">640*960</h6>
                </li>
                <li class="list-cnt">
                  <section class="icon-cnt">
                    <i class="el-icon-plus icon"></i>
                    <span>（格式：jpg）</span>
                  </section>
                  <h6 class="ratio-txt">640*960</h6>
                </li>
              </ul>
            </main>
          </el-collapse-item>
        </el-collapse> -->
      </el-col>
    </el-row>
  </el-form-item>
</template>

<script>
import ImageTemplate from './ImageTemplate';

export default {
  components: {
    ImageTemplate,
  },
  props: {
    hasShownOperationFunctionItem: {
      type: Boolean,
      required: true,
    },
    operationFunction: {
      type: String,
      required: true,
    },
  },
  data () {
    return {
      // TODO
    };
  },
  computed: {
    isDisabeld () {
      return this.hasShownOperationFunctionItem && +this.operationFunction === 1;
    },
  },
  methods: {
    handleBeforeBatchUpload (file) {
      // TODO
      console.log(file);
    },
    handleBatchUploadSuccess (res, file, fileList) {
      console.log(res);
      console.log(file);
      console.log(fileList);
    },
    handleBatchUploadError (err, file, fileList) {
      console.log(err);
      console.log(file);
      console.log(fileList);
    },
    // handleBeforeSingleUpload (file) {
    //   console.log(file);
    // },
    // handleSingleUploadSuccess (res, file, fileList) {
    //   console.log(res);
    //   console.log(file);
    //   console.log(fileList);
    //   this.imageUrl = URL.createObjectURL(file.raw);
    // },
    // handleSingleUploadError (err, file, fileList) {
    //   console.log(err);
    //   console.log(file);
    //   console.log(fileList);
    // },
  }
}
</script>

<style lang="scss">
/*
.ads2x-content {

  .upload {

    .el-collapse {
      border: 1px solid #ebeef5;

      .el-collapse-item__header {
        height: 100%;
      }

      .el-collapse-item__arrow {
        display: none;
      }

      .el-collapse-item__content {
        padding: 0;
      }

      header {
        width: 100%;
        height: 32px;
        line-height: 32px;
        text-indent: 1em;
        background-color: #f9fafc;

        &:hover {
          background-color: #edeff5;
        }
      }

      main {
        .list-wrapper {
          height: 100%;
          padding-left: 15px;
          padding-bottom: 15px;
          margin: 0;
          color: #a7a7a7;
          overflow: hidden;

          .list-cnt {
            float: left;
            width: 120px;
            margin: 15px 15px 0 0;
            list-style: none;
            text-align: center;
            font-size: 12px;
            cursor: pointer;

            .icon-cnt {
              height: 60px;
              border: 1px dashed #e6e6e6;

              .icon {
                display: block;
                margin: 8px auto 2px auto;
                width: 22px;
                height: 22px;
                font-size: 22px;
                color: #838383;
              }

              &:hover {
                background-color: #f5f5f5;
              }
            }

            .ratio-txt {
              margin: 2px 0 0 0;
              font-weight: normal;
              font-size: 13px;
            }

            .avatar-uploader {
              width: 122px;
              height: 62px;

              .el-upload {
                width: 120px;
                height: 60px;
                border: 1px dashed #d9d9d9;
                border-radius: 6px;
                cursor: pointer;
                position: relative;
                overflow: hidden;

                &:hover {
                  border-color: #409EFF;
                }

                .avatar-uploader-icon {
                  font-size: 18px;
                  color: #8c939d;
                  width: 100%;
                  height: 100%;
                  line-height: 45px;
                  text-align: center;
                }

                .avatar-subtitle {
                  display: block;
                  margin-top: -30px;
                  color: #a7a7a7;
                }

                .avatar {
                  position: absolute;
                  max-width: 100%;
                  max-height: 100%;
                  top: 50%;
                  left: 50%;
                  transform: translate(-50%, -50%);
                }
              }
            }

          }
        }
      }
    }
  }
}
*/
</style>
