<template>
  <li class="ratio-template">
    <el-upload
      class="avatar-uploader"
      action="https://jsonplaceholder.typicode.com/posts/"
      :multiple="false"
      :show-file-list="false"
      :before-upload="handleBeforeSingleUpload"
      :on-success="handleSingleUploadSuccess"
      :on-error="handleSingleUploadError">
      <img v-if="url" :src="url" class="avatar">
      <template v-else>
        <i class="el-icon-plus avatar-uploader-icon"></i>
        <span class="avatar-subtitle">（格式：jpg）</span>
      </template>
    </el-upload>
    <h6 class="ratio-txt">{{ ratio }}</h6>
  </li>
</template>

<script>
export default {
  props: {
    ratioId: {
      type: Number,
      required: true,
    }
  },
  data () {
    const self = this;
    return {
      id: self.ratioId,
      ratio: '720*294',
      url: '',
      isDefault: 0,
    };
  },
  methods: {
    handleBeforeSingleUpload (file) {
      console.log(file);
    },
    handleSingleUploadSuccess (res, file, fileList) {
      console.log(res);
      console.log(file);
      console.log(fileList);
      this.url = URL.createObjectURL(file.raw);
    },
    handleSingleUploadError (err, file, fileList) {
      console.log(err);
      console.log(file);
      console.log(fileList);
    },
  }
}
</script>

<style lang="scss">
.ads2x-content {

  .upload {

    .ratio-template {
      float: left;
      width: 120px;
      margin: 15px 15px 0 0;
      list-style: none;
      text-align: center;
      font-size: 12px;
      cursor: pointer;

      .icon-cnt {
        height: 60px;
        border: 1px dashed #e6e6e6;

        .icon {
          display: block;
          margin: 8px auto 2px auto;
          width: 22px;
          height: 22px;
          font-size: 22px;
          color: #838383;
        }

        &:hover {
          background-color: #f5f5f5;
        }
      }

      .ratio-txt {
        margin: 2px 0 0 0;
        font-weight: normal;
        font-size: 13px;
      }

      .avatar-uploader {
        width: 122px;
        height: 62px;

        .el-upload {
          width: 120px;
          height: 60px;
          border: 1px dashed #d9d9d9;
          border-radius: 6px;
          cursor: pointer;
          position: relative;
          overflow: hidden;

          &:hover {
            border-color: #409EFF;
          }

          .avatar-uploader-icon {
            font-size: 18px;
            color: #8c939d;
            width: 100%;
            height: 100%;
            line-height: 45px;
            text-align: center;
          }

          .avatar-subtitle {
            display: block;
            margin-top: -30px;
            color: #a7a7a7;
          }

          .avatar {
            position: absolute;
            max-width: 100%;
            max-height: 100%;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
          }
        }
      }
    }
  }
}
</style>
