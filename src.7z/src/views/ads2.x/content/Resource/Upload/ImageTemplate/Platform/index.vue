<template>
  <el-collapse-item :name="name" class="platform">
    <template slot="title">
      <header>
        <span>{{ name }}</span>
      </header>
    </template>
    <main>
      <ul class="list-wrapper">
        <ratio-template v-for="ratio in ratios" :key="ratio" :ratio-id="ratio"></ratio-template>
      </ul>
    </main>
  </el-collapse-item>
</template>

<script>
import RatioTemplate from './RatioTemplate'

export default {
  components: {
    RatioTemplate,
  },
  props: {
    platform: {
      type: String,
      required: true,
    },
  },
  data () {
    const self = this;
    return {
      id: self.platform,
      name: self.platform,
      ratios: [5, 6, 7, 8],
    };
  },
}
</script>

<style lang="scss">
.ads2x-content {

  .upload {

    .platform {

      .el-collapse-item__header {
        height: 100%;
      }

      .el-collapse-item__arrow {
        display: none;
      }

      .el-collapse-item__content {
        padding: 0;
      }

      header {
        width: 100%;
        height: 32px;
        line-height: 32px;
        text-indent: 1em;
        background-color: #f9fafc;

        &:hover {
          background-color: #edeff5;
        }
      }

      main {

        .list-wrapper {
          height: 100%;
          padding-left: 15px;
          padding-bottom: 15px;
          margin: 0;
          color: #a7a7a7;
          overflow: hidden;
        }
      }
    }
  }
}
</style>
