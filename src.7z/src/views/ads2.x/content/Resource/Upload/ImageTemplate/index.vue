<template>
  <el-collapse v-model="uncollapsed" size="mini" class="image-template">
    <platform v-for="platform in platforms" :key="platform" :platform="platform"></platform>
  </el-collapse>
</template>

<script>
import Platform from './Platform';

export default {
  components: {
    Platform,
  },
  data () {
    return {
      id: '43',
      platforms: ['Android', 'Iphone'],
      uncollapsed: ['Android', 'Iphone'],
    };
  }
}
</script>

<style lang="scss">
.ads2x-content {

  .upload {

    .image-template {
      border: 1px solid #ebeef5;
    }
  }
}
</style>
