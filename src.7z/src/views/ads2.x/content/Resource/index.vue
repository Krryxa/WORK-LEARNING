<template>
  <main class="main">
    <h1>{{ title }}</h1>

    <!-- 跳转类型 -->
    <el-form-item label="跳转到：" prop="linkType" :required="isRequired">
      <el-row>
        <el-col :span="22">
          <el-select v-model="linkType">
            <el-option
              v-for="item in linkTypeOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </el-col>
      </el-row>
    </el-form-item>

    <!-- 红包券设置 -->
    <coupon v-show="hasShownCouponSection"></coupon>

    <!-- 跳转地址 -->
    <el-form-item label="跳转地址：">
      <el-row type="flex" align="middle" class="specific">
        <el-col :span="22">
          <el-input v-model="link" placeholder="请在基本属性填写普通URL链接"></el-input>
        </el-col>
        <el-col :span="1">
          <el-button
            type="primary"
            icon="el-icon-plus"
            size="mini"
            circle
            plain
            @click="handleAddLink"
          ></el-button>
        </el-col>
        <el-col :span="1">
          <el-button type="info" icon="el-icon-view" size="mini" circle plain></el-button>
        </el-col>
      </el-row>
      <el-row type="flex" align="middle" class="specific" v-for="(url, index) in otherLinks" :key="index">
        <el-col :span="22">
          <el-input placeholder="请在基本属性填写普通URL链接" v-model="otherLinks[index]" class="input-with-select">
            <el-select v-model="warehouses[index]" slot="prepend" placeholder="请选择分仓">
              <el-option v-for="item in warehouseOptions" :key="item.value" :label="item.label" :value="item.value"></el-option>
            </el-select>
          </el-input>
        </el-col>
        <el-col :span="1">
          <el-button
            type="danger"
            icon="el-icon-minus"
            size="mini"
            circle
            plain
            @click="handleRemoveLink(index)"
          ></el-button>
        </el-col>
        <el-col :span="1">
          <el-button type="info" icon="el-icon-view" size="mini" circle plain></el-button>
        </el-col>
      </el-row>
    </el-form-item>

    <!-- 广告图模板 -->
    <el-form-item label="广告图模板：">
      <el-row>
        <el-col :span="22">
          <el-select v-model="adTemplate" placeholder="单选，或关键字搜索。（先选模板再上传广告图）">
            <el-option v-for="item in adTemplateOptions" :key="item.value" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-col>
      </el-row>
    </el-form-item>

    <!-- 运营位功能 -->
    <el-form-item label="运营位功能：" v-show="hasShownOperationFunctionItem">
      <el-row>
        <el-col :span="22">
          <el-radio v-model="operationFunction" label="0">不使用</el-radio>
          <el-radio v-model="operationFunction" label="1">图片个性化</el-radio>
          <el-radio v-model="operationFunction" label="2">图片自动生成</el-radio>
        </el-col>
      </el-row>
    </el-form-item>

    <!-- 图片自动化 -->
    <image-automation v-show="hasShownImageAutomationSection"></image-automation>

    <!-- 上传图片 -->
    <upload
      :has-shown-operation-function-item="hasShownOperationFunctionItem"
      :operation-function="operationFunction"
    ></upload>
  </main>
</template>

<script>
import Upload from './Upload';
import ImageAutomation from './ImageAutomation';
import Coupon from './Coupon';

export default {
  components: {
    Upload, ImageAutomation, Coupon,
  },
  data () {
    return {
      title: '链接与图片',
      isRequired: true,

      linkType: '',
      linkTypeOptions: [
        {
          label: '不跳转',
          value: 1,
        },
        {
          label: '领红包跳专题',
          value: 2,
        }
      ],

      link: '',

      otherLinks: [
        'http://www.vip.com',
      ],

      warehouses: [],
      warehouseOptions: [
        {
          label: '南海',
          value: '1',
        },
      ],

      adTemplate: '',
      adTemplateOptions: [
        {
          label: '启动页',
          value: '1',
        },
        {
          label: '运营位多图',
          value: '2',
        }
      ],

      operationFunction: '0',

      // imageArea: ['1', '2'],
    };
  },
  computed: {
    linkTypeDict () {
      const dict = {};
      this.linkTypeOptions.forEach(el => {
        dict[el.value] = el.label;
      });
      return dict;
    },
    adTemplateDict () {
      const dict = {};
      this.adTemplateOptions.forEach(el => {
        dict[el.value] = el.label;
      });
      return dict;
    },
    hasShownCouponSection () {
      return /红包/g.test(this.linkTypeDict[this.linkType]);
    },
    hasShownOperationFunctionItem () {
      return /运营位/g.test(this.adTemplateDict[this.adTemplate]);
    },
    hasShownImageAutomationSection () {
      return this.hasShownOperationFunctionItem && +this.operationFunction === 2;
    },
  },
  methods: {
    handleAddLink () {
      this.otherLinks.push('');
      this.warehouses.push('');
    },
    handleRemoveLink (index) {
      this.otherLinks.splice(index, 1);
      this.warehouses.splice(index, 1);
    }
  },
}
</script>

<style lang="scss">
.ads2x-content {
  .main {
    position: relative;
    margin-bottom: 80px;

    h1 {
      font-size: 24px;
      text-indent: 30px;
      font-weight: 400;

      &::before {
        content: '';
        padding-right: 5px;
        margin-right: 10px;
        background-color: #909399;
      }
    }

    .el-row {
      margin-bottom: 10px;

      .el-col {
        
        .el-select {
          width: 100%;
        }

        .el-input {
          .el-select {
            width: 120px;
          }
        }
      }

      &.specific {
        .el-button {
          display: block;
          margin: 0 auto;
        }
      }

      &:last-child {
        margin-bottom: 0;
      }
    }
  }
}

</style>
