<template>
  <section class="image-automation">
    
    <el-form-item label="图片上的商品来源：">
      <el-row>
        <el-col :span="22">
          <el-radio v-model="imageAutomationConfig.type" label="0">从组货ID获取</el-radio>
          <el-radio v-model="imageAutomationConfig.type" label="1">从107分类树获取</el-radio>
        </el-col>
      </el-row>
    </el-form-item>
    <el-form-item label="组货ID：" v-show="hasShownGroupItem">
       <el-row>
        <el-col :span="22">
          <el-input v-model="imageAutomationConfig.group"></el-input>
        </el-col>
      </el-row>
    </el-form-item>
    <el-form-item label="107分类树三级分类：" v-show="hasShownCategoryItem">
      <el-col :span="22">
        <el-cascader
          ref="category"
          :options="categoryOptions"
          :props="categoryProps"
          v-model="imageAutomationConfig.category"
          @focus="handleCategoryFocus"
          @change="handleCategoryChange"
          filterable
        ></el-cascader>
      </el-col>
    </el-form-item>
    <el-form-item label="图片任务ID：">
      <el-col :span="17">
        <el-input v-model="imageAutomationConfig.pool"></el-input>
      </el-col>
      <el-col :span="1">&nbsp;</el-col>
      <el-col :span="4">
        <el-button type="primary" @click="handleFetchImages">生成默认图/换一换</el-button>
      </el-col>
    </el-form-item>
  </section>
</template>

<script>
export default {
  data () {
    return {
      imageAutomationConfig: {
        type: '1',
        pool: 232,
        category: [],
        group: 4343,
        ratio: 2.4,
      },
      // 辅助
      categoryOptions: [
        {
          name :"水晶",
          category_id: '',
          children: [
            {
              name: "紫色水晶",
              category_id: '',
              children: [
                {
                  category_id: "26149",
                  name: "人造紫色水晶",
                },
              ],
            },
          ],
        }
      ],
      categoryProps: {
        label: 'name',
        value: 'category_id',
      },
    };
  },
  computed: {
    hasShownGroupItem () {
      return !+this.imageAutomationConfig.type;
    },
    hasShownCategoryItem () {
      return +this.imageAutomationConfig.type;
    },
  },
  methods: {
    handleCategoryFocus () {
      // TODO
    },
    handleCategoryChange () {
      // TODO
    },
    handleFetchImages () {
      // TODO
    },
  },
}
</script>

<style lang="scss">
.ads2x-content {

  .image-automation {
    
    .el-cascader {
      width: 100%;
    }

    .el-button {
      width: 100%;
    }
  }
}
</style>
