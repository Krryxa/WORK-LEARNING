<template>
  <el-form-item label="" class="coupon">
    <el-row>
      <el-col :span="22" class="wrapper">
        <el-row class="row">
          <el-col :span="4">红包弹窗图：</el-col>
          <el-col :span="6">
            <section class="avatar-wrapper">
              <el-upload
                class="avatar-uploader"
                action="https://jsonplaceholder.typicode.com/posts/"
                :show-file-list="false"
                :on-success="handleAvatarSuccess"
                :before-upload="beforeAvatarUpload">
                <img v-if="couponConfig.imageUrl" :src="couponConfig.imageUrl" class="avatar">
                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
              </el-upload>
              <h6 class="ratio">560*638</h6>
            </section>
          </el-col>
          <el-col :span="12">
            <el-row>
              <el-col :span="7">左按钮文案：</el-col>
              <el-col :span="17">
                <el-input placeholder="左按钮文案（必填）"></el-input>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="7">中按钮文案：</el-col>
              <el-col :span="17">
                <el-input placeholder="左按钮文案（必填）"></el-input>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="7">右按钮文案：</el-col>
              <el-col :span="17">
                <el-input placeholder="左按钮文案（必填）"></el-input>
              </el-col>
            </el-row>
          </el-col>
          <el-col :span="2"></el-col>
        </el-row>
        <el-row class="row">
          <el-col>
            <el-row>
              <el-col :span="3">红包券：</el-col>
              <el-col :span="19">
                <el-input class="row-input" v-model="couponConfig.info.id" placeholder="券ID（必填）"></el-input>
                <el-input class="row-input" v-model="couponConfig.info.rule" placeholder="规则ID（选填）"></el-input>
                <el-input class="row-input" v-model="couponConfig.info.source" placeholder="来源（必填）"></el-input>
              </el-col>
              <el-col :span="2">
                <el-button
                  type="primary"
                  icon="el-icon-plus"
                  size="mini"
                  circle
                  plain
                  @click="handleAddACoupon"
                ></el-button>
              </el-col>
            </el-row>
            <el-row v-for="(item, index) in couponConfig.moreInfos" :key="index">
              <el-col :span="3">红包券：</el-col>
              <el-col :span="19">
                <el-input class="row-input" v-model="item.id" placeholder="券ID（必填）"></el-input>
                <el-input class="row-input" v-model="item.rule" placeholder="规则ID（选填）"></el-input>
                <el-input class="row-input" v-model="item.source" placeholder="来源（必填）"></el-input>
              </el-col>
              <el-col :span="2">
                <el-button
                  type="danger"
                  icon="el-icon-minus"
                  size="mini"
                  circle
                  plain
                  @click="handleRemoveACoupon(index)"
                ></el-button>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
        <el-row class="row">
          <el-col :span="3">领券后：</el-col>
          <el-col :span="21">
            <el-radio-group v-model="couponConfig.finalState">
              <el-radio :label="0">仍显示此广告</el-radio>
              <el-radio :label="1">不显示此广告</el-radio>
            </el-radio-group>
          </el-col>
        </el-row>
      </el-col>
    </el-row>
  </el-form-item>
</template>

<script>
export default {
  data () {
    return {
      couponConfig: {
        // imageUrl: 'http://b.appsimg.com/upload/dsdmin/2017/11/22/60/15113445596182.png',
        imageUrl: '',
        finalState: 1,
        buttonText: {
          left: '',
          right: '',
          center: '',
        },
        info: {
          id: '22222',
          rule: '2',
          source: '来源于419大促',
        },
        moreInfos: [],
      },
    };
  },
  methods: {
    handleAvatarSuccess () {
      // TODO
    },
    beforeAvatarUpload () {
      // TODO
    },
    handleAddACoupon () {
      // TODO
      const infos = this.couponConfig.moreInfos;
      if (infos.length >= 4) {
        this.$alert('红包最多设置5个~~', '提示', {
          confirmButtonText: '确定',
          type: 'warning',
          showClose: false,
        });
      } else {
        infos.push({
          id: '',
          rule: '',
          source: '',
        });
      }
    },
    handleRemoveACoupon (index) {
      const infos = this.couponConfig.moreInfos;
      infos.splice(index, 1);
    },
  },
}
</script>

<style lang="scss">
.ads2x-content {

  .coupon {

    .wrapper {
      border-radius: 4px;
      border: 1px solid #ebeef5;
      background-color: #f9fafc;

      .row {
        width: 95%;
        margin: 0 auto;
        padding: 10px 5px;
        border-bottom: 1px solid #ebeef5;
        overflow: hidden;

        &:last-child {
          border-bottom: none;
        }

        .avatar-wrapper {
          width: 82px;

          .avatar-uploader {
            height: 106px;

            .el-upload {
              border: 1px dashed #d9d9d9;
              border-radius: 6px;
              cursor: pointer;
              position: relative;
              overflow: hidden;

              &:hover {
                border-color: #409EFF;
              }

              .avatar-uploader-icon {
                font-size: 24px;
                color: #8c939d;
                width: 80px;
                height: 104px;
                line-height: 104px;
                text-align: center;
              }

              .avatar {
                width: 80px;
                height: 104px;
                display: block;
              }
            }
          }

          .ratio {
            margin: 0;
            font-size: 12px;
            font-weight: normal;
            color: #97989B;
            text-align: center;
          }
        }

        .row-input {
          display: inline-block;
          width: 30%;
          margin-right: 10px;
        }
      }
    }
  }

}
</style>
