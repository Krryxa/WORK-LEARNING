<template>
  <section class="wrapper">
    <header class="header">
      <span class="title">分流策略</span>
    </header>
    <main class="main">
      <section v-for="(item, index) in abtestInfo" :key="index">
        <h1>{{ item.abtName }}</h1>
        <el-form class="form" label-width="300px" label-position="right" size="small">
          <el-form-item label="分流策略：">
            <el-switch
              v-model="item.switch"
              active-color="#13ce66"
              inactive-color="#ff4949"
              active-text="开启分流"
              inactive-text="关闭分流">
            </el-switch>
          </el-form-item>
          <div v-show="item.switch">
            <el-form-item label="ABTest分流平台父组别：">
              <el-input v-model="item.parentId"></el-input>
            </el-form-item>
            <el-form-item :label="item.experimentalGroupLabel">
              <el-input v-model="item.experimentalGroup"></el-input>
            </el-form-item>
            <el-form-item :label="item.controlGroupLabel">
              <el-input v-model="item.controlGroup"></el-input>
            </el-form-item>
          </div>
        </el-form>
      </section>
    </main>
    <footer class="footer">
      <el-button type="primary" @click="saveAction">保存</el-button>
    </footer>
  </section>
</template>

<script>
import * as API from 'newAPI';

export default {
  data () {
    return {
      allAbtestInfo: [],
      // switches: [false, false],
      abtestInfo: [],
    };
  },
  computed: {
    saveParams () {
      const paramsMap = {
        switch: 'switch',
        parentId: 'parent_id',
        experimentalGroup: 'experimental_group',
        controlGroup: 'control_group',
        abtType: 'abt_type',
      };
      const abtInfo = this.abtestInfo.map(item => {
        const abtObj = Object.create(Object.prototype);
        for (const [ key, value ] of Object.entries(item)) {
          if (paramsMap[key]) {
            if (key === 'switch') {
              abtObj[paramsMap[key]] = value ? 1 : 0;
            } else {
              abtObj[paramsMap[key]] = value;
            }
          } else {
            continue;
          }
        }
        return abtObj;
      });
      return {
        abt_config: JSON.stringify(abtInfo),
      }
    }
  },
  methods: {
    labelTextFormat (label) {
      return (text) => {
        return {
          experimentalGroupLabel: `实验组（进行${ text }的实验组）：`,
          controlGroupLabel: `对照组（不进行${ text }的默认组）：`,
        }[label];
      };
    },
    async saveAction () {
      const res = await API.abtest.saveInfo(this.saveParams);
      if (+res.status === 200) {
        this.$message({
          message: ' 保存成功！',
          type: 'success',
        });
      } else {
        this.$message({
          message: res.msg,
          type: 'error',
        });
      }
    },
  },
  created () {
    (async () => {
      const res = await API.abtest.fetchInfo();
      if (res.status === 200) {
        this.allAbtestInfo = [...res.data];
        // set form datas
        const labelTexts = ['experimentalGroupLabel', 'controlGroupLabel'];
        this.abtestInfo = this.allAbtestInfo.map((item, index) => {
          const abtObj = Object.create(Object.prototype);
          for (const [ key, value ] of Object.entries(item)) {
            const keys = key.split('_');
            const firstWord = keys.shift();
            const newkeys = keys.map(word => word.replace(word.charAt(0), word.charAt(0).toUpperCase()));
            newkeys.unshift(firstWord);
            abtObj[newkeys.join('')] = value;
          }
          labelTexts.forEach(label => {
            abtObj[label] = this.labelTextFormat(label)(abtObj['abtName']);
          });
          abtObj['switch'] = !!+abtObj['switch'];
          return abtObj;
        });
      } else {
        this.$message({
          message: res.msg,
          type: 'error',
        })
      }
    })()
  }
};
</script>

<style lang="scss" scoped>
.wrapper {
  position: relative;
  width: 1000px;
  height: 100%;
  margin: 0 auto;
  overflow-y: scroll;

  .header {
    height: 50px;
    border-bottom: 1px solid #DCDFE6;

    &::before {
      content: '';
      width: 1%;
      height: 100%;
      display: inline-block;
      vertical-align: middle;
    }

    .title {
      display: inline-block;
      vertical-align: middle;
    }
  }

  .main {
    position: relative;
    margin-bottom: 80px;

    h1 {
      font-size: 24px;
      text-indent: 30px;
      
      &::before {
        content: '';
        padding-right: 5px;
        margin-right: 5px;
        background-color: #909399;
      }
    }

    .form {
      width: 90%;
      margin: 0 auto;
    }
  }

  .footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 50px;
    text-align: center;
  }
}
</style>
