<template>
  <div class="container-box race-settings-box" v-loading="bodyLoading" element-loading-text="拼命加载中">
    <header class="container-header clearfix">
      <div class="top-line-title">
        <el-breadcrumb separator="/" v-if="isEdit">
          <el-breadcrumb-item >赛马分组列表</el-breadcrumb-item>
          <el-breadcrumb-item>赛马广告</el-breadcrumb-item>
        </el-breadcrumb>
        <el-breadcrumb separator="/" v-else-if="curZoneCode">
          <el-breadcrumb-item >可视化列表</el-breadcrumb-item>
          <el-breadcrumb-item>赛马广告</el-breadcrumb-item>
        </el-breadcrumb>
        <el-breadcrumb separator="/" v-else>
          <el-breadcrumb-item >广告列表</el-breadcrumb-item>
          <el-breadcrumb-item>赛马广告</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <!-- <a href="http://appre.vip.vip.com/new/vue-dev/publish/index.html#/index" target="_blank" class="attr-edit-btn data-check-btn">查看赛马数据</a> -->
    </header>

    <div class="container-body">
      <div class="tabs-content">
        <div class="settings-panel">
          <h2 class="title">投放赛马</h2>
          <div class="settings-row">
            <div class="settings-label settings-label-stat"><span class="star">*</span>赛马分组：</div>
            <div class="settings-cnt">
              <div v-show="!curGroupId">
                <template>
                  <el-radio-group v-model="groupType" class="settings-label-stat" @change="changeGroupType()">
                    <el-radio :label="0">新建分组</el-radio>
                    <el-radio :label="1">加入到已有分组</el-radio>
                  </el-radio-group>
                </template>
                <div class="group-name-box" v-show="groupType==0">
                  <el-input v-model="newGroupName" placeholder="请填写赛马新分组名称" size="small"></el-input>
                </div>
                <div class="group-name-box" v-show="groupType!=0">
                  <template>
                    <el-select v-model="selectedGroupId" placeholder="请选择" size="small" class="select" @change="changeGroupList()">
                      <el-option
                        v-for="item in oldGroupList"
                        :label="item.gname"
                        :value="item.gid"
                        :key="item.gid">
                      </el-option>
                    </el-select>
                  </template>
                </div>
              </div>
              <div v-show="curGroupId">
                <div class="group-name-box group-name-box2">
                  <el-input v-model="newGroupName" placeholder="请填写赛马分组名称" size="small" :disabled="true"></el-input>
                </div>
              </div>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-label settings-label-stat"><span class="star">*</span>赛马状态：</div>
            <div class="settings-cnt">
              <div class="race-time-box">
                <span class="time-txt">赛马时间：{{curRaceTime}}</span>
                <div class="attr-box">
                  <!-- <el-button size="small">编辑广告属性</el-button> -->
                  <a :href="adsAttrUrl" target="_blank" class="attr-edit-btn">编辑广告属性</a>
                </div>
              </div>
              <div class="table-box">
                <table class="settings-table">
                  <thead>
                    <tr>
                        <th class="ads-name-td">广告名称</th>
                        <th>初始流量占比</th>
                        <th>操作</th>
                    </tr>
                  </thead>
                  <tbody class="cdn-row-box">
                    <tr v-for="oldAds of oldAdsList" :key="oldAds.adsId">
                      <td>
                        {{oldAds.adsName}}
                      </td>
                      <td>
                        <div class="form-input-box">
                          <template>
                            <el-input-number size="small" v-model="oldAds.originalFlow" :min="0" :max="100"></el-input-number>
                          </template>
                          <span class="percent">%</span>
                        </div>
                      </td>
                      <td>
                        <div class="ads-btn-box">
                          <!-- <el-button type="text" size="small">编辑</el-button> -->
                          <!-- <a :href="createAdsUrl(oldAds)" target="_blank" class="edit-btn">编辑</a> -->
                          <el-tooltip placement="left">
                            <div slot="content">
                              <div class="ads-list-tips-box">
                                <div>编辑完广告后，请重新【保存】当前赛马组，以把更新同步到赛马组</div>
                              </div>
                            </div>
                            <a :href="createAdsUrl(oldAds)" target="_blank" class="edit-btn">编辑</a>
                          </el-tooltip>
                          <span class="gap">|</span>
                          <el-button class="delete-btn" type="text" size="small" @click="removeRaceRow(oldAds.adsId, 1)">删除</el-button>
                        </div>
                      </td>
                    </tr>
                    <tr v-for="newAds of newAdsList" :key="newAds.adsId">
                      <td>
                        {{newAds.adsName}}
                      </td>
                      <td>
                        <div class="form-input-box">
                          <template>
                            <el-input-number size="small" v-model="newAds.originalFlow" :min="0" :max="100" ></el-input-number>
                          </template>
                          <span class="percent">%</span>
                        </div>
                      </td>
                      <td>
                        <div class="ads-btn-box">
                          <!-- <el-button type="text" size="small">编辑</el-button> -->
                          <a :href="createAdsUrl(newAds)" target="_blank" class="edit-btn">编辑</a>
                          <span class="gap">|</span>
                          <el-button class="delete-btn" type="text" size="small" @click="removeRaceRow(newAds.adsId, 0)">删除</el-button>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-label"><span class="star">*</span>切流方式：</div>
            <div class="settings-cnt">
              <template>
                <el-radio-group v-model="switchType" @change="changeSwitchType()">
                  <el-radio :label="0">人工切换流量（如需临时人工调整流量，请勾选）</el-radio>
                  <el-radio :label="1">系统自动切换流量</el-radio>
                </el-radio-group>
              </template>
            </div>
          </div>
        </div>
        <div class="switch-panel" v-show="switchType">
          <h2 class="title">
            <div class="title-inner">
              <div class="title-txt">系统自动切换流量</div>
              <div class="title-time" v-if="execSwitchTime">已于{{execSwitchTime}}自动切流成功</div>
              <!-- <div class="title-btn-box" v-if="execSwitchTime">
              <el-button size="small">再次发送邮件通知</el-button>
            </div> -->
            </div>
          </h2>
          <div class="tabs-nav clearfix">
            <div v-bind:class="[(curTabIndex == 1) ? 'is-active' : '', 'nav-item']" @click="switchTabs(1)">切流设置</div>
            <div v-if='curGroupId' v-bind:class="[(curTabIndex == 2) ? 'is-active' : '', 'nav-item']" @click="switchTabs(2)">查看数据</div>
          </div>
        </div>
        <div class="tab-panel" v-show="switchType && curTabIndex == 1">
          <div class="settings-row">
            <div class="settings-label"><span class="star">*</span>预设条件：</div>
            <div class="settings-cnt">
              <div>
                <template>
                  <el-checkbox v-model="switchCdn.time.isShow" disabled>变更时间点</el-checkbox>
                  <el-checkbox v-model="switchCdn.expoPv.isShow">曝光量(PV)</el-checkbox>
                  <el-checkbox v-model="switchCdn.expoUv.isShow">曝光量(UV)</el-checkbox>
                  <el-checkbox v-model="switchCdn.clickPv.isShow">点击量(PV)</el-checkbox>
                  <el-checkbox v-model="switchCdn.clickUv.isShow">点击量(UV)</el-checkbox>
                  <el-checkbox v-model="switchCdn.clickRate.isShow">点击率相差率</el-checkbox>
                  <el-checkbox v-model="switchCdn.clickSale.isShow">销售额相差率</el-checkbox>
                </template>
              </div>
              <div class="table-box">
                <table class="settings-table">
                  <thead>
                    <tr>
                      <th>条件</th>
                      <th>条件数值</th>
                      <th>状态</th>
                    </tr>
                  </thead>
                  <tbody class="cdn-row-box">
                    <tr>
                      <td class="td-label">
                        变更时间点
                      </td>
                      <td class="cdn-cnt">
                        <!-- <template>
                            <el-date-picker
                            v-model="switchCdn.time.value"
                            type="datetimerange"
                            size="small"
                            format="yyyy-MM-dd HH:mm:ss"
                            range-separator=" - "
                            placeholder="选择切换时间范围">
                          </el-date-picker>
                        </template> -->
                        <div>
                          <span>在赛马开始</span>
                          <!-- <el-date-picker
                            class="time-wrap"
                            size="small"
                            v-model="switchCdn.time.value.startDate"
                            type="date"
                            :default-value="switchCdn.time.value.defaultStartDate"
                            placeholder="开始日期">
                          </el-date-picker>
                          <el-time-picker
                            class="time-wrap"
                            size="small"
                            v-model="switchCdn.time.value.startTime"
                            placeholder="开始时间">
                          </el-time-picker> -->
                          <el-input-number size="small" v-model="switchCdn.addTime.num6" :step="0.5" :min="0"></el-input-number>
                          <span>小时后由系统执行切换流量操作</span>
                          <!-- <el-date-picker
                            class="time-wrap"
                            size="small"
                            v-model="switchCdn.time.value.endDate"
                            type="date"
                            :default-value="switchCdn.time.value.defaultEndDate"
                            placeholder="结束日期">
                          </el-date-picker>
                          <el-time-picker
                            class="time-wrap"
                            size="small"
                            v-model="switchCdn.time.value.endTime"
                            placeholder="结束时间">
                          </el-time-picker> -->
                        </div>
                        <div class="prompt-txt">建议设置为赛马开始的1小时后，以让赛马广告获取足够多的流量数据</div>
                      </td>
                      <td>
                        <i class="el-icon-circle-check icon-right" v-if="switchCdn.time.isReach"></i>
                      </td>
                    </tr>
                    <tr v-show="switchCdn.expoPv.isShow">
                      <td>
                        曝光量(PV)
                      </td>
                      <td class="cdn-cnt">
                        <span class="form-label">其中一个赛马广告的曝光量超过</span>
                        <div class="form-input-box">
                          <template>
                            <el-input-number size="small" v-model="switchCdn.expoPv.value" :min="1"></el-input-number>
                          </template>
                        </div>
                      </td>
                      <td>
                        <i class="el-icon-circle-check icon-right" v-if="switchCdn.expoPv.isReach"></i>
                      </td>
                    </tr>
                    <tr v-show="switchCdn.expoUv.isShow">
                      <td>
                        曝光量(UV)
                      </td>
                      <td class="cdn-cnt">
                        <span class="form-label">其中一个赛马广告的曝光量超过</span>
                        <div class="form-input-box">
                          <template>
                            <el-input-number size="small" v-model="switchCdn.expoUv.value" :min="1"></el-input-number>
                          </template>
                        </div>
                      </td>
                      <td>
                        <i class="el-icon-circle-check icon-right" v-if="switchCdn.expoUv.isReach"></i>
                      </td>
                    </tr>
                    <tr v-show="switchCdn.clickPv.isShow">
                      <td>
                        点击量(PV)
                      </td>
                      <td class="cdn-cnt">
                        <span class="form-label">其中一个赛马广告的点击量超过</span>
                        <div class="form-input-box">
                          <template>
                            <el-input-number size="small" v-model="switchCdn.clickPv.value" :min="1"></el-input-number>
                          </template>
                        </div>
                      </td>
                      <td class="cdn-stat">
                        <i class="el-icon-circle-check icon-right" v-if="switchCdn.clickPv.isReach"></i>
                      </td>
                    </tr>
                    <tr v-show="switchCdn.clickUv.isShow">
                      <td>
                        点击量(UV)
                      </td>
                      <td class="cdn-cnt">
                        <span class="form-label">其中一个赛马广告的点击量超过</span>
                        <div class="form-input-box">
                          <template>
                            <el-input-number size="small" v-model="switchCdn.clickUv.value" :min="1"></el-input-number>
                          </template>
                        </div>
                      </td>
                      <td>
                        <i class="el-icon-circle-check icon-right" v-if="switchCdn.clickUv.isReach"></i>
                      </td>
                    </tr>
                    <tr v-show="switchCdn.clickRate.isShow">
                      <td class="td-label">
                        点击率相差率
                      </td>
                      <td class="cdn-cnt">
                        <span class="form-label">最高与最低的点击率相差超过</span>
                        <div class="form-input-box">
                          <template>
                            <el-input-number size="small" v-model="switchCdn.clickRate.value" :min="1" :max="100"></el-input-number>
                          </template>
                          <span class="percent">%</span>
                        </div>
                        <div class="prompt-txt">点击率相差率=（最高点击率 - 最低点击率）÷ 最低点击率</div>
                      </td>
                      <td class="cdn-stat">
                        <i class="el-icon-circle-check icon-right" v-if="switchCdn.clickRate.isReach"></i>
                      </td>
                    </tr>
                    <tr v-show="switchCdn.clickSale.isShow">
                      <td class="td-label">
                        销售额相差率
                      </td>
                      <td class="cdn-cnt">
                        <span class="form-label">最高与最低的销售额相差超过</span>
                        <div class="form-input-box">
                          <template>
                            <el-input-number size="small" v-model="switchCdn.clickSale.value" :min="1" :max="100"></el-input-number>
                          </template>
                          <span class="percent">%</span>
                        </div>
                        <div class="prompt-txt">销售额相差率=（最高销售额 - 最低销售额）÷ 最低销售额</div>
                      </td>
                      <td class="cdn-stat">
                        <i class="el-icon-circle-check icon-right" v-if="switchCdn.clickSale.isReach"></i>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-label"><span class="star">*</span>切换方式：</div>
            <div class="settings-cnt">
              <div>
                <template>
                  <el-radio-group v-model="rankType">
                    <el-radio :label="0">按点击率排名</el-radio>
                    <el-radio :label="1">按销售额排名<span class="importance">（推荐）</span></el-radio>
                  </el-radio-group>
                </template>
              </div>
              <div class="table-box">
                <table class="settings-table">
                  <thead>
                    <tr>
                      <th>赛马广告</th>
                      <th>切换后的流量占比</th>
                    </tr>
                  </thead>
                  <tbody class="cdn-row-box">
                    <tr v-for="(flowItem, index) of switchFlowList" :key="index">
                      <td v-if="rankType==0">
                        点击率排名第{{flowItem.index}}的广告
                      </td>
                      <td v-else>
                        销售额排名第{{flowItem.index}}的广告
                      </td>
                      <td>
                        <div class="form-input-box">
                          <template>
                            <el-input-number size="small" v-model="flowItem.value" :min="0" :max="100"></el-input-number>
                          </template>
                          <span class="percent">%</span>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="prompt-txt">
              (注：自动切流只执行一次，且在自动切换时会有通知邮件发送给赛马投放人)
              </div>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-label">切换后邮件通知：</div>
            <div class="settings-cnt">
              <div>
                <el-tag
                  :key="tag"
                  v-for="tag in contactTags"
                  :closable="true"
                  :close-transition="false"
                  @close="handleContactClose(tag)"
                  class="contact-tag"
                  size="small"
                >{{tag}}</el-tag>
                <el-input
                  class="input-new-tag"
                  v-if="inputContactVisible"
                  v-model="newContactValue"
                  ref="newContactTag"
                  size="mini"
                  @keyup.enter.native="handleContactConfirm"
                  @blur="handleContactConfirm"
                ></el-input>
                <el-button v-else class="btn-new-tag" size="small" @click="showContactInput">+新增收件人OA账号</el-button>
              </div>
              <div class="prompt-txt">
                (注：请填写完整的OA账号，无需填写@vipshop.com)
                <br />
                <br />
                <div class="">
                  为避免邮件被屏蔽，请先对outlook邮箱进行以下操作：<br />
                  ① 把<strong>ads@vipshop.com</strong>加入到“安全发件人”名单，<a href="https://support.office.com/zh-cn/article/%E9%98%BB%E6%AD%A2%E9%82%AE%E4%BB%B6%E5%8F%91%E4%BB%B6%E4%BA%BA-b29fd867-cac9-40d8-aed1-659e06a706e4#ID0EAACAAA=2016、2013_和_2010" target="_blank" class="email-btn">操作方法&gt;&gt;</a><br />
                  ② 取消阻止所有邮件的图片下载， <a href="https://support.office.com/zh-cn/article/%E5%9C%A8%E7%94%B5%E5%AD%90%E9%82%AE%E4%BB%B6%E4%B8%AD%E9%98%BB%E6%AD%A2%E6%88%96%E5%8F%96%E6%B6%88%E9%98%BB%E6%AD%A2%E8%87%AA%E5%8A%A8%E5%9B%BE%E7%89%87%E4%B8%8B%E8%BD%BD-15e08854-6808-49b1-9a0a-50b81f2d617a?ui=zh-CN&rs=zh-CN&ad=CN" target="_blank" class="email-btn">操作方法&gt;&gt;</a><br />
                  ③ 如邮箱收到【隔离邮件】，操作方式请见《<a href="http://wiki.corp.vipshop.com/x/dYtlF" target="_blank" class="email-btn">系统自动切换赛马流量 - 操作方法</a>》
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="tab-panel" v-show="switchType && curTabIndex == 2">
          <div class="ui-box">
            <div class="name-box">
              <div><strong>赛马分组id：{{curGroupId}}</strong></div>
              <div><strong>赛马分组名：{{newGroupName}}</strong></div>
              <div class="time" v-if="execSwitchTime">已于{{execSwitchTime}} 自动切换流量成功</div>
              <div class="prompt">（注：以下数据为自动切流时刻点的实际数据）</div>
            </div>
            <div class="rate-box">
              <div class="em-prompt">以下数据为自动切流时刻点的实际数据</div>
              <div class="race-table-box">
                <!--列表层-->
                <el-table
                  :data="raceData.results"
                  border
                  header-row-class-name="g-table-header"
                  cell-class-name="g-table-cell"
                  :row-class-name="isLast"
                >
                  <el-table-column
                    label="赛马广告"
                    align="center"
                    width="180"
                    prop="name"
                  ></el-table-column>
                  <el-table-column
                    label="点击率"
                    align="center"
                    prop="clickPercent"
                  ></el-table-column>
                  <el-table-column
                    label="销售额"
                    align="center"
                    prop="salesNum"
                  ></el-table-column>
                </el-table>
              </div>
              <div class="prompt">【注：切换时的提升值 = （切换排名第一的广告 - 排名最后的广告）÷ 排名最后的广告】</div>
            </div>
            <table v-if='raceData.list.length > 0' class="race-data-list" cellpadding="0" cellspacing="0">
              <tr v-for="item in raceData.list" :key="item.bannerId">
                <td>
                  <img class="icon" :src="item.pic" alt="" />
                </td>
                <td>
                  <div>广告id：{{item.bannerId}}</div>
                  <div>广告名：{{item.bannerName}}</div>
                  <div class="fl-rate">切换后的流量占比：{{item.ratio}}</div>
                  <div class="click-rate">点击率(点击量PV ÷ 曝光量PV)：{{item.clickPercent}}</div>
                  <div class="sales-num">切换时销售额：{{item.salesNum}}</div>
                  <div>切换时曝光量PV：{{item.exposePv}}</div>
                  <div>切换时曝光量UV：{{item.exposeUv}}</div>
                  <div>切换时点击量PV：{{item.clickPv}}</div>
                  <div>切换时点击量UV：{{item.clickUv}}</div>
                  <div>切换时单UV价值（销售额÷点击UV）：{{item.uvValue}}</div>
                </td>
              </tr>
            </table>
          </div>
        </div>
      </div>
    </div>

    <!--底部条-->
    <footer class="container-footer clearfix">
      <div class="btn-box" v-if="curTabIndex==1">
        <el-button type="primary" class="save-btn" @click="saveSettings()"><strong>保存</strong></el-button>
        <el-button class="cancel-btn" @click="goBack()">取消</el-button>
      </div>
    </footer>
  </div>
</template>

<script>
  var raceAdsLsKey = 'ads-race-ids';
  var visualRaceAdsLsKey = 'ads-race-visual_ids';

  var contactKey = 'contactKey';

  import utils from '../../libs/utils';
  import uri from '../../libs/uri';
  import storage from '../../libs/storage';
  // window.storage = storage;

  export default {
    data() {
      return {
        curFromVisual: '',
        curZoneCode: '',
        curRaceAdsLsKey: '',

        curTabIndex: 1,

        bodyLoading: false,

        isEdit: false,		/* 是不是编辑界面 */
        curGroupId: false,	/* 这个用来记录url是否传gid过来和添加新赛马保存后的gid */
        groupType: 0,
        newGroupName: '',
        selectedGroupId: '',
        oldGroupList: [],

        switchType: 1,
        rankType: 0,
        curRaceTime: '--',

        execSwitchTime: '',		/* 系统已经执行切换的时间 */

        switchCdn: {
          time: {
            isShow: true,
            // value: [],
            value: {
              defaultStartDate: new Date(),
              defaultEndDate: new Date(),
              startDate: '',
              startTime: new Date(2017, 5, 10, 10, 0, 0),
              endDate: '',
              endTime: new Date(2017, 5, 12, 10, 0, 0)
            },
            isReach: false
          },
          expoPv: {
            isShow: false,
            value: 100000,
            isReach: false
          },
          expoUv: {
            isShow: false,
            value: 80000,
            isReach: false
          },
          clickPv: {
            isShow: false,
            value: 1000,
            isReach: false
          },
          clickUv: {
            isShow: false,
            value: 800,
            isReach: false
          },
          clickRate: {
            isShow: false,
            value: 20,
            isReach: false
          },
          clickSale: {
            isShow: false,
            value: 10,
            isReach: false
          },
          addTime: {
            value: 0.5,
                num6: 1
          }

        },

        /*
          info.adsId = item.banner_id;
          info.adsName = item.name;
          info.originalFlow = item.ratio;
         */
        oldAdsList: [],
        newAdsList: [],
        switchFlowList: [],			//{'index': 1, 'value': 50}

        contactTags: [],
            inputContactVisible: false,
            newContactValue: '',

            raceData: {
              // highestClickPercent: '',
              // lowestClickPercent: '',
              // upPecent: '',
              results: [
                // {
                // 	name:
                // 	clickPercent:
                // 	salesNum:
                // }
              ],
              list: [
                // {
                // 	"racingId": "586",                     //赛马分组ID
                 //  "bannerId": "1343468",                 //广告ID
                 //  "bannerName": "赛马---f",            //广告名称
                 //  "exposePv": "250000",                  //曝光pv
                 //  "exposeUv": "200000",                  //曝光UV
                 //  "clickPv": "200000",                   //点击PV
                 //  "clickUv": "200000",                   //点击UV
                 //  "clickPercent": "80",                  //点击率
                 //  ratio: 									//切换后的流量占比
                 //  "switchTime": "2017-09-22 15:05:19",           //切换时间
                 //  "pic": "http://b.appsimg.com/upload/dsdmin/2017/09/22/27/15060635292915.jpg"    //图片
                 //  salesNum = row.sales;
                 //  uvValue = row.uv_value;
                // }
              ]
            }
      };
    },

    computed: {
      adsAttrUrl() {

        if (this.oldAdsList.length > 0 || this.newAdsList.length > 0) {

          var visualStr = (this.curFromVisual == 'true') ? '&fromVisual=' + this.curFromVisual : '';
          var zcStr = this.curZoneCode ? '&zoneCode=' + this.curZoneCode : '';

          var raceIds = [];
          var id;//第一个id
          this.oldAdsList.forEach(function(value){
            raceIds.push(value.adsId);
          });
          this.newAdsList.forEach(function(value){
            raceIds.push(value.adsId);
          });
          id = raceIds.shift();

          if(this.curGroupId){
            return '/index.php?c=banners&m=race_form&id=' + id + visualStr + zcStr + '&gid=' + (this.curGroupId ? this.curGroupId : '0') + '&o_id=' + raceIds.join(',');
          }else{
            return '/index.php?c=banners&m=race_form&id=' + id + visualStr + zcStr + '&o_id=' + raceIds.join(',');
          }
        } else {
          return 'javascript: return false;';
        }
      }
    },

    mounted() {
      // console.log(5);
      this.isEdit = uri.query('fromedit', true) ? true : false;
      this.curFromVisual = uri.query('fromVisual', true);
      this.curRaceAdsLsKey = (this.curFromVisual == 'true') ? visualRaceAdsLsKey : raceAdsLsKey;

      this.curZoneCode = uri.query('zoneCode', true);

      var gid = this.getCurGid();
      if (gid) {
        this.curGroupId = gid;
        this.getGroupInfo(gid);
      } else {
        this.getGroupList();
        this.newAdsList = this.getLocalAds();
        this.syncFlowList();

        var contacts = storage.get(contactKey);
        if (contacts && contacts.length > 0) {
          this.contactTags = contacts;
        } else {	/* 取自己账号 */
          this.$API({
            method: 'get',
            url: this.$URL.getUrl('getUserInfo')
          }).then(result => {

            if (result.status == 200 && result.data && result.data.username) {
              this.contactTags = [result.data.username];
            } else {

            }
          }, s => {

          });
        }
      }

    },
    methods: {

      createAdsUrl(row) {
        var url;
        // if (row.introductId == -1) {	// '可视化广告'
        // 	url = '/index.php?c=banners&m=redirect_form&model=banners&isAuth=true&id=' + row.adsId;
        // } else if (row.introductId == 1) {	//'工作流广告'
        // 	url = '/index.php?c=banners&m=modify_form&filter_field=1&id=' + row.adsId;
        // } else {	//0 '普通广告'
        // 	url = '/index.php?c=banners&m=form&model=banners&isAuth=true&id=' + row.adsId;
        // }
        // if (row.introductId == 1) {	//'工作流广告'
        // 	url = '/index.php?c=banners&m=modify_form&filter_field=1&id=' + row.adsId;
        // } else {	// -1 '可视化广告' or 0 '普通广告'
          url = '/index.php?c=banners&m=redirect_form&model=banners&isfrom=racing&isAuth=true&id=' + row.adsId;
        // }

        return url;
      },

      switchTabs(index) {
        if (this.curTabIndex != index) {
          this.curTabIndex = index;

          if (this.curTabIndex == 2) {
            this.getRaceData();
          }
        }
      },

      getRaceData() {
        this.bodyLoading = true;

        // this.raceData.highestClickPercent = '--';
        // this.raceData.lowestClickPercent = '--';
        // this.raceData.upPecent = '--';
        this.raceData.list = [];
        this.raceData.results = [];

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getRaceData'),
          params: {
            'gid': this.curGroupId
          }
        }).then(result => {

          this.bodyLoading = false;

          if (result.status == 200 && result.data) {

            /*

            highestClickPercent: '',
              lowestClickPercent: '',
              upPecent: '',
              list: [
                {
                  "racingId": "586",                     //赛马分组ID
                  "bannerId": "1343468",                 //广告ID
                  "bannerName": "赛马---f",            //广告名称
                  "exposePv": "250000",                  //曝光pv
                  "exposeUv": "200000",                  //曝光UV
                  "clickPv": "200000",                   //点击PV
                  "clickUv": "200000",                   //点击UV
                  "clickPercent": "80",                  //点击率
                  "switchTime": "2017-09-22 15:05:19",           //切换时间
                  "pic": "http://b.appsimg.com/upload/dsdmin/2017/09/22/27/15060635292915.jpg"    //图片
                }

                "racing_id": "586",                     //赛马分组ID
        "banner_id": "1343468",                 //广告ID
        "banner_name": "赛马2fawfawf",            //广告名称
        "expose_pv": "250000",                  //曝光pv
        "expose_uv": "200000",                  //曝光UV
        "click_pv": "200000",                   //点击PV
        "click_uv": "200000",                   //点击UV
        "click_percent": "80",                  //点击率
        "switch_time": "2017-09-22 15:05:19",           //切换时间
        "pic": "http://b.appsimg.com/upload/dsdmin/2017/09/22/27/15060635292915.jpg"    //图片
              ]
             */
            var resultData = result.data;
            // this.raceData.highestClickPercent = resultData.highest_click_percent + '%';
            // this.raceData.lowestClickPercent = resultData.lowest_click_percent + '%';
            // this.raceData.upPecent = resultData.upPecent + '%';

            var tmpResults = [];
            var resultItem;

            resultItem = {};
            resultItem.name = '切换时排名第一的广告';
            resultItem.clickPercent = resultData.highest_click_percent + '%';
            resultItem.salesNum = resultData.highest_sales + '元';
            tmpResults.push(resultItem);

            resultItem = {};
            resultItem.name = '切换时排名最后的广告';
            resultItem.clickPercent = resultData.lowest_click_percent + '%';
            resultItem.salesNum = resultData.lowest_sales + '元';
            tmpResults.push(resultItem);

            resultItem = {};
            resultItem.name = '切换时的提升值';
            resultItem.isLast = 1;
            resultItem.clickPercent = resultData.upPecent + '%';
            resultItem.salesNum = resultData.upSalesPecent + '%';
            tmpResults.push(resultItem);

            this.raceData.results = tmpResults;


            var list = [];
            for (var i = 0; i < resultData.list.length; i++) {
              var row = resultData.list[i];
              var item = {};
              item.racingId = row.racing_id;
              item.bannerId = row.banner_id;
              item.bannerName = row.banner_name;
              item.exposePv = row.expose_pv;
              item.exposeUv = row.expose_uv;
              item.clickPv = row.click_pv;
              item.clickUv = row.click_uv;
              item.clickSale = row.click_sale;
              item.clickPercent = row.click_percent + '%';
              item.switchTime = row.switch_time;
              item.ratio = row.ratio + '%';
              item.pic = row.pic;

              item.salesNum = row.sales;
              item.uvValue = row.uv_value;
              list.push(item);
            }
            this.raceData.list = list;
          } else if (result.status == 201) {
            this.$toast({
              title: '当前系统还没进行自动切流，因此还没具体数据，请耐心等候！',
              type: 'warning'
            });
          } else {
            this.$toast({
              title: '获取赛马数据失败，请重新刷新页面.',
              type: 'warning'
            });
          }
        }, s => {
          this.bodyLoading = false;
          this.$toast({
            title: '获取赛马数据失败，请重新刷新页面！',
            type: 'warning'
          });
        });
      },

      // 关闭快速编辑
      removeRaceRow(adsId, isOld) {
        if (this.oldAdsList.length + this.newAdsList.length > 2) {
          var raceList = isOld ? this.oldAdsList : this.newAdsList;
          var raceItem;
          for (var i = 0; i < raceList.length; i++) {
            raceItem = raceList[i];
            if (raceItem.adsId === adsId) {
              raceList.splice(i, 1);
              this.syncFlowList();
              break;
            }
          }
        } else {
          this.$toast({
            title: '至少要2条广告参加赛马！',
            type: 'warning'
          });
          return false;
        }
      },

      getLocalAds() {
        if (!this.localAdsList) {
          var adsObj = storage.get(this.curRaceAdsLsKey);
          if (adsObj) {
            var adsList = [];
            var adsItem;
            for (var key in adsObj) {
              if (utils.isDigital(key)) {
                adsItem = {};
                adsItem.adsId = key;
                var value = adsObj[key];
                if (typeof value == 'object') {
                  adsItem.adsName = value.name;
                  adsItem.introductId = value.introductId;
                } else {
                  adsItem.adsName = value;
                  adsItem.typeId = 0;
                }
                adsItem.originalFlow = 0;
                if (this.curZoneCode) {
                  adsItem.zoneCode = this.curZoneCode;
                }
                adsList.push(adsItem);
              }
            }
            this.localAdsList = adsList;
            return this.localAdsList.slice(0);
          } else {
            return [];
          }
        } else {
          return this.localAdsList.slice(0);
        }
        // return [{
        // 			adsId: 3,
        // 			adsName: "name3",
        // 			originalFlow: 0
        // 		}, {
        // 			adsId: 4,
        // 			adsName: "name4",
        // 			originalFlow: 0
        // 		}];
      },

      getCurGid() {
        var gid = uri.query('gid', true);
        if (gid && utils.isDigital(gid)) {
          return parseInt(gid);
        } else {
          return false;
        }
      },

      // getCurAutoSwitchAfterHour(){
      // 	var addSaiMaTime = uri.query('addSaiMaTime',true);
      // }

      getGroupList() {
        this.bodyLoading = true;

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('raceGroupList')
        }).then(result => {

          this.bodyLoading = false;

          if (result.status == 200 && result.data) {
            var list = result.data.map(function(item) {
              var info = {};
              info.gid = parseInt(item.val);
              info.gname = item.text;
              return info;
            });
            this.oldGroupList = list;
          } else {
            this.$toast({
              title: '获取赛马分组列表失败，请重新刷新页面.',
              type: 'warning'
            });
          }
        }, s => {
          this.bodyLoading = false;
          this.$toast({
            title: '获取赛马分组列表失败，请重新刷新页面！',
            type: 'warning'
          });
        });
      },

      getRaceTime() {

        var ids = '';
        var adsList = this.newAdsList.concat(this.oldAdsList);
        for (var i = 0; i < adsList.length; i++) {
          var ads = adsList[i];
          ids += ',' + ads.adsId;
        }
        ids = ids.substr(1);

        if (!ids) {
          return false;
        }

        this.curRaceTime = '...';

        this.$API({
          method: 'get',
          url: this.$URL.getUrl('getRaceTime'),
          params: {
            'ids': ids
          }
        }).then(result => {

          if ( result.status == 200 && result.data && utils.isDateTime(result.data.start_time) && utils.isDateTime(result.data.end_time) ) {
            this.curRaceTime = utils.strDate(new Date(result.data.start_time)) + " - " + utils.strDate(new Date(result.data.end_time));
            this.switchCdn.time.value.defaultStartDate = new Date(result.data.start_time);
            this.switchCdn.time.value.defaultEndDate = new Date(result.data.end_time);
          } else {
            this.curRaceTime = '--';
            this.switchCdn.time.value.defaultStartDate = new Date();
            this.switchCdn.time.value.defaultEndDate = new Date();
          }

        }, s => {
          this.curRaceTime = '--';
        });
      },

      changeGroupType() {
        if (this.groupType == 0) {
          this.selectedGroupId = '';
          this.oldAdsList = [];
          if (this.newAdsList.length < 2) {		/* 新广告少于2条，还原 */
            this.newAdsList = this.getLocalAds();
          }
          this.syncFlowList();
        } else {

        }
      },

      changeSwitchType() {
        // if (this.switchType == 1) {
        // 	var timeItems = this.switchCdn.time.value;
        // 	if (!timeItems || timeItems.length !== 2 || !timeItems[0] || !timeItems[1]) {
        // 		this.switchCdn.time.value = [this.getNextTime(1), this.getNextTime(2)];
        // 	}
        // }
      },

      getNextTime(dayNum) {		/* 取出今天还有多少时间(秒) */
          var exp = new Date();
          var now = exp.getTime();	//毫秒数
          exp.setTime(now + dayNum * 24 * 3600 * 1000);
          var nextStr = exp.getFullYear() + '/' + (exp.getMonth() + 1) + '/' + exp.getDate()
            + ' 10:00:00';
          return nextStr;
        },

      changeGroupList() {
        // console.log(this.selectedGroupId, typeof this.selectedGroupId);
        var gid = this.selectedGroupId;
        this.getGroupInfo(gid)
      },

      getGroupInfo(gid) {
        if (!gid) {
          return false;
        }
        this.bodyLoading = true;
        this.$API({
          method: 'get',
          url: this.$URL.getUrl('raceGroupInfo'),
          params: {
            'gid': gid
          }
        }).then(result => {

          this.bodyLoading = false;

          if (result.status == 200 && result.data) {

            if (this.curGroupId) {
              this.newGroupName = result.gname;
            }
            var list = result.data.map(function(item) {
              var info = {};
              info.adsId = item.banner_id;
              info.adsName = item.name;
              info.originalFlow = item.ratio;
              info.introductId = item.introduct;
              return info;
            });
            this.oldAdsList = list;

            this.curRaceTime = result.start + " - " + result.end;

            if (this.curGroupId) {		/* 编辑状态 */

              var switchData = result.auto_switch;


              this.switchType = switchData.is_open ? 1 : 0;
              if (this.switchType) {

                var addSaiMaTime = switchData.info.auto_switch_after_hour;
                var info = switchData.info;

                if (info.start && info.end && utils.isDateTime(info.start) && utils.isDateTime(info.end)) {
                  // this.switchCdn.time.value = [info.start, info.end];
                  var startDateTimes = info.start.split(/\s+/);
                  var endDateTimes = info.end.split(/\s+/);
                  this.switchCdn.time.value.startDate = startDateTimes[0];
                  this.switchCdn.time.value.startTime = new Date(info.start);
                  this.switchCdn.time.value.endDate = endDateTimes[0];
                  this.switchCdn.time.value.endTime = new Date(info.end);

                  this.switchCdn.time.isReach = info.reach_time ? true : false;
                }

                if (info.pv.value > 0) {
                  this.switchCdn.expoPv.isShow = true;
                  this.switchCdn.expoPv.value =info.pv.value;
                  this.switchCdn.expoPv.isReach = info.pv.is_reach ? true : false;
                } else {
                  this.switchCdn.expoPv.isShow = false;
                }

                if (info.uv.value > 0) {
                  this.switchCdn.expoUv.isShow = true;
                  this.switchCdn.expoUv.value = info.uv.value;
                  this.switchCdn.expoUv.isReach = info.uv.is_reach ? true : false;
                } else {
                  this.switchCdn.expoUv.isShow = false;
                }

                if (info.click_pv.value > 0) {
                  this.switchCdn.clickPv.isShow = true;
                  this.switchCdn.clickPv.value = info.click_pv.value;
                  this.switchCdn.clickPv.isReach = info.click_pv.is_reach ? true : false;
                } else {
                  this.switchCdn.clickPv.isShow = false;
                }

                if (info.click_uv.value > 0) {
                  this.switchCdn.clickUv.isShow = true;
                  this.switchCdn.clickUv.value = info.click_uv.value;
                  this.switchCdn.clickUv.isReach = info.click_uv.is_reach ? true : false;
                } else {
                  this.switchCdn.clickUv.isShow = false;
                }

                if (info.click.value > 0) {
                  this.switchCdn.clickRate.isShow = true;
                  this.switchCdn.clickRate.value = info.click.value;
                  this.switchCdn.clickRate.isReach = info.click.is_reach ? true : false;
                } else {
                  this.switchCdn.clickRate.isShow = false;
                }

                if (info.click_sale.value > 0) {
                  this.switchCdn.clickSale.isShow = true;
                  this.switchCdn.clickSale.value = info.click_sale.value;
                  this.switchCdn.clickSale.isReach = info.click_sale.is_reach ? true : false;
                } else {
                  this.switchCdn.clickSale.isShow = false;
                }

                this.rankType = info.ratio_type == 1 ? 1 : 0;
                this.syncFlowList(info.ratio);

                if (switchData.have_excuted) {
                  this.execSwitchTime = switchData.switch_time;
                  // console.log(this.execSwitchTime);
                }

                if(addSaiMaTime > 0){
                  this.switchCdn.addTime.num6 = addSaiMaTime;
                  // console.log(this.switchCdn.addTime.num6);
                }

                var contacts = switchData.mailto;
                if (contacts && contacts.length > 0) {
                  this.contactTags = contacts;
                }
              } else {
                this.syncFlowList();
              }
            } else {
              this.syncFlowList();
            }

          } else {
            this.$toast({
              title: '获取分组详细信息失败，请重试.',
              type: 'warning'
            });
          }
        }, s => {
          this.bodyLoading = false;
          this.$toast({
            title: '获取分组详细信息失败，请重试！',
            type: 'warning'
          });
        });
      },

      syncFlowList(values) {
        // console.log(values);
        var adsTotal = this.oldAdsList.length + this.newAdsList.length;
        var flowTotal = this.switchFlowList.length;
        if (adsTotal != flowTotal) {
          if (adsTotal > flowTotal) {
            var newList = [];
            values = values ? values : [];
            for (var i = flowTotal; i < adsTotal; i++) {
              var value = (values[i] !== undefined) ? values[i] : ((i == 0) ? 100 : 0);
              newList.push({'index': (i + 1), 'value': value});
            }
            this.switchFlowList = this.switchFlowList.concat(newList);
          } else {
            this.switchFlowList.splice(adsTotal, flowTotal - adsTotal);
          }
        }

        /* 重新取赛马时间 */
        this.getRaceTime();
      },

      saveSettings() {

        var gid, gname;
        var item, i;

        if (this.curGroupId) {
          gid = this.curGroupId;
          gname = this.newGroupName;
        } else {
          if (!this.groupType) {	/* 新加分组 */
            if (this.newGroupName.length < 2) {
              var txt = '赛马分组名不能少于2个字！';
              if (this.newGroupName.length == 0) {
                txt = '赛马分组名不能为空，且不能少于2个字！';
              }
              this.$toast({
                title: txt,
                type: 'warning'
              });
              return false;
            }
            gname = this.newGroupName;
          } else {	/* 添加到原有分组 */
            if (!this.selectedGroupId) {
              this.$toast({
                title: '请选择赛马分组！',
                type: 'warning'
              });
              return false;
            } else {
              gid = this.selectedGroupId;
              var groupList = this.oldGroupList;
              for (i = 0; i < groupList.length; i++) {
                item = groupList[i];
                if (item.gid == gid) {
                  gname = item.gname;
                  break;
                }
              }
            }
          }
        }

        if (this.oldAdsList.length + this.newAdsList.length < 2) {
          this.$toast({
            title: '至少要2条广告参加赛马！',
            type: 'warning'
          });
          return false;
        }

        var originalFlowTotal = 0;
        var ads = [];
        var ratios = [];
        for (i = 0; i < this.oldAdsList.length; i++) {
          item = this.oldAdsList[i];
          if (!utils.isDigital(item.originalFlow)) {
            this.$toast({
              title: '第' + (i + 1) + '条广告初始流量占比不能是小数',
              type: 'warning'
            });
            return false;
          }
          originalFlowTotal += item.originalFlow;
          ads.push(item.adsId);
          ratios.push(item.originalFlow);
        }
        for (i = 0; i < this.newAdsList.length; i++) {
          item = this.newAdsList[i];
          if (!utils.isDigital(item.originalFlow)) {
            this.$toast({
              title: '第' + (this.oldAdsList.length + i + 1) + '条广告初始流量占比不能是小数',
              type: 'warning'
            });
            return false;
          }
          originalFlowTotal += item.originalFlow;
          ads.push(item.adsId);
          ratios.push(item.originalFlow);
        }
        if (originalFlowTotal != 100) {
          this.$toast({
            title: '广告初始流量占比相加不等于100！',
            type: 'warning'
          });
          return false;
        }

        var paramObj = {};

        if (gid) {
          paramObj['gid'] = gid;
        }
        paramObj["gname"] = gname;
        paramObj["type"] = 1;
        paramObj["ids"] = ads.join(',');
        paramObj["ratios"] = ratios.join(',');


        if (this.switchType) {		/* 自动切换，检查切换的值的合法性 */

          var switchCdn =this.switchCdn;

          paramObj["is_auto_switch"] = this.switchType;

          paramObj["auto_switch_after_hour"] = this.switchCdn.addTime.num6;
          // var timeItems = switchCdn.time.value;
          // if (timeItems && timeItems.length == 2 && timeItems[0] && timeItems[1]) {
          // 	paramObj["start_time"] = utils.strDate(timeItems[0]);
          // 	paramObj["end_time"]  = utils.strDate(timeItems[1]);
          // } else {
          // 	this.$toast({
          // 		title: '切换时间设置有误',
          // 		type: 'warning'
          // 	});
          // 	return false;
          // }
          var timeValue = switchCdn.time.value;
          var startDate, startTime, endDate, endTime;
          // console.log(timeValue);
          startDate = timeValue.startDate && utils.strDate(timeValue.startDate, 'date');
          // if (!startDate || !utils.isDateTime(startDate, 'date')) {
          // 	this.$toast({
          // 		title: '切换的开始日期有误（不能为空且不能小于2000年）',
          // 		type: 'warning'
          // 	});
          // 	return false;
          // }

          startTime = timeValue.startTime && utils.strDate(timeValue.startTime, 'time');
          // if (!startTime) {
          // 	this.$toast({
          // 		title: '切换的开始时间有误',
          // 		type: 'warning'
          // 	});
          // 	return false;
          // }

          endDate = timeValue.endDate && utils.strDate(timeValue.endDate, 'date');
          // if (!endDate || !utils.isDateTime(endDate, 'date')) {
          // 	this.$toast({
          // 		title: '切换的结束日期有误（不能为空且不能小于2000年）',
          // 		type: 'warning'
          // 	});
          // 	return false;
          // }

          endTime = timeValue.endTime && utils.strDate(timeValue.endTime, 'time');
          // if (!endTime) {
          // 	this.$toast({
          // 		title: '切换的结束时间有误',
          // 		type: 'warning'
          // 	});
          // 	return false;
          // }

          paramObj["start_time"] = startDate + ' ' + startTime;
          paramObj["end_time"]  = endDate + ' ' + endTime;
          // if ( (new Date(paramObj["start_time"])).getTime() >= (new Date(paramObj["end_time"])).getTime() ) {
          // 	this.$toast({
          // 		title: '开始的切换时间不能大于结束时间',
          // 		type: 'warning'
          // 	});
          // 	return false;
          // }
          // console.log(paramObj);
          // return true;

          if (switchCdn.expoPv.isShow) {
            if ( !switchCdn.expoPv.value || !utils.isDigital(switchCdn.expoPv.value) ) {
              this.$toast({
                title: '曝光量(PV)不能是小数',
                type: 'warning'
              });
              return false;
            }
            paramObj["cond_pv"] = switchCdn.expoPv.value;
          }

          if (switchCdn.expoUv.isShow) {
            if ( !switchCdn.expoUv.value || !utils.isDigital(switchCdn.expoUv.value) ) {
              this.$toast({
                title: '曝光量(UV)不能是小数',
                type: 'warning'
              });
              return false;
            }
            paramObj["cond_uv"] = switchCdn.expoUv.value;
          }

          if (switchCdn.clickPv.isShow) {
            if ( !switchCdn.clickPv.value || !utils.isDigital(switchCdn.clickPv.value) ) {
              this.$toast({
                title: '点击量(PV)不能是小数',
                type: 'warning'
              });
              return false;
            }
            paramObj["cond_click_pv"] = switchCdn.clickPv.value;
          }

          if (switchCdn.clickUv.isShow) {
            if ( !switchCdn.clickUv.value || !utils.isDigital(switchCdn.clickUv.value) ) {
              this.$toast({
                title: '点击量(UV)不能是小数',
                type: 'warning'
              });
              return false;
            }
            paramObj["cond_click_uv"] = switchCdn.clickUv.value;
          }

          if (switchCdn.clickRate.isShow) {
            if ( !switchCdn.clickRate.value || !utils.isDigital(switchCdn.clickRate.value) ) {
              this.$toast({
                title: '点击率相差值只能在1到100之间的整数',
                type: 'warning'
              });
              return false;
            }
            paramObj["cond_click"] = switchCdn.clickRate.value;
          }

          if (switchCdn.clickSale.isShow) {
            if ( !switchCdn.clickSale.value || !utils.isDigital(switchCdn.clickSale.value) ) {
              this.$toast({
                title: '销售额相差值只能在1到100之间的整数',
                type: 'warning'
              });
              return false;
            }
            paramObj["cond_click_sale"] = switchCdn.clickSale.value;
          }

          var switchFlowTotal = 0;
          var switchRatios = [];
          for (i = 0; i < this.switchFlowList.length; i++) {
            item = this.switchFlowList[i];
            if (!utils.isDigital(item.value)) {
              this.$toast({
                title: '第' + (i + 1) + '条广告（切换后占比）不能是小数',
                type: 'warning'
              });
              return false;
            }
            switchFlowTotal += item.value;
            switchRatios.push(item.value);
          }
          if (switchFlowTotal != 100) {
            this.$toast({
              title: '切换后的流量占比不等于100！',
              type: 'warning'
            });
            return false;
          }

          paramObj["ratio_type"] = this.rankType;
          paramObj["auto_ratio"] = switchRatios.join(',');

          paramObj["mailto"] = this.contactTags.join(',');
        }


        this.bodyLoading = true;

        this.$API({
          method: 'post',
          url: this.$URL.getUrl('saveRaceSettings'),
          isFormData: true,
          data: paramObj
        }).then(result => {

          this.bodyLoading = false;
          if (result.status == 200 && result.data) {
            this.$toast({
              title: '保存成功，请在【赛马分组列表】中查看。',
              type: 'success'
            });

            if (!this.gid) {
              this.curGroupId = result.gid;
              storage.remove(this.curRaceAdsLsKey);
              this.localAdsList = null;
              this.oldAdsList = this.oldAdsList.concat(this.newAdsList);
              this.newAdsList = [];
            }
            this.curRaceTime = (result.data.start_time_format + ' - ' + result.data.end_time_format);

            storage.set(contactKey, this.contactTags);

          } else {
            var errMsg = result.msg ? result.msg : '保存失败.';
            this.$toast({
              title: errMsg,
              type: 'warning'
            });
          }
        }, result => {
          this.bodyLoading = false;
          var errMsg = result.msg ? result.msg : '保存失败!';
          this.$toast({
            title: errMsg,
            type: 'warning'
          });
        });
      },

      handleContactClose(tag) {
        this.contactTags.splice(this.contactTags.indexOf(tag), 1);
      },

      showContactInput() {
        this.inputContactVisible = true;
        this.$nextTick(_ => {
          this.$refs.newContactTag.$refs.input.focus();
        });
      },

      handleContactConfirm() {
        var newContactValue = this.newContactValue;
        // console.log('utils.isEmail(newContactValue) = ', utils.isEmail(newContactValue));
        newContactValue = newContactValue.replace(/^\s+|\s+$/, '');
        if (newContactValue) {
          this.contactTags.push(newContactValue);
          this.newContactValue = '';
        }
        this.inputContactVisible = false;
      },

      //	显示奇偶行样式{row, rowIndex}
      isLast(info) {
        // console.log(arguments);
        if (info.row.isLast) {
          return 'is-last';
        }
        return '';
      },

      goBack() {
        window.history.go(-1);
      }

    }
  };
</script>

<style lang="scss">
  .race-settings-box {

    .tabs-nav {
      /*position: absolute;
      bottom: -1px;
      left: 50%;
      margin-left: -118px;
      z-index: 901;*/

      margin-top: 20px;
      padding-left: 50px;
      position: relative;
      text-align: left;
      border-bottom: 1px solid #e0e6ed;
      height: 41px;

      .nav-item {
        float: left;
        width: 118px;
        line-height: 40px;
        border: 1px solid transparent;
        transition: all .3s cubic-bezier(.645,.045,.355,1);
        color: #8391a5;
        text-align: center;
        cursor: pointer;
        user-select: none;
      }

      .nav-item.is-active {
        border: 1px solid #e0e6ed;
          border-bottom-color: #fff;
          border-radius: 4px 4px 0 0;
          color: #20a0ff;
          cursor: default;
      }
    }

    button {
      font-family: "Microsoft YaHei", "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","\5FAE\8F6F\96C5\9ED1",Arial,sans-serif;
    }

    .is-last {
      color: #13cc65;
    }

    .switch-panel {
      margin-top: 70px;
      padding-bottom: 30px;
    }

    .icon-right:before {
      width: 36px;
      height: 36px;
      font-size: 20px;
      line-height: 36px;
      color: #13ce66;
      /*background-color: #13ce66;
      */
    }

    .attr-edit-btn {
      display: inline-block;
      line-height: 1;
        white-space: nowrap;
        cursor: pointer;
        background: #fff;
        border: 1px solid #bfcbd9;
        color: #1f2d3d;
        text-align: center;
        box-sizing: border-box;
        margin: 0;
        padding: 10px 15px;
        font-size: 14px;
        border-radius: 4px;
        padding: 7px 9px;
        font-size: 12px;
        border-radius: 4px;
    }

    .attr-edit-btn:hover {
      color: #20a0ff;
        border-color: #20a0ff;
    }

    .data-check-btn {
      position: absolute;
      top: 16px;
      right: 56px;
      z-index: 1000;
    }

    .edit-btn {
      display: inline-block;
      line-height: 1;
      white-space: nowrap;
      cursor: pointer;
      color: rgb(31, 45, 61);
      -webkit-appearance: none;
      text-align: center;
      box-sizing: border-box;
      user-select: none;
      font-size: 13.333333px;
      background: rgb(255, 255, 255);
      border-width: 1px;
      border-style: solid;
      border-color: rgb(191, 203, 217);
      border-image: initial;
      outline: none;
      margin: 0px;
      padding: 10px 15px;
      border-radius: 4px;
      color: rgb(32, 160, 255);
      padding-left: 0px;
      padding-right: 0px;
      border-width: initial;
      border-style: none;
      border-color: initial;
      border-image: initial;
      background: transparent;
    }

    .prompt-txt {
      margin-top: 5px;
      color: #bbb;
    }

    .delete-btn {
      color: #999;
    }

    .delete-btn:hover {
      color: #4db3ff;
    }

    .table-box {
      margin-top: 10px;
    }

    .settings-table {
      display: table;
        border-collapse: separate;
        border-spacing: 0;
        border: 1px solid #dfe6ec;
        overflow: hidden;

        width: 100%;

      border-radius: 2px;
      -moz-border-radius: 2px;
      -webkit-border-radius: 2px;

      tbody tr:hover {
        background-color: #F9FAFC;
      }

      th {
        background-color: #eef1f6;
        color: #999;
          text-align: left;
          height: 40px;
          min-width: 0;
          padding: 0 10px;
          box-sizing: border-box;
          text-overflow: ellipsis;
          vertical-align: middle;
          /*position: relative;*/

          border-left: 1px solid #dfe6ec;
      }

        td {
          /*height: 40px;*/
          min-width: 0;
          padding: 6px 10px;
          box-sizing: border-box;
          text-overflow: ellipsis;
          vertical-align: middle;
          /*position: relative;*/

          border-top: 1px solid #dfe6ec;
          border-left: 1px solid #dfe6ec;
        }

        th:first-child, td:first-child {
          color: #999;
          border-left: none;
        }

        td:first-child{
          color: #1f2d3d;
        }

      .ads-name-td {
        width: 60%;
      }

      .ads-btn-box {
        white-space: nowrap;
      }

      .td-label {
        vertical-align: top;
        line-height: 30px;
      }

      .time-wrap {
        width: 140px;
      }

        .form-label {
          min-width: 205px;
          display: inline-block;
          line-height: 30px;
          vertical-align: middle;
        }

        .form-input-box {
          display: inline-block;
          position: relative;
          height: 30px;
          /*overflow: hidden;*/
          /*padding-top: 3px;*/
          line-height: normal;
          vertical-align: middle;
          overflow: visible;
          /*zoom: 1;*/
          /*background-color: rgba(255, 0, 0, 1);*/

          .percent {
            position: absolute;
            left: 80px;
            top: 0;
            line-height: 32px;
          }
        }
    }

    .title {
      margin: 20px auto 0 auto;
      border-left: 4px solid #666;
      padding-left: 10px;
      text-align: left;
      line-height: 27px;
      font-size: 24px;
      font-weight: normal;
      color: #666;

      .title-inner {
        position: relative;
        margin-right: 50px;
      }

      .title-txt {
        display: inline-block;
        vertical-align: middle;
      }

      .title-time {
        display: inline-block;
        vertical-align: middle;
        background-color: #13CE66;
        color: #fff;
        border-radius: 3px;
        margin-left: 20px;
        padding: 0 10px;
        font-size: 13px;
        line-height: 21px;
      }

      .title-btn-box {
        position: absolute;
        line-height: normal;
        vertical-align: top;
        right: 5px;
        top: -3px;
      }
    }


    .settings-panel {
      padding-bottom: 30px;
    }

    .settings-row {
      position: relative;
      margin: 40px 50px 0 auto;
      padding: 0 0 0 150px;
    }

    .settings-label {
      position: absolute;
      left: 0;
      top: 0;
      width: 140px;
      text-align: right;

    }

    .settings-label-stat {
      line-height: 30px;
    }

    .settings-cnt {
    }

    .star, .importance {
      color: #fd2b2b;
    }

    .group-name-box {
      margin-top: 5px;
      margin-right: auto;
      width: 90%;
      max-width: 500px;

      .select {
        width: 100%;
      }
    }

    .group-name-box2 {
      margin-top: 0;
    }

    .race-time-box {
      position: relative;
      text-align: right;

      .time-txt {
        position: absolute;
        left: 5px;
        top: 0;
        line-height: 30px;
      }

      .attr-box {
        display: inline-block;
        margin-right: 5px;
        margin-left: auto;
      }
    }

    .nowrap {
      white-space: nowrap;
    }


    .btn-box {
      padding-top: 2px;
    }

    .save-btn {
      width: 180px;
    }

    .cancel-btn {
      margin-left: 30px;
      width: 80px;
    }

    .contact-tag {
      margin-left: 10px;
    }

    .contact-tag:first-child {
      margin-left: 0px;
    }

    .input-new-tag {
      width: 140px;
        margin-left: 10px;
        vertical-align: bottom;
    }

    .btn-new-tag {
      margin-left: 10px;
      height: 24px;
      line-height: 22px;
      padding-top: 0;
      padding-bottom: 0;
      width: 140px;
    }

    $uiBorderColor: #d9d9d9;
    .ui-box {
      padding: 20px;

      .name-box {
        border: 1px solid $uiBorderColor;
        border-radius: 3px;

        padding: 10px;
        line-height: 22px;

        .time {
          display: inline-block;
          padding: 0 5px;
          border-radius: 3px;
          background: #13ce66;
          margin-top: 10px;
          color: #fff;
          line-height: 21px;
        }

        .prompt {
          margin-top: 10px;
          color: #d7d7d7;
        }
      }

      .rate-box {
        margin-top: 20px;
        border: 1px solid $uiBorderColor;
        border-radius: 3px;
        padding: 10px;
        line-height: 22px;

        .click {
          color: #13cc65;
        }

        .prompt {
          margin-top: 10px;
          color: #d7d7d7;
        }

        .em-prompt {
          color: #cc0000;
          margin-bottom: 6px;
        }
      }

      .race-data-list {
        margin-top: 20px;
        border: 1px solid $uiBorderColor;
        border-radius: 3px;
        overflow: hidden;
        width: 100%;

        td {
          border-top: 1px solid $uiBorderColor;
          border-left: 1px solid $uiBorderColor;
          padding: 10px;
          text-align: left;
          color: #989898;
          vertical-align: middle;
          line-height: 22px;
        }

        tr:first-child td {
          border-top: none;
        }

        td:first-child {
          border-left: none;
          width: 200px;
          text-align: center;
        }

        .icon {
          max-width: 100%;
          max-height: 100%;
        }

        .fl-rate {
          margin-top: 20px;
          color: #13ce66;
        }

        .click-rate {
          margin-top: 20px;
          color: #cc0000;
        }

        .sales-num {
          color: #cc0000;
        }
      }


    }

    .email-btn {
      color: #20a0ff;
      text-decoration: none;
    }

    .email-btn:hover {
      text-decoration: underline;
    }

  }

</style>