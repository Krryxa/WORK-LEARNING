'use strict'

// import 'babel-polyfill';
// 引入babel
import Vue from 'vue';
// 引入主文件
import entry from 'com/index';
// 引入路由
import router from './router';

import store from './store';

// 引入ajax服务
import { API, URL } from 'api/api';

// 引入axios APIs
import axios from '@/service/newAPI/axios';

import { wfire, won, woff } from 'com/extend/event';

import listeners from './libs/listeners';

import toast from 'com/toast/main';
import picmanager from 'com/picmanager/main';

import sysmask from 'com/sysmask/main';

// 引入表单校验服务
// import Vuerify from 'vuerify';
// import VuerifyDirective from 'v-vuerify-next';
// 引入UI样式,各模块按需引入ui组件
import 'element-ui/lib/theme-chalk/index.css';
// 引入ui组件
import elementUI from 'element-ui';
// 引入基本样式
import './static/styles/base';
// import './static/styles/public.scss';

Vue.use(toast);
Vue.use(picmanager);
Vue.use(sysmask);

// 注册全局组件
Vue.use(elementUI);
// 注册验证组件
// Vue.use(Vuerify);
// Vue.use(VuerifyDirective);

Vue.use(Vue => {
  Vue.prototype.$API = API;
  Vue.prototype.$URL = URL;

  Vue.prototype.$wfire = wfire;
  Vue.prototype.$won = won;
  Vue.prototype.$woff = woff;
});

// 将Axios调用写入vue原型链
Vue.prototype.$axios = axios;

var hasLoginInit = true;
listeners.sub('SystemAjaxResult', function (data) {
  var result = data.result;
  if (result) {
    if (+result.status === 400) {  /* 还没有登录，直接登录 */
      if (hasLoginInit) {
        hasLoginInit = false;
        /*
        重组链接
        http://ads-admin-test.vip.vip.com/new_ads/dist/#/list?&madmin_app_name=特卖会&madmin_component_name=特卖会广告组件
        &madmin_version=20171107112633&madmin_app_code=2&madmin_component_id=21
        因为历史原因，链接就成这样子
        */
        var url;
        var href = window.location.href;
        var mainHref = href.split('#')[0];
        mainHref = mainHref.split('?')[0];

        var hash = window.location.hash;
        var realHash = hash;
        var sysDefaultKey = 'madmin_app_name';
        var search = '';
        if (hash.indexOf(sysDefaultKey) >= 0) { /* 新页面加上旧的链接的参数 */
          // var hashSegs = hash.split(/\?\&?/);
          var hashSegs = hash.split(/\?&?/);
          if (hashSegs.length > 1) {
            search = hashSegs[1];
            realHash = hashSegs[0];
          } else { /* 已经在新页面 */
            alert('链接有误,请重新登录')
          }
        } else {
          if (location.search) {
            search = location.search.substr(1);
          } else {
            search = 'newfrom=1';
          }
        }

        if (search) {
          url = mainHref + '?' + search + realHash;
        } else {
          url = mainHref + realHash;
        }
        // alert(url);
        var txtHref = result.data;
        var arr = txtHref.split('?');
        txtHref = arr[0];
        txtHref += '?service=' + window.encodeURIComponent(url);
        // alert(txtHref);
        location.href = txtHref;
      }
    } else if (+result.status === 402) { /* 系统暂停 */
      var txt = (result.data && result.data.announcement ? result.data.announcement : '广告系统现在在发布更新中，暂停服务，各位老大请稍等（10分钟）！再次使用时麻烦清除浏览器缓存！谢谢各位女神男神！');
      vm.$sysmask(txt);
    }
  }
});

listeners.sub('SystemCheckLogin', function (data) {
  var result = data.result;
  // 登录成功，删除url中的ticket, 再自动刷新页面
  if (result && +result.status === 200) {
    var url;
    var href = window.location.href;
    var mainHref = href.split('#')[0];
    mainHref = mainHref.split('?')[0];

    var search = location.search;
    search = search.substr(1);
    search = search.replace(/(^|&)ticket=([^&]*)(&|$)/, '&');
    // search = search.replace(/^\&+|&+$/, '');
    search = search.replace(/^&+|&+$/, '');
    if (search) {
      search = '?' + search;
    }
    url = mainHref + search + location.hash;

    location.href = url;
  } else { /* 登录不成功 */
    vm.$sysmask('登录不成功，请重新登录');
  }
});

window.vm = new Vue({
  render: h => h(entry),
  router,
  store,
}).$mount('#app');
