'use strict';

import * as API from 'newAPI';
import { Message } from 'element-ui';

const state = {
  allDatas: [],
  total: 0,
  currentPage: 1,
  pageSize: 20,
  searchContent: '',
};

const getters = {
  allGroups: state => {
    const groups = [];
    const originGroups = state.allDatas;
    // there are any datas to format
    if (originGroups.length) {
      originGroups.forEach(originGroup => {
        const group = {
          id: originGroup.id,
          name: originGroup.name,
          adNames: originGroup.banners_info.map(ad => {
            return ad.name;
          }),
          dates: [ originGroup.start_time, originGroup.end_time ],
          zoneNames: originGroup.zone_name,
          operator: originGroup.creator + '/' + originGroup.modifier,
        };
        groups.push(group);
      });
    }
    return groups;
  },
  //
};

const mutations = {
  setGroups (state, { groups }) {
    state.allDatas = [...groups];
  },
  setTotal (state, { total }) {
    state.total = total;
  },
  changeCurrentPage (state, { currentPage }) {
    state.currentPage = currentPage;
  },
  changePageSize (state, { pageSize }) {
    state.pageSize = pageSize;
  },
  changeSearchContent (state, { searchContent }) {
    state.searchContent = searchContent;
  },
};

const actions = {
  async getGroupList ({ commit, state }, payload = { page: 1, page_size: 20 }) {
    const params = Object.assign(payload, { page: state.currentPage, page_size: state.pageSize });
    const res = await API.personalGroup.fetchGroupList(params);
    if (+res.status === 200) {
      commit('setGroups', { groups: res.data });
      commit('setTotal', { total: res.total });
    }
  },
  async deleteGroup ({ commit, dispatch }, { id = 0 }) {
    const res = await API.personalGroup.deleteGroup({
      id: id
    });
    if (+res.status === 200) {
      Message({
        message: '删除成功！',
        type: 'success',
      });
      setTimeout(() => {
        dispatch('getGroupList');
      }, 3000);
    }
  },
  seachGroupList ({ state, dispatch }, payload = { name: '' }) {
    const params = Object.assign(payload, { name: state.searchContent });
    dispatch('getGroupList', params);
  },
};

export default {
  state,
  getters,
  mutations,
  actions,
};
