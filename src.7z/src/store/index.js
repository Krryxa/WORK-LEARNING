'use strict';

// 'vue'和'vuex'变成'Vue'和'Vuex'是不会报错的
import Vue from 'vue';
import Vuex from 'vuex';
import personalList from './modules/personal/list';

Vue.use(Vuex);

const isDebug = process.env.NODE_ENV !== 'production';

export default new Vuex.Store({
  modules: {
    personalList,
  },
  strict: isDebug,
});
