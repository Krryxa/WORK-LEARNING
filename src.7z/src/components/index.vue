<template>
	<div id="container" class="clearfix">
		<router-view></router-view>
	</div>
</template>
