<template>
	<div class="u-search-wrap">
		<div class="u-cnt-basic clearfix">
			<el-button type="text" class="btn-search-advance" size="mini"
				v-show="hasAdvSearch"
				@click="setPanelAdvSearch(!isShowAdvSearch)"
			>{{btnAdvSCnt}}</el-button>
			<div
				:class="['u-search-normal', hasAdvSearch ? 'shorten' : '']"
			>
				<el-input placeholder="搜索广告名称、广告ID、创建人" size="mini"
					v-model="keyName"
					@focus="chkSearchState"
					@blur="isFocus = false"
					@keyup.enter.native="searchNormal"
					:disabled="isShowAdvSearch"
				>
					<el-button slot="append" icon="el-icon-search" class="general-btn" :disabled="isShowAdvSearch"
						@click="searchNormal"
					></el-button>
				</el-input>
			</div>
			<img alt=""	:src="getImg('update.png')" :class="['fresh-btn', isRotate? 'update' : '']" title='刷新广告列表' @click='updateList'>
		</div>
		<transition name="fade">
			<div class="u-cnt-advanced"
				v-show="isShowAdvSearch"
			>
				<div class="form-box clearfix">

					<div class="adv-col1">
						<div class="adv-row clearfix">
							<div class="label-wrap">
								<label class="label"><span class="inner-txt">开始时间</span></label>
								<el-date-picker
									type="datetime"
									placeholder="选择日期时间"
									v-model="advInfo.startTimeBegin"
									size="mini"
									style="width: 100%;"
									:default-value="defaultDateTime"
								></el-date-picker>
							</div>
							<div class="label-wrap">
								<label class="label">到</label>
								<el-date-picker
									type="datetime"
									placeholder="选择日期时间"
									v-model="advInfo.startTimeEnd"
									size="mini"
									style="width: 100%;"
									:default-value="defaultDateTime"
								></el-date-picker>
							</div>
						</div>
						<div class="adv-row clearfix">
							<div class="label-wrap">
								<label class="label"><span class="inner-txt">结束时间</span></label>
								<el-date-picker
									type="datetime"
									placeholder="选择日期时间"
									v-model="advInfo.endTimeBegin"
									size="mini"
									style="width: 100%;"
									:default-value="defaultDateTime"
								></el-date-picker>
							</div>
							<div class="label-wrap">
								<label class="label">到</label>
								<el-date-picker
									type="datetime"
									placeholder="选择日期时间"
									v-model="advInfo.endTimeEnd"
									size="mini"
									style="width: 100%;"
									:default-value="defaultDateTime"
								></el-date-picker>
							</div>
						</div>
					</div>

					<div class="adv-col2">
						<div class="adv-row clearfix">
							<div class="label-wrap" style="width: 100%;">
								<label class="label"><span class="inner-txt">申请位</span></label>
								<el-cascader :options="applyList" filterable clearable placeholder="申请位" size="mini" style="width: 100%;" v-model="selectedApplys"></el-cascader>
							</div>
						</div>
						<div class="adv-row clearfix">
							<div class="label-wrap" style="width: 100%;">
								<label class="label"><span class="inner-txt">广告位</span></label>
								<el-cascader :options="adsPostList" :disabled="curZoneId?true:false" filterable clearable placeholder="广告位" size="mini" style="width: 100%;" v-model="selectedAdsPosts"></el-cascader>
							</div>
						</div>
					</div>

					<div class="adv-col3">
						<div class="adv-row clearfix">
							<div class="label-wrap">
								<label class="label"><span class="inner-txt">广告ID</span></label>
								<el-input class="add-name ad-name-from" placeholder="广告ID"
									size="mini" style="width: 100%;"
									v-model="advInfo.bannerIdBegin"
								></el-input>
							</div>
							<div class="label-wrap">
								<label class="label">--</label>
								<el-input class="ad-name add-name-to" placeholder="广告ID"
									size="mini" style="width: 100%;"
									v-model="advInfo.bannerIdEnd"
								></el-input>
							</div>
						</div>

						<div class="adv-row clearfix">
							<div class="label-wrap">
								<label class="label"><span class="inner-txt">广告名称</span></label>
								<el-input placeholder="广告名称" style="width: 100%;"
									v-model="advInfo.bannerName"
									size="mini"
								></el-input>
							</div>
							<div class="label-wrap label-wrap2">
								<label class="label">创建人</label>
								<el-input placeholder="创建人" style="width: 100%;"
									v-model="advInfo.author"
									size="mini"
								></el-input>
							</div>
						</div>

					</div>

					<div class="btn-col">
						<el-button slot="append" type="default" class="btn-search"
							@click="searchAdvanced"
							@keyup.enter="searchAdvanced"
							size="mini"
						>搜索</el-button>

						<el-button type="default" class="btn-clear"
							@click="clearAdvSearch"
							size="mini"
						>清空</el-button>
					</div>

				</div>

			</div>
		</transition>
	</div>
</template>

<script>
	import
	{
		Input,
		Button,
		Select,
		DatePicker
	}
	from 'element-ui';

	export default {
		name: 'component-search',
		data() {
			return {
				email: '',
				defaultDateTime: '',
				isShowAdvSearch: false,   // 是否展示高级搜索
				isFocus: false,			  // 是否聚焦
				appOptions: [],              // 广告位app下拉
				zoneOptions: [],           // 广告位zoneid下拉
				pchannels: [],

				keyName: '',

				advInfo: {
					startTimeBegin: '',
					startTimeEnd: '',
					endTimeBegin: '',
					endTimeEnd: '',
					// base_zone_id: '', 		// 广告位基础id
					zoneId: '', 			// 广告位id
					applicationId: '', // 父频道
					bannerName: '', 		// 广告名称
					author: '', 			// 创建人
					// search_name: '', 		// 关键字
					bannerIdBegin: '',
					bannerIdEnd: ''
				},

				applyList:  [],	/* 申请位列表 */
		        selectedApplys: [],	/*  */


		        adsPostList:  [],	/* 申请位列表 */
		        selectedAdsPosts: [],	/*  */

				isRotate: false
			};
		},
		props: {
			hasAdvSearch: {
				type: Boolean,
				default: true
			},
			curZoneId: ''
		},
		computed: {
			btnAdvSCnt() {			// 切换高级搜索按钮状态的文案
				return this.isShowAdvSearch ? '收起搜索' : '高级搜索';
			}
		},
		mounted() {
			let _vm = this;

			if (_vm.hasAdvSearch) {
				// 获取广告表单获取全部app接口（下拉)
				_vm.getAppList();
				// 获取父频道选项
				_vm.getZoneidList();
			}

			//	绑定回车事件
			// document.addEventListener('keydown', this.onKeyDown);

			//设置日历的默认时间
			var nowDate = new Date();
			var defaultStr = nowDate.getFullYear() + '-' + (nowDate.getMonth() + 1) + '-' + nowDate.getDate() + ' 10:00:00';
			this.defaultDateTime = new Date(defaultStr);
		},
		methods: {
			//	处理回车搜索
			// onKeyDown(e) {
			// 	//	回车提交-简单搜索框聚焦或者高级搜索展开后生效
			// 	if (e.keyCode === 13 && (this.isFocus || this.isShowAdvSearch)) {
			// 		this.$emit('event-search', this.getAllSearchInfo());
			// 	}
			// },

			chkSearchState() {
				// 处理模糊搜索与高级搜索切换的状态
				this.isFocus = true;
				if (this.hasAdvSearch && this.isShowAdvSearch) {
					this.isShowAdvSearch = false;
				}
			},
			setPanelAdvSearch(val) {		// 关闭or打开高级搜索面板
				this.isShowAdvSearch = val;
				// this.clearAdvSearch();
				this.$emit('event-size', val);
			},
			searchNormal() {			// 普通搜索
				var keyName = this.keyName;
				this.clearSearch();
				this.keyName = keyName;
				this.$emit('event-search', this.getAllSearchInfo());
			},
			searchAdvanced() {			// 高级搜索
				// console.log('this.advInfo', this.advInfo);
				if (this.checkAdvSCnt()) {
					this.keyName = '';
					this.$emit('event-search', this.getAllSearchInfo());
				}
			},
			clearAdvSearch() {			// 清空高级搜索
				this.clearSearch();
			},
			checkAdvSCnt() {	// 提交高级搜索前检查提交的内容
				//	时间校验
				if (!this.checkTime(this.advInfo.endTimeEnd, this.advInfo.endTimeBegin)) {
					this.$message({
						message: '结束时间必须大于开始时间',
						type: 'warning'
					});
					return false;
				}
				if (!this.checkTime(this.advInfo.startTimeEnd, this.advInfo.startTimeBegin)) {
					this.$message({
						message: '结束时间必须大于开始时间',
						type: 'warning'
					});
					return false;
				}
				return true;
			},
			checkTime(end, begin) {
				if (begin !== '' && end !== '') {
					let differ = new Date(end) - new Date(begin);
					if (differ && differ < 0) {
						return false;
					} else {
						return true;
					}
				} else {
					return true;
				}
			},


			// 获取广告app下拉列表
			getAppList() {

				/* 取出申请位列表 */
				this.$API({
					method: 'get',
					url: this.$URL.getUrl('getApplyTree'),
					params: {
						'appid': 1,
						'limit_channel': 1
					}
				}).then(result => {

					if (result.status == 200 && result.data) {
						var list = result.data;
						var tmpList = [];
						var hasRecord = false;
						for (var i = 0; i < list.length; i++) {

							var item = list[i];
							var itemId = parseInt(item.chl_id);

							var children = item.children;
							var node = {'value': itemId, 'label': item.chl_name};
							var childList = [];
							for (var j = 0; j < children.length; j++) {
								var childItem = children[j];
								var childItemId = parseInt(childItem['id']);
								var childNode = {'value': childItemId, 'label': childItem['apply_name']};
								childList.push(childNode);
							}

							node['children'] = childList;

							tmpList.push(node);
						}


						this.applyList = tmpList;


					} else {
						this.$toast({
							title: result.msg ? result.msg : '获取申请位列表失败.',
							type: 'warning'
						});
					}
				}, result => {
					this.$toast({
						title: '获取申请位列表失败！',
						type: 'warning'
					});
				});

			},

			// 广告位获取zoneid列表
			getZoneidList(id) {
				this.$API({
					method: 'get',
					url: this.$URL.getUrl('searchZones'),
					params: {
						// id: id
					}
				}).then(result => {
					if (result.status == 200) {
						this.zoneOptions = result.data;
					} else {
						console.log(result.msg);
					}
				}, err => {
					console.log(err);
				});

				/* 取出申请位列表 */
				this.$API({
					method: 'get',
					url: this.$URL.getUrl('searchZones'),
					params: {
					}
				}).then(result => {

					if (result.status == 200 && result.data) {
						var list = result.data;
						var tmpList = [];
						var hasRecord = false;
						for (var i = 0; i < list.length; i++) {

							var item = list[i];
							// var itemId = parseInt(item.chl_id);
							var itemId = i + 1;

							var children = item.children;
							var node = {'value': itemId, 'label': item.name};
							var childList = [];
							for (var j = 0; j < children.length; j++) {
								var childItem = children[j];
								var childItemId = parseInt(childItem['id']);
								var childNode = {'value': childItemId, 'label': childItem['zonename']};
								childList.push(childNode);
							}

							node['children'] = childList;

							tmpList.push(node);
						}


						this.adsPostList = tmpList;


					} else {
						this.$toast({
							title: result.msg ? result.msg : '获取zoneid列表失败.',
							type: 'warning'
						});
					}
				}, result => {
					this.$toast({
						title: '获取zoneid列表失败！',
						type: 'warning'
					});
				});

			},

			// 清除选项
			clearSearch() {

				this.keyName = '';

				this.advInfo.startTimeBegin = '';
				this.advInfo.startTimeEnd = '';
				this.advInfo.endTimeBegin = '';
				this.advInfo.endTimeEnd = '';
				// this.advInfo.base_zone_id = ''; 		// 广告位基础id 用于获取zone_id
				this.advInfo.zoneId = ''; 			// 广告位id
				this.advInfo.applicationId = ''; // 申请位
				this.advInfo.bannerName = ''; 		// 广告名称
				this.advInfo.author = ''; 			// 创建人
				// this.advInfo.search_name: ''; 		// 关键字
				this.advInfo.bannerIdBegin = '';
				this.advInfo.bannerIdEnd = '';

				this.selectedApplys = [];
				this.selectedAdsPosts = [];

			},

			//
			getAllSearchInfo() {

				var info = {};

				info.keyName = this.keyName;

				info.startTimeBegin = this.advInfo.startTimeBegin;
				info.startTimeEnd = this.advInfo.startTimeEnd;
				info.endTimeBegin = this.advInfo.endTimeBegin;
				info.endTimeEnd = this.advInfo.endTimeEnd;
				info.bannerName = this.advInfo.bannerName; 		// 广告名称
				info.author = this.advInfo.author; 			// 创建人
				info.bannerIdBegin = this.advInfo.bannerIdBegin;
				info.bannerIdEnd = this.advInfo.bannerIdEnd;

				console.log('this.selectedAdsPosts - 1: ', this.selectedAdsPosts);

				if (this.selectedAdsPosts.length > 1) {
					info.zoneId = this.selectedAdsPosts[1];
				} else {
					info.zoneId = ''; 			// 广告位id
				}

				if (this.selectedApplys.length > 1) {
					info.applicationId = this.selectedApplys[1]; // 申请位
				} else {
					info.applicationId = '';
				}

				return info;
			},

			// 查找前更新icon
			getImg(name) {
				return this.$URL.getImgUrl() + name;
			},
			updateList() {
				let vm = this;
				vm.isRotate = true;
				this.clearSearch();
				vm.$emit('event-search', this.getAllSearchInfo());
				// vm.isRotate = false;
				setTimeout(function(){vm.isRotate = false;},1000)
			}
		},
		components: {
			'el-input': Input,
			'el-button': Button,
			'el-select': Select,
			'el-date-picker': DatePicker
		}
	};
</script>

<style lang="scss">
	/*.is-danger {
		border: 1px solid 'red';
	}*/

	.u-search-wrap {

		.general-btn[disabled] {
			border-color: transparent;
		    background-color: transparent;
		    color: inherit;
		    border-top: 0;
		    border-bottom: 0;
		}

		.form-box {
			position: relative;
			width: 100%;
			min-width: 1219px;
			margin: 0 auto;
			padding: 5px 140px 5px 0;
			border: 1px solid #c0ccda;
			border-radius: 5px;
			/*border-spacing: 5px;*/

			box-sizing: border-box;
			-webkit-box-sizing: border-box;

			.adv-col1 {
				float: left;
				width: 35%;
			}

			.adv-col2 {
				float: left;
				width: 30%;
			}

			.adv-col3 {
				float: left;
				width: 35%;
				margin-right: -1px;
			}

			.btn-col {
				position: absolute;
				right: 0;
				top: 0;
				text-align: center;
				width: 140px;
			}

			.adv-row {
				position: relative;
				padding-left: 50px;
				margin-top: 5px;
			}

			.adv-row:first-child {
				margin-top: 0px;
			}

			.label {
				position: absolute;
				left: 0px;
				top: 0;
				width: 30px;
				text-align: center;
				white-space: nowrap;
				line-height: 30px;

				.inner-txt {
					position: absolute;
					right: 8px;
					top: 0;
					white-space: nowrap;
				}
			}

			.label-wrap {
				float: left;
				width: 50%;
				position: relative;
				padding-left: 30px;
				box-sizing: border-box;
				-webkit-box-sizing: border-box;
			}

			.label-wrap2 {
				padding-left: 58px;
				.label {
					width: 50px;
					text-align: right;
				}
			}

			.label-wrap:last-child {
				margin-right: -1px;
			}

			.btn-search,
			.btn-clear {
				display: block;
				width: 80px;
				color: #20a0ff;
    			border-color: #20a0ff;
    			margin: 5px auto 0 auto;
			}

			.btn-search:hover, .btn-clear:hover  {
				background: #4db3ff;
			    border-color: #4db3ff;
			    color: #fff;
			}


		}

		.fresh-btn {
			margin: 7px 15px 0 0;
			float: right;
			width: 18px;
			height: 18px;
			cursor: pointer;
		}

		.fresh-btn.update{
			animation: rotate 1s linear 1;
		}

		.td-txt {
			/*width: 30px;*/
			font-size: 13px;
		}

		.u-cnt-basic {
			position: relative;
			height: 35px;
			background: #fff;
			z-index: 899;
			margin-right: 10px;
		}
		.u-cnt-advanced {
			position: relative;
			z-index: 898;
			background: #fff;
			margin: 0 auto;
			width: 100%;
			transition: transform .5s cubic-bezier(.23,1,.32,1) .1s,opacity .5s cubic-bezier(.23,1,.32,1) .1s;
			transform:translateY(0px);

			/*.btn-close {
				position: absolute;
				top: 8px;
				right: 8px;
				color: #999;

				&:hover {
					color: #6b6868;
				}

				&:active {
					color: #524d4d;
				}
			}*/
		}
		.u-cnt-advanced.fade-leave-active{
			transform:translateY(-50px);
			opacity:0;
		}
		.u-cnt-advanced.fade-enter {
			transform:translateY(-50px);
			opacity:0;
		}

		.u-search-normal {
			float: right;
			display: inline-block;
			margin-right: 10px;
			&.shorten {
				width: 300px;
			}
		}


		.btn-search-advance {
			float: right;
			margin: 2px 0px 0 0;
			vertical-align: top;
			min-width: 80px;
			color: #bfcbd9;
			span{
				text-decoration:underline;
			}
		}

	}

</style>