<template>
  <div class="m-multi-selection clearfix">
    <div class="u-cont">
      <div class="u-box" v-for="number in box.length" :key="number">
        <ul class="u-list">
          <li
            :class="[{ hover: (number != box.length && number != order.length && order[number-1] == index) || labelResult.indexOf(box[number-1][index].label) != -1, 'u-disabled': val.checked}, 'u-item']"
            v-for="(val, index) in box[number-1]"
            @click="selectItem(number, index)"
            :key="index"
          >
            {{val.label}}
          </li>
        </ul>
      </div>
      <div class="u-box" v-for="number in (num - box.length)" :key="number">
        <ul class="u-list"></ul>
      </div>
    </div>
    <div class="u-btn">
      <span class="s-btn-narrow" @click="save()">&gt;&gt;</span>
      <span class="s-btn-narrow" @click="del()">&lt;&lt;</span>
    </div>
    <div class="u-box u-result">
      <ul class="u-list">
        <li
          :class="[{ 'hover': rubbish.indexOf(results[index]) != -1 }, 'u-item']"
          v-for="(val, index) in results"
          @click="delItem(index)"
          :key="index"
        >
          {{val.label}}
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
  import Vue from 'vue';

  export default {
    data() {
      return {
        box: [],
        result: [],
        results: [],
        rubbish: [],
        number: 1,
        preNumber: 0,
        isHover: false,
        clickIndex: [[0]],
        rubbishClickIndex: 0,
        order: []
      };
    },
    props: {
      // 初始数据
      array: {
        type: Array
      },
      num: {
        type: Number
      }
    },
    computed: {
      labelResult() {
        return this.result.map(function(val, index) {
          return val.label;
        });
      }
    },
    mounted() {
      this.intBox(1, 0, false);
      this.save();
    },
    methods: {
      // 初始化选择框 number:需要开第n个框 index:该框的第n+1个菜单被选中 isOpen:是否打开该菜单的子菜单
      intBox(number, index, isOpen) {
        let arr = this.array;

        this.order[number - 1] = index;
        if (isOpen) {
          this.order[number] = 0;
          this.order.length = number + 1;
        } else {
          this.order.length = number;
        }

        for (let i = 0; i < this.order.length - 1; i++) {
          arr = arr[this.order[i]].subs;
        }

        const data = [];
        for (let j = 0; j < arr.length; j++) {
          data.push({
            label: arr[j].label,
            checked: arr[j].checked
          });
        }

        if (data.length > 0) {
          Vue.set(this.box, this.order.length - 1, data);
          this.box.length = this.order.length;
        } else {
          this.box.length = this.order.length - 1;
        }
      },

      selectItem(number, index) {
        let arr = this.box[number - 1];

        if (number < this.preNumber) {
          // 往前几层点击框 则初始化后面几层的clickIndex
          let length1 = this.preNumber - number;
          while (length1) {
            this.clickIndex[this.preNumber - 1] = 0;
            length1--;
          }
        }
        if (number !== this.preNumber) {
          // 前后两次点击的框不同 删除result数据
          this.result = [];
          this.preNumber = number;
        }

        // 最新版的chrome,firefox,safari才支持metakey
        if (event.altKey) {
          // 按住alt选择头尾多个
          let minIndex = Math.min(index, this.clickIndex[number - 1]);
          let maxIndex = Math.max(index, this.clickIndex[number - 1]);
          let length2 = maxIndex - minIndex + 1;
          const res = [];
          while (length2) {
            let lastIndex = minIndex++;
            if (!arr[lastIndex].checked) res.push(arr[lastIndex]);
            length2--;
          }
          this.result = res;
          this.intBox(number, index, false);
        } else if (event.ctrlKey || event.metaKey) {
          // 按 ctrl 或 command多选
          let which = this.result.indexOf(arr[index]);
          if (which !== -1) {
            this.result.splice(which, 1);
          } else {
            this.result.push(arr[index]);
          }
          this.intBox(number, index, false);
        } else {
          // 单选
          this.result = [arr[index]];
          this.intBox(number, index, true);
        }
        this.number = number;
        this.clickIndex[number - 1] = index;
      },

      delItem(index) {
        let arr = this.results;

        // 最新版的chrome,firefox,safari才支持metakey
        if (event.altKey) {
          // 按住alt选择头尾多个
          let minIndex = Math.min(index, this.rubbishClickIndex);
          let maxIndex = Math.max(index, this.rubbishClickIndex);
          let length = maxIndex - minIndex + 1;
          const res = [];
          while (length) {
            res.push(arr[minIndex++]);
            length--;
          }
          this.rubbish = res;
        } else if (event.ctrlKey || event.metaKey) {
          // 按 ctrl 或 command多选
          let which = this.rubbish.indexOf(arr[index]);
          if (which !== -1) {
            this.rubbish.splice(which, 1);
          } else {
            this.rubbish.push(arr[index]);
          }
        } else {
          // 单选
          this.rubbish = [arr[index]];
        }

        this.rubbishClickIndex = index;
      },
      // 保存
      save() {
        let number = this.number;
        let order = this.order;

        let arr = this.array;
        for (let i = 0; i < number - 1; i++) {
          arr = arr[order[i]].subs;
        }
        for (let j = 0; j < arr.length; j++) {
          if (this.labelResult.indexOf(arr[j].label) !== -1) arr[j].checked = true;
        }
        this.intBox(number, 0, false);
        this.results = this.getArray(this.array);

        // 模拟点击上一层
        if (number !== 1) {
          this.result = [this.box[number - 2][this.order[number - 2]]];
          this.number = this.number - 1;
        } else {
          this.result = [];
        }
      },
      // 删除
      del() {
        for (let i = 0; i < this.rubbish.length; i++) {
          this.rubbish[i].item.checked = false;
        }
        this.intBox(this.number, 0, false);
        this.results = this.getArray(this.array);
      },

      // 遍历结果
      getArray(arr, name) {
        let res = [];
        let path = name || '';

        for (let i = 0; i < arr.length; i++) {
          let item = arr[i];
          let label = path + ' ' + item.label;

          if (item.checked) {
            res.push({
              item: item,
              label: label
            });
            if (item.subs.length > 0) this.setChecked(item.subs);
          } else if (item.subs && item.subs.length > 0) {
            res = res.concat(this.getArray(item.subs, label));
          }
        }

        return res;
      },

      // 遍历checked为true的item是其下数组的checked为false
      setChecked(arr) {
        for (let i = 0; i < arr.length; i++) {
          let item = arr[i];
          item.checked = false;
          if (item.subs.length > 0) this.setChecked(item.subs);
        }
      }
    }
  };
</script>

<style lang="scss">
  @import '../../static/styles/mixin';

  .m-multi-selection {
    .u-cont,.u-btn,.u-result {
      float: left;
    }
    .u-box {
      @include selectBox;
      float: left;
      margin-right: 20px;
    }
    .u-list {
      @include selectList;
    }
    .u-item {
      @include selectItem;
    }
    .u-disabled {
      display: none;
    }
    .u-btn {
      margin-right: 20px;
      .s-btn-narrow:nth-of-type(2) {
        margin-top: 16px;
      }
    }
  }
</style>