'use strict'

import Vue from 'vue';
import toast from './index.vue'

let ToastConstructor = Vue.extend(toast);

let instance;

var Toast = function(options) {
  // options = options || {};

  if (!instance) {
    instance = new ToastConstructor();
    instance.vm = instance.$mount();
    document.body.appendChild(instance.vm.$el);
    // instance.vm.visible = true;
    instance.dom = instance.vm.$el;
  }

  instance.vm.set(options);
  // instance.vm.$set(options);
  instance.vm.show();
  return instance.vm;
};

export default Toast;
