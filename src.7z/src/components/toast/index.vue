<template>
	<transition name="com-toast-fade">
		<div class="com-toast-box" v-if="isShow">
			<el-alert
				:title="title"
				:type="type"
				:closable="false"
				show-icon>
			</el-alert>
			<i class="toast-close" @click="close"></i>
		</div>
	</transition>
</template>

<script>
	export default {
		props: {},

		data: function() {
			return {
				title: '文本信息',
				type: 'success',
				duration: 3000,
				isShow: false,
				_timerId: null
			};
		},

		created() {
			// console.log(1);
			// this.isShow = true;
		},

		methods: {

			set(options) {
				options = options || {};
				if (typeof options === 'string') {
					var tmpTitle = options;
					options = {};
					options.title = tmpTitle;
				}
				var type = this._getType(options.type);
				var title = options.title ? options.title : '提示信息';
				var duration = options.duration ? options.duration : 3000;
				this.title = title;
				this.type = type;
				this.duration = duration;
			},

			show() {
				if (!this.isShow) {
					this.isShow = true;
				}
				this._stopTimer();
				this._startTimer();
			},

			close() {
				if (this.isShow) {
					this._stopTimer();
					this.isShow = false;
				}
			},

			_startTimer() {
				this._timerId = setTimeout(() => {
					this._timerHandler();
				}, this.duration);
			},

			_stopTimer() {
				if (this._timerId) {
					clearTimeout(this._timerId);
					this._timerId = null;
				}
			},

			_timerHandler() {
				this._stopTimer();
				this.isShow = false;
			},

			_getType(type) {
				switch (type) {
					case 'success':
						return 'success';
					case 'warning':
						return 'warning';
					case 'info':
						return 'info';
					case 'error':
						return 'error';
					default:
						return 'warning';
				}
			}

		}
	};
</script>

<style lang="scss" scoped>

	.com-toast-fade-enter-active, .com-toast-fade-leave-active {
		transition: opacity .5s
	}

	.com-toast-fade-enter, .com-toast-fade-leave-active {
		opacity: 0
	}

	.com-toast-box {
		position: fixed;
		left: 50%;
		top: 50%;
		width: 500px;
		height: 35px;
		margin: -17px 0 0 -200px;
		z-index: 20000;

		.toast-close {
			font-family: element-icons!important;
		    speak: none;
		    font-style: normal;
		    font-weight: 400;
		    font-variant: normal;
		    text-transform: none;
		    line-height: 1;
		    vertical-align: baseline;
		    display: inline-block;
		    -webkit-font-smoothing: antialiased;
		    font-size: 12px;
		    color: #fff;
		    opacity: 1;
		    top: 12px;
		    right: 15px;
		    position: absolute;
		    cursor: pointer;
		    &:hover {
		    	color: #aaa;
		    }
		}

		.toast-close::before {
			content: "\E60C";
		}
	}
</style>