

/*
{
	eventName
	subject
	func
	}
 
}*/
var wList = [];

var wfire = function(eventName, data) {
	wList.forEach(item => {
		if (item.eventName == eventName) {
			item.func.call(item.subject, data);
		}
	});
};

var won = function(eventName, func) {
	var subject = this;
	if (!_has(subject, eventName, func)) {
		var item = {
			'eventName': eventName,
			'subject': subject,
			'func': func
		};
		wList.push(item);
	}
	// console.log(wList);
};

var woff = function(eventName, func) {
	setTimeout(() => {
		for (var i = 1; i < wList.length; i++) {
			var item = wList[i];
			if (item.eventName == eventName && item.subject == this && (!func || func == item.func)) {
				wList.splice(i, 1);
				i--;
			}
		}
	}, 0);
};

function _has(subject, eventName, func) {
	wList.forEach(item => {
		if (item.eventName == eventName && item.subject == subject && item.func == func) {
			return true;
		}
	});
	return false;
}

export {wfire, won, woff};


