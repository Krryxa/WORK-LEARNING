'use strict'

import Vue from 'vue';
import picmanager from './index.vue'

let PicmanagerConstructor = Vue.extend(picmanager);

let instance;

var Picmanager = function (options) {
  // options = options || {};

  if (!instance) {
    instance = new PicmanagerConstructor();
    instance.vm = instance.$mount();
    document.body.appendChild(instance.vm.$el);
    // instance.vm.visible = true;
    instance.dom = instance.vm.$el;
  }

  instance.vm.set(options);
  instance.vm.show();
  return instance.vm;
};

export default Picmanager;
