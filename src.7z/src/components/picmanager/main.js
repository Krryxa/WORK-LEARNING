import Picmanager from './index.js';

const install = function(Vue, opts = {}) {
  /* istanbul ignore if */
  if (install.installed) return;

  // Vue.component('picmanager', Picmanager);

  Vue.prototype.$picmanager = Picmanager;
};

/* istanbul ignore if */
if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue);
}

// module.exports = {
export default {
  version: '1.1.6',
  install,
  Picmanager
};
