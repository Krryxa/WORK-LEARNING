<template>
	<transition name="com-picmanager-fade">
		<div class="com-picmanager-box" v-if="isShow">
			<div class="picmanager-panel">
				<i class="picmanager-close el-icon-close" @click="close"></i>
				<header>从图片库选择</header>
				<div class="picmanager-body clearfix">
					<div class="nav-side" v-loading="isNavLoading">
						<div class="nav-search">
							<el-input placeholder="输入三级分类名称" v-model="searchTxt" class="input-search" prefix-icon="el-icon-search" size="mini" @input="changeSearch"></el-input>
						</div>
						<ul class="nav-list">
							<template v-if="hasShowNav">
								<li v-if="navItem.isShow" :class="[{ 'is-focus': navItem.isFocus}, 'nav-bar']" v-for="navItem in navList" :key="navItem.id" @click="clickNavBar(navItem)">
									{{navItem.categoryId}} {{navItem.categoryName}}
								</li>
							</template>
							<li class="none-txt" v-else>无数据</li>
						</ul>
					</div>
					<div class="cnt-side">
						<div class="img-prompt">每个分类可选 1 张</div>
						<ul class="img-list clearfix" v-loading="isImgLoading">
							<template v-if="imgList.length > 0">
								<li class="img-bar" v-for="imgItem in imgList" :key="imgItem.id" @click="clickImgIconBar(imgItem)">
									<div class="icon">
										<img :src="imgItem.url">
										<div class="mask" v-if="imgItem.isSelected">
											<i class="el-icon-check"></i>
										</div>
									</div>
									<div class="size">{{imgItem.width}} * {{imgItem.height}}</div>
									<div class="name">{{imgItem.picName}}</div>
								</li>
							</template>
							<li class="none-txt" v-else>无数据</li>
						</ul>
					</div>
				</div>
				<div class="picmanager-select clearfix">
					<div class="selected-txt">已选 {{selectedList.length}} 张图片，还可选 {{remainNum}} 张</div>
					<ul class="selected-list clearfix">
						<template v-if="selectedList.length > 0">
							<li class="selected-bar" v-for="selectedItem in selectedList" :key="selectedItem.id">
								<div class="icon">
									<img :src="selectedItem.url">
									<div class="mask">
										<el-tooltip class="item" effect="dark" content="删除" placement="bottom">
											<i class="el-icon-delete delete" @click="clickDelete(selectedItem)"></i>
										</el-tooltip>
									</div>
									<el-tooltip class="item" effect="dark" :content="selectedItem.isDefault?'取消默认':'设置默认'" placement="top">
				                      <i :class="[selectedItem.isDefault?'el-icon-star-on favorite-on':'el-icon-star-off favorite-off', 'favorite']"  @click="clickFavorite(selectedItem)"></i>
				                    </el-tooltip>
								</div>
								<div class="name" v-if="selectedItem.categoryName">{{selectedItem.categoryName}}</div>
							</li>
						</template>
						<li class="none-txt" v-else>无数据</li>
					</ul>
				</div>
				<footer>
					<el-button type="primary" size="mini" :disabled="isNavLoading" @click="clickConfirm">确定</el-button>
					<el-button class="cancel-btn" size="mini" @click="close">取消</el-button>
				</footer>
			</div>
		</div>
	</transition>
</template>
<script>

	import utils from '../../libs/utils';

	export default {
		props: {},

		data: function() {
			return {

				isShow: false,

				maxNum: 20,
				onSelect: null,
				onCancel: null,
				selectedList: [],

				searchTxt: '',
				navList: [],
				isNavLoading: false,

				imgList: [],
				isImgLoading: false,

				ajaxIndex: 0

			};
		},

		created() {
			// console.log(1);
			// this.isShow = true;
		},

		computed: {
			/* 是否有显示的左边导航（类型） */
			hasShowNav() {
				var navList = this.navList;
				for (var i = 0; i < navList.length; i++) {
					if (navList[i].isShow) {
						return true;
					}
				}
				return false;
			},

			remainNum() {
				var num = this.maxNum - this.selectedList.length;
				return num > 0 ? num : 0;
			}
		},

		methods: {

			set(options) {
				options = options || {};
				var maxNum = options.maxNum ? options.maxNum : 20;
				var onSelect = options.onSelect ? options.onSelect : null;
				var onCancel = options.onCancel ? options.onCancel : null;
				var selectedList = options.list ? utils.deepCopy(options.list) : [];
				var context = options.context ? options.context : null;
				this.context = context;
				this.maxNum = maxNum;
				this.onSelect = onSelect;
				this.onCancel = onCancel;
				this.selectedList = selectedList;
			},

			show() {
				// console.log('this.isShow = ' + this.isShow);
				if (!this.isShow) {
					this.isShow = true;
				}

				this.isNavLoading = true;
				this.searchTxt = '';
				this.navList = [];

				this.isImgLoading = false;
				this.imgList = [];

				var ajaxIndex = ++this.ajaxIndex;

				this.$API({
					method: 'get',
					url: this.$URL.getUrl('getCategoryList'),
					params: {
						'getall': 1
					}
				}).then(result => {

					this.isNavLoading = false;
					if ((ajaxIndex !== this.ajaxIndex) || (!this.isShow)) {
						return;		/* 过期了，不必理会 */
					}
					if (result.status == 200 && result.data) {
						/*
										 {
				            "id": "133",
				            "category_id": "20496",
				            "category_name": "男款毛衣",
				            "pic_num": "0",
				            "editor": "peter01.chen",
				            "is_delete": "0",
				            "full_name": "男装-毛衣/针织衫-男款毛衣"
				        },
						 */
						var tmpList = [];
						result.data.forEach((item) => {
							var newItem = {};
							newItem.id = item.id;
							newItem.categoryId = item.category_id;
							newItem.categoryName = item.category_name;
							newItem.editor = item.editor;
							newItem.fullName = item.full_name;
							newItem.isDelete = item.is_delete;
							newItem.picNum = item.pic_num;
							newItem.isFocus = false;
							newItem.isShow = true;
							tmpList.push(newItem);
						});

						if (tmpList.length > 0) {
							this.navList = tmpList;
						}

					} else {
						this.$toast({
							title: result.msg ? result.msg : '获取图片库列表失败.',
							type: 'warning'
						});
					}
				}, result => {
					this.isNavLoading = false;
					this.$toast({
						title: '获取图片库列表失败！',
						type: 'warning'
					});
				});

			},

			close() {
				if (this.isShow) {
					// this._stopTimer();
					this.isShow = false;
				}
				this.onCancel && this.onCancel.call(this.context);
			},

			clickNavBar(navItem) {
				// console.log(navItem)
				if (!navItem.isFocus) {

					this.navList.forEach((item) => {
						item.isFocus = false;
					});
					navItem.isFocus = true;

					this.isImgLoading = true;

					var ajaxIndex = ++this.ajaxIndex;

					this.$API({
						method: 'get',
						url: this.$URL.getUrl('getCategoryPicList'),
						params: {
							'getall': 1,
							'cid': navItem.id
						}
					}).then(result => {

						this.isImgLoading = false;
						if ((ajaxIndex !== this.ajaxIndex) || (!this.isShow)) {
							return;		/* 过期了，不必理会 */
						}
						if (result.status == 200 && result.data) {
							/*
							{
					            "id": "269",
					            "pic_url": "http://b.appsimg.com/2016/12/16/8277/14818823226492.jpg",
					            "pic_name": "1477021580",
					            "editor": "xiaojiang.zhang",
					            "width": "750",
					            "height": "360",
					            "category_id": "99",
					            "is_delete": "0"
					        }
							 */
							var tmpList = [];
							result.data.forEach((item) => {
								var newItem = {};
								newItem.id = item.id;
								newItem.categoryId = item.category_id;
								newItem.categoryName = navItem.categoryName;
								newItem.url = item.pic_url;
								newItem.picName = item.pic_name;
								newItem.isDelete = item.is_delete;
								newItem.width = item.width;
								newItem.height = item.height;
								newItem.editor = item.editor;
								// newItem.isFocus = false;
								newItem.isSelected = this.isSelectedId(item.id);
								tmpList.push(newItem);
							});

							if (tmpList.length > 0) {
								this.imgList = tmpList;
							}

						} else {
							this.$toast({
								title: result.msg ? result.msg : '获取图片列表失败.',
								type: 'warning'
							});
						}
					}, result => {
						this.isImgLoading = false;
						this.$toast({
							title: '获取图片列表失败！',
							type: 'warning'
						});
					});

				}
			},

			clickImgIconBar(imgItem) {
				// console.log(imgItem);
				if (!imgItem.isSelected) {

					if (this.selectedList.length >= this.maxNum) {
						this.$toast({
							title: '最多只能选择' + this.maxNum + '图片',
							type: 'warning'
						});
						return;
					}

					this.imgList.forEach((item) => {
						item.isSelected = false;
						//删除这个种类的图片,为什么不用categoryId比较，因为广告初始化时没有categoryId传入来，所以不能用categoryId比较
						for (var i = 0; i < this.selectedList.length; i++) {
							var selectedItem = this.selectedList[i];
							if (selectedItem.id == item.id) {
								this.selectedList.splice(i, 1);
								break;
							}
						}
					});
					imgItem.isSelected = true;

					//删除这个种类的图片
					// for (var i = 0; i < this.selectedList.length; i++) {
					// 	var selectedItem = this.selectedList[i];
					// 	if (selectedItem.categoryId == imgItem.categoryId) {
					// 		this.selectedList.splice(i, 1);
					// 		i--;
					// 	}
					// }

					//把选择的这个放在第一位
					var tmpItem = this.newSelectedItem(imgItem);
					this.selectedList.unshift(tmpItem);
				}
			},

			clickDelete(selectedItem) {
				//删除这个的图片
				for (var i = 0; i < this.selectedList.length; i++) {
					var curSelectedItem = this.selectedList[i];
					if (curSelectedItem.id == selectedItem.id) {
						this.selectedList.splice(i, 1);
						i--;
					}
				}

				//同步当前的图片列表
				if (this.imgList.length == 0 || (this.imgList[0].categoryId != selectedItem.categoryId) ) {
					return;
				}
				for (var i = 0; i < this.imgList.length; i++) {
					var imgItem = this.imgList[i];
					if (imgItem.id == imgItem.id) {
						imgItem.isSelected = false;
						break;
					}
				}
			},

			clickFavorite(selectedItem) {
				if (selectedItem.isDefault) {
					selectedItem.isDefault = 0;
				} else {
					for (var i = 0;  i < this.selectedList.length; i++) {
						if (this.selectedList[i].isDefault) {  //删除其余的
							this.selectedList[i].isDefault = 0;
						}
					}
					selectedItem.isDefault = 1;
				}
			},


			isSelectedId(id) {
				for (var i = 0; i < this.selectedList.length; i++) {
					var selectedItem = this.selectedList[i];
					if (selectedItem.id == id) {
						return true;
					}
				}
				return false;
			},

			changeSearch() {
				// console.log('changeSearch');
				if (this.searchTxt) {
					// var newProvinces = [];
					this.navList.forEach((item) => {
						if (utils.hasSearch(this.searchTxt, item.categoryName)) {
							if (!item.isShow) {
								item.isShow = true;
							}
						} else if(item.isShow) {
							item.isShow = false;
						}
					});

				} else {
					this.navList.forEach((item) => {
						if(!item.isShow) {
							item.isShow = true;
						}
					});
				}
			},

			clickConfirm() {
				this.isShow = false;
				this.onSelect && this.onSelect.call(this.context, utils.deepCopy(this.selectedList) );
			},

			newSelectedItem(imgItem) {
				var newItem = {};
				newItem.id = imgItem.id;
				newItem.categoryName = imgItem.categoryName;
				newItem.url = imgItem.url;
				newItem.picName = imgItem.picName;
				newItem.width = imgItem.width;
				newItem.height = imgItem.height;
				newItem.isDefault = 0;
				return newItem;
			}

		}
	};
</script>

<style lang="scss" scoped>

	$txtHeight: 40px;
	$listHeight: 320px;
	$borderColor: #c7c7c7;

	.com-picmanager-fade-enter-active, .com-picmanager-fade-leave-active {
		transition: opacity .5s
	}

	.com-picmanager-fade-enter, .com-picmanager-fade-leave-active {
		opacity: 0
	}

	.com-picmanager-box {
		position: fixed;
		left: 0;
		top: 0;
		bottom: 0;
		right: 0;
		margin: 0 auto;
		padding: 0;
		z-index: 2000;
		font-size: 14px;
		border: 1px solid $borderColor;

		background-color: rgba(0, 0, 0, 0.5);
		display: -webkit-box; /* OLD - iOS 6-, Safari 3.1-6 */
	    display: -moz-box; /* OLD - Firefox 19- (buggy but mostly works) */
	    display: -ms-flexbox; /* TWEENER - IE 10 */
	    display: -webkit-flex; /* NEW - Chrome */
	    display: flex; /* NEW, Spec - Opera 12.1, Firefox 20+ */
	    align-items:center;
	    justify-content: center;

	    box-sizing: border-box;
	    -webkit-box-sizing: border-box;


		.picmanager-close {
			position: absolute;
			top: 10px;
			right: 10px;
			transition: transform 0.5s;
			font-size: 20px;
			cursor: pointer;

		    &:hover {
		    	transform: rotate(360deg);
		    }
		}

		.picmanager-panel {
			position: relative;
			width: 820px;
			background-color: #fff;
			border-radius: 4px;
		}

		header {
			margin: 0;
			padding: 0 15px;
			display: block;
			text-align: left;
			line-height: 40px;
			font-size: 18px;
			border-bottom: 1px solid $borderColor;
		}

		.nav-side {
			float: left;
			width: 185px;
			border-right: 1px solid $borderColor;
		}

		.cnt-side {
			float: left;
			width: 634px;
		}

		.nav-search {
			height: $txtHeight;
			margin: 0;
			padding: 0 10px;

			box-sizing: border-box;
	    	-webkit-box-sizing: border-box;

	    	border-bottom: 1px solid #e1e0e0;
		}

		.input-search {
			margin-top: 6px;

			.el-input-group__append {
				padding-left: 10px !important;
				padding-right: 10px !important;
			}
		}

		.nav-list {
			height: $listHeight;
			margin: 0 auto;
			padding: 0;
			list-style: none;
			overflow: auto;

			.nav-bar {
				display: block;
				margin: 0;
				padding: 6px 0 6px 10px;
				text-align: left;
				line-height: 18px;
				cursor: pointer;
			}

			.nav-bar:hover {
				background: #dfe0e2;
			}

			.nav-bar.is-focus {
				background: #d3d5d7;
			}

			.none-txt {
				color: #909399;
				padding: 20px 0 0 60px;
				text-align: left;
			}
		}

		.img-prompt {
			height: $txtHeight;
			line-height: $txtHeight;
			padding-right: 15px;
			text-align: right;
			color: #999;
		}

		.img-list {
			height: $listHeight;
			margin: 0 auto;
			padding: 0;
			list-style: none;
			overflow: auto;

			.img-bar {
				float: left;
				display: inline-block;
				margin: 15px;
				padding: 0;
				width: 110px;

				font-size: 13px;

				cursor: pointer;

				* {
					cursor: pointer;
				}
			}

			.icon {
				display: -webkit-box; /* OLD - iOS 6-, Safari 3.1-6 */
			    display: -moz-box; /* OLD - Firefox 19- (buggy but mostly works) */
			    display: -ms-flexbox; /* TWEENER - IE 10 */
			    display: -webkit-flex; /* NEW - Chrome */
			    display: flex; /* NEW, Spec - Opera 12.1, Firefox 20+ */
			    align-items:center;
			    justify-content: center;

			    box-sizing: border-box;
			    -webkit-box-sizing: border-box;

			    position: relative;
			    height: 108px;

			    border: 1px solid #eee;

			    img {
			    	max-width: 100%;
			    	max-height: 100%;
			    	display: block;
			    	margin: auto;
			    }
			}

			.mask {

				display: -webkit-box; /* OLD - iOS 6-, Safari 3.1-6 */
			    display: -moz-box; /* OLD - Firefox 19- (buggy but mostly works) */
			    display: -ms-flexbox; /* TWEENER - IE 10 */
			    display: -webkit-flex; /* NEW - Chrome */
			    display: flex; /* NEW, Spec - Opera 12.1, Firefox 20+ */
			    align-items:center;
			    justify-content: center;

				position: absolute;
				left: 0;
				top: 0;
				bottom: 0;
				right: 0;
				background-color: rgba(0,0,0, 0.5);

				font-size: 28px;
    			color: #67C23A;
			}

			.size {
				margin-top: 3px;
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
				line-height: 20px;
				text-align: center;
			}

			.name {
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
				line-height: 20px;
				text-align: center;
			}

			.none-txt {
				color: #909399;
				padding: 20px 0 0 60px;
				text-align: center;
				padding-right: 50px;
			}

		}

		.picmanager-select {
			border-top: 1px solid $borderColor;
		}

		.selected-txt {
			margin: 0 auto;
			padding: 0 20px;
			line-height: 30px;
			text-align: left;
			color: #999;
			font-size: 14px;
		}

		.selected-list {
			height: 160px;
			margin: 0 auto;
			padding: 0;
			list-style: none;
			overflow: auto;

			.selected-bar {
				float: left;
				display: inline-block;
				margin: 10px 15px;
				padding: 0;
				width: 110px;

				font-size: 13px;

				cursor: pointer;

				* {
					cursor: pointer;
				}

				&:hover .mask {
					display: block;
			    };

			    &:hover .favorite-off {
					display: block;
				};
			}

			.icon {
				display: -webkit-box; /* OLD - iOS 6-, Safari 3.1-6 */
			    display: -moz-box; /* OLD - Firefox 19- (buggy but mostly works) */
			    display: -ms-flexbox; /* TWEENER - IE 10 */
			    display: -webkit-flex; /* NEW - Chrome */
			    display: flex; /* NEW, Spec - Opera 12.1, Firefox 20+ */
			    align-items:center;
			    justify-content: center;

			    box-sizing: border-box;
			    -webkit-box-sizing: border-box;

			    position: relative;
			    height: 108px;

			    border: 1px solid #eee;

			    img {
			    	max-width: 100%;
			    	max-height: 100%;
			    	display: block;
			    	margin: auto;
			    }
			}

			.mask {

				position: absolute;
				left: 0;
				top: 0;
				bottom: 0;
				right: 0;
				background-color: rgba(0,0,0, 0.5);

				font-size: 20px;
    			display: none;
			}

			.delete {
				position: absolute;
				right: 5px;
				bottom: 5px;
				color: #F56C6C;
			}

			.delete:hover {
				color: #fa1807;
			}

			.favorite {
				position: absolute;
				right: 5px;
				top: 5px;
				font-size: 21px;
				color: #F56C6C;
				outline: none;
			}

			.favorite:hover {
				color: #fa1807;
			}

			.favorite-off {
				display: none;
			}

			.favorite-on {
				color: #F56C6C;
			}


			.name {
				margin-top: 3px;
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
				line-height: 20px;
				text-align: center;
			}

			.none-txt {
				color: #909399;
				padding: 20px 0 0 60px;
				text-align: center;
				padding-right: 50px;
			}
		}

		footer {
			margin: 0 auto;
			padding: 10px 0;
			border-top: 1px solid $borderColor;
			text-align: center;
		}

		.cancel-btn {
			margin-left: 40px;
		}

	}
</style>