<template>
	<transition name="com-sysmask-fade">
		<div class="com-sysmask-box" v-if="isShow">
			<div class="sysmask-box">{{title}}</div>
		</div>
	</transition>
</template>
<script>

	export default {
		props: {},

		data: function() {
			return {
				title: '文本信息',
				isShow: false,
			};
		},

		created() {
			// console.log(1);
			// this.isShow = true;
		},

		methods: {

			set(txt) {
				var title = txt ? txt : '文本信息';
				this.title = title;
			},

			show() {
				if (!this.isShow) {
					this.isShow = true;
				}
			}

		}
	};
</script>
<style lang="scss" scoped>
	
	.com-sysmask-fade-enter-active, .com-sysmask-fade-leave-active {
		transition: opacity .5s
	}

	.com-sysmask-fade-enter, .com-sysmask-fade-leave-active {
		opacity: 0
	}

	.com-sysmask-box {
		position: fixed;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		margin: 0;
		padding: 0;
		z-index: 20001;
		background: rgba(0, 0, 0, 0.5);

		display: -webkit-box; /* OLD - iOS 6-, Safari 3.1-6 */ 
	    display: -moz-box; /* OLD - Firefox 19- (buggy but mostly works) */ 
	    display: -ms-flexbox; /* TWEENER - IE 10 */ 
	    display: -webkit-flex; /* NEW - Chrome */ 
	    display: flex; /* NEW, Spec - Opera 12.1, Firefox 20+ */
	    align-items:center;
	    justify-content: center;


		.sysmask-box {
			margin: 0 auto;
			padding: 20px 30px;
			max-width: 830px;
			background: #f90;
			font-size: 26px;
			line-height: 40px;
			color: #fff;
		}

	}
</style>