import Sysmask from './index.js';

const install = function(Vue, opts = {}) {
  /* istanbul ignore if */
  if (install.installed) return;

  // Vue.component('Sysmask', Sysmask);

  Vue.prototype.$sysmask = Sysmask;
};

/* istanbul ignore if */
if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue);
}

// module.exports = {
export default {
  version: '1.1.6',
  install,
  Sysmask
};
