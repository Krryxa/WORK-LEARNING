'use strict'

import Vue from 'vue';
import sysmask from './index.vue'

let SysmaskConstructor = Vue.extend(sysmask);

let instance;

var Sysmask = function (txt) {
  // options = options || {};

  if (!instance) {
    instance = new SysmaskConstructor();
    instance.vm = instance.$mount();
    document.body.appendChild(instance.vm.$el);
    // instance.vm.visible = true;
    instance.dom = instance.vm.$el;
  }

  instance.vm.set(txt);
  instance.vm.show();
  return instance.vm;
};

export default Sysmask;
