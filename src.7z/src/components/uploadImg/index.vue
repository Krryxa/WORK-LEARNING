<!--上传图片组件-->
<template>
	<div class="u-uploadImg">
		<div class="u-uploadingImg-con">
			<div class="u-uploadingImg-mask"
				v-show="loading"
			>
				<i class="el-icon-loading"></i>
			</div>
			<div class="u-uploadingImg-blank"
				v-show="!imgUrl"
				@click="selectFile"
			>
				<i class="el-icon-plus"></i>
				<span>{{ text }}</span>
			</div>
			<div class="u-uploadingImg-img"
				:class="{'column': imgSetting.size.width > imgSetting.size.height}"
			>
				<img 
					:src="imgUrl"
					@click="selectFile"
					@load="imageLoaded"
				>
				<i class="el-icon-delete2"
					@click="deleteImg"
				></i>
			</div>
		</div>
		<div class="u-uploadingImg-text">
			<span>{{ imgSetting.sizeText }}</span>
		</div>
		<input type="file" class="u-uploadingImg-input j-uploadingImg-input"
			:accept="imgSetting.acceptText"
			@change="inputChange"
			@click="inputClick"
		>
	</div>
</template>

<script>

	export default {
		name: 'upload-image',
		data() {
			return {
				imgUrl: '',						// 图片显示的url
				isPreview: false,				// 当前是否在预览图片
				uploadedImgUrl: null,			// 图片上传后的url
				loading: false,					// 是否显示loading
				text: '',						// 显示的文字
				response: {},					// 上传的返回值
				imgSetting: {					// 图片设置
					size: {						// 图片尺寸
						width: 0,				// 宽度
						height: 0				// 高度
					},
					checkSize: true,			// 是否检查图片宽高
					acceptText: 'image/jpeg,image/gif,image/png',	// 在input中使用的accept值
					allowTypesText: 'jpg、png、gif',					// 用户选错文件类型时的提示
					maxSize: 0,					// 最大允许上传的图片大小
					sizeText: '0 X 0'			// 显示的图片尺寸
				},
				imgInfo: {						// 文件信息
					fileName: '',				// 文件名
					fileSize: 0,				// 文件大小
					fileType: 0					// 文件类型
				}
			};
		},
		props: [
			'imageWidth',       // 图片宽度
			'imageHeight',      // 图片高度
			'changeEventName',  // 图片变化的回调函数
			'imageSize',    	// 图片大小
			'imageTypes',		// 图片类型数组
			'imageUrl',			// 图片url
			'imageIdentity',	// 组件唯一标志
			'uploadUrl',		// 上传服务器的url
			'infoText'          // 提示文本
		],
		methods: {
			// 选择文件
			selectFile() {
				this.$el.querySelector('.j-uploadingImg-input').click();
			},
			// 上传文件
			uploadFile(file) {
				let formData = new FormData();
				formData.append('userfile', file);
				// 预览
				this.isPreview = true;
				this.loading = true;
				this.imgUrl = window.URL.createObjectURL(file);
				// 上传
				this.$API({
					method: 'POST',
					url: this.uploadUrl || this.$URL.getUrl('uploadImg'),
					data: formData
				}).then(res => {
					if (parseInt(res.status, 10) === 200) {
						this.uploadedImgUrl = res.data.url;
						this.response = res;
						this.$message.success('上传图片成功！');
					} else {
						this.imgUrl = this.uploadedImgUrl = '';
						this.$message.error('上传图片失败！');
					}
					this.isPreview = this.loading = false;
					formData = null;
				}).catch(() => {
					this.isPreview = this.loading = false;
					this.imgUrl = this.uploadedImgUrl = '';
					this.$message.error('上传图片失败！');
					formData = null;
				});
			},
			// 选择文件变化
			inputChange(event) {
				const files = event.target.files;
				let size = 0;
				let file = null;
				if (files && files.length > 0) {
					file = files[0];
					// 检查文件类型
					if (!this.imgSetting.acceptText.match(file.type)) {
						this.$message.error(`只能上传${this.imgSetting.allowTypesText}图片哦`);
						return;
					}
					// 检查文件大小
					if (this.imgSetting.maxSize < file.size) {
						size = Math.ceil(this.imgSetting.maxSize / (1024 * 1024));
						this.$message.error(`图片尺寸不能超过${size}M哦`);
						return;
					}
					this.imgInfo.fileType = file.type;
					this.imgInfo.fileSize = file.size;
					this.imgInfo.fileName = file.name;
					this.uploadFile(file);
					return;
				}
			},
			// 文件输入框点击，清空
			inputClick(event) {
				event.target.value = '';
			},
			// 图片加载完成
			imageLoaded(event) {
				const target = event.target;
				// 回收预览的图片占用的内存
				if (this.isPreview) {
					window.URL.revokeObjectURL(target.src);
				}
				// 更新图片宽高
				this.imgSetting.size.width = target.width;
				this.imgSetting.size.height = target.height;
			},
			// 删除图片
			deleteImg() {
				this.imgUrl = this.uploadedImgUrl = '';
			}
		},
		created() {
			// 图片类型映射
			const types = {
				'jpg': 'image/jpeg',
				'gif': 'image/gif',
				'png': 'image/png'
			};
			let imageTypes = [];
			// 处理传入的参数
			// 图片尺寸
			this.imgSetting.size.width = parseInt(this.imageWidth, 10) || 0;
			this.imgSetting.size.height = parseInt(this.imageHeight, 10) || 0;
			this.imgSetting.checkSize = (this.imageWidth && this.imageHeight);
			this.imgSetting.sizeText = this.imgSetting.checkSize
										? `${this.imgSetting.size.width} X ${this.imgSetting.size.height}`
										: '';
			// 图片大小
			this.imgSetting.maxSize = parseInt(this.imageSize, 10) || (2 * 1024 * 1024);
			// 图片类型
			if (this.imageTypes && this.imageTypes.length > 0) {
				// 传入数组
				if (Array.isArray(this.imageTypes)) {
					imageTypes = this.imageTypes;
				// 传入字符串
				} else {
					imageTypes = this.imageTypes.split(',');
				}
				// 生成用来匹配的文件类型字符串(mine-type)
				this.imgSetting.acceptText = imageTypes.map(function(val) {
					return types[val];
				}).join(',');
				// 生成用户选错文件时的提示文字(文件名后缀)
				this.imgSetting.allowTypesText = imageTypes.join('、');
			}
			// 图片url
			this.imgUrl = this.uploadedImgUrl = (this.imageUrl || '');
			// 显示文字
			this.text = (this.infoText === undefined) ? '上传图片' : this.infoText;
		},
		watch: {
			// 图片url改变时，广播事件
			'uploadedImgUrl': function(newVal, oldVal) {
				let data = null;
				let info = null;
				if (oldVal !== null) {
					info = {
						url: newVal,
						size: this.imgInfo.fileSize,
						type: this.imgInfo.fileType,
						name: this.imgInfo.fileName,
						width: this.imgSetting.size.width,
						height: this.imgSetting.size.height,
						response: this.response
					};
					data = {
						identity: this.imageIdentity,
						newVal: newVal ? info : '',
						oldVal: oldVal
					};
					this.$emit(this.changeEventName || 'upload-image-change', data);
				}
			}
		}
	};

</script>

<style lang="scss">

	$height: 100px;
	$width: 100px;

	@mixin absoluteBlock {
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
	}

	@mixin bgBlack {
		background-color: rgba(0, 0, 0, 0.6);
	}

	.u-uploadImg {
		display: inline-block;
		width: $width;
		background-color: white;
		color: #7f7f7f;
		font-size: 12px;

		.u-uploadingImg-con {
			position: relative;
			box-sizing: content-box;
			width: $width - 2;
			height: $height - 2;
			border: 1px solid #f2f2f2;
		}

		.u-uploadingImg-mask {
			@include absoluteBlock;
			@include bgBlack;
			line-height: $height;
			color: white;
			font-size: 20px;
			text-align: center;
			z-index: 3;
		}

		.u-uploadingImg-blank {
			@include absoluteBlock;
			display: flex;
			flex-direction: column;
			justify-content: center;
			background-color: #f2f2f2;
			text-align: center;
			z-index: 2;
			cursor: pointer;

			.el-icon-plus {
				display: block;
				font-size: 20px;
				line-height: 34px;
			}
		}

		.u-uploadingImg-img {
			@include absoluteBlock;
			display: flex;
			justify-content: center;
			z-index: 1;

			img {
				height: 100%;
				width: auto;
				max-height: 100%;
				max-width: 100%;
				cursor: pointer;
			}

			&.column {
				flex-direction: column;
			}

			&.column img {
				width: 100%;
				height: auto;
			}

			.el-icon-delete2 {
				display: none;
				position: absolute;
				top: 0;
				right: 0;
				width: 20px;
				height: 20px;
				color: white;
				@include bgBlack;
				text-align: center;
				line-height: 20px;
				border-radius: 2px;
				cursor: pointer;
			}

			&:hover .el-icon-delete2 {
				display: block;
			}
		}

		.u-uploadingImg-text {
			line-height: 26px;
			text-align: center;
			font-family: 'Arial';
		}

		.u-uploadingImg-input {
			display: none;
		}
	}

</style>