<template>
	<div class="vip-template-box">
    <div class="g-hidden-box">
      <el-upload
        ref="signleUpload"
        name="userfile"
        :action="singleUploadUrl"
        :limit="5"
        :data="singleUploadData"
        :on-exceed="handleUploadExceed"
        :before-upload="handleUploadBefore"
        :on-change="handleUploadChange"
        :on-success="handleUploadSuccess"
        :on-error="handleUploadError"
        :on-progress="handleUploadProgress"
        accept="image/gif,image/jpeg,image/png"
        :multiple="false"
        :file-list="singleFileList"
        :auto-upload="true">
        <el-button slot="trigger" ref='signleUploadBtn' size="small" type="primary">选取文件</el-button>
      </el-upload>
    </div>
    <el-tooltip placement="right">
      <div slot="content" class="g-ads-tooltip">个性化广告图可实现给一个运营位配置多张图片，并通过个性化计算，把符合用户偏好的图片展示给用户看个性化广告图将从图片库中选择已经打了标签的广告图作为投放的图片，如需投放请先在图片库上传图片</div>
      <div class="info-icon" v-show="value.isOperation"><i class="el-icon-info"></i></div>
    </el-tooltip>
    <el-row>
      <el-col :span="16">
        <div>
          <el-button type="primary" class="batch-btn" size="mini" @click="openUploadMask" :disabled="openBatchPanel||value.isIndividual">批量上传</el-button><span class="upload-prompt">（图片格式为"jpg/png/gif"，单张不超过450K）</span>
        </div>
      </el-col>
      <el-col :span="8" class="individual-col">
        <el-checkbox v-model="value.isIndividual" v-show="value.isOperation">使用图片个性化</el-checkbox>
      </el-col>
    </el-row>
    <div :class="[openBatchPanel ? 'min-box' : '', 'template-box']" v-if="value.groups.length>0">
      <el-collapse v-model="value.activeIndexs">
        <el-collapse-item :name="group.id" v-for="(group, index) in value.groups" :key="index">
          <template slot="title">
            <div  class="item-header">{{group.name}}<span v-if='value.isIndividual' class="delete-all">[<el-button class="delete-btn" type="text" @click.stop='deleteIndividualAll(group)'>全部删除</el-button>]</span></div>
          </template>
          <ul class="item-body clearfix">
            <template v-if="value.isOperation&&value.isIndividual">
              <div class="left-body">
                <li class="icon-box">
                  <div class="icon-row" @click="openPicManager(group)">
                    <div>
                      <i class="el-icon-plus add-icon"></i>
                      <div class="icon-txt">从图片库中选择</div>
                    </div>
                  </div>
                  <div class="txt-row">
                    {{group.individualPics.length}} / {{individualMax}}
                  </div>
                </li>
              </div>
              <ul class="right-body">
                <li class="icon-box" v-for="(picture, index) in group.individualPics" :key="index">
                  <div class="icon-row">
                    <img v-if="picture.url" :src="picture.url" alt="" />
                    <div v-else>
                      <i class="el-icon-plus add-icon"></i>
                    </div>
                    <div class="mask">
                      <el-tooltip class="item" effect="dark" content="删除" placement="bottom">
                        <i class="el-icon-delete delete" @click="clickIndividualDelete(picture, group.individualPics)"></i>
                      </el-tooltip>
                    </div>
                    <el-tooltip class="item" effect="dark" :content="picture.isDefault?'取消默认':'设置默认'" placement="top">
                      <i :class="[picture.isDefault?'el-icon-star-on favorite-on':'el-icon-star-off favorite-off', 'favorite']"  @click="clickIndividualFavorite(picture, group.individualPics)"></i>
                    </el-tooltip>
                  </div>
                  <div class="txt-row" v-show="picture.size">
                    {{picture.size}}
                  </div>
                </li>
              </ul>
            </template>
            <li v-else class="icon-box" v-for="(picture, index) in group.pictures" :key="index">
              <div class="icon-row">
                <img v-if="picture.url" :src="picture.url" alt="" />
                <div v-else class="add-box" @click="openUploadSelect(picture)">
                  <div>
                    <i class="el-icon-plus add-icon"></i>
                    <div class="icon-txt" v-if="picture.placeholder">{{picture.placeholder}}</div>
                  </div>
                </div>
                <div class="mask" v-if='!picture.isUpload&&picture.url'>
                  <el-tooltip class="item" effect="dark" content="删除" placement="bottom">
                    <i class="el-icon-delete delete" @click="clickPicDelete(picture, group.pictures)"></i>
                  </el-tooltip>
                </div>
                <el-progress v-if="picture.isUpload" class="icon-progress-bar" :text-inside="true" :show-text="false" :stroke-width="6" :percentage="picture.percent" status="success"></el-progress>
              </div>
              <div class="txt-row" v-show="picture.size">
                {{picture.size}}
              </div>
            </li>
          </ul>
        </el-collapse-item>
      </el-collapse>
      <div class="mask-layer" v-show="openBatchPanel">
        <i class="el-icon-circle-close mask-close" @click="closeUploadMask"></i>
        <div class="upload-panel">
          <el-upload
            ref="batchUpload"
            name="userfile"
            :action="batchUploadUrl"
            :limit="5"
            :on-exceed="handleBatchUploadExceed"
            :before-upload="handleUploadBefore"
            :on-change="handleBatchUploadChange"
            :on-success="handleBatchUploadSuccess"
            :on-error="handleBatchUploadError"
            accept="image/gif,image/jpeg,image/png"
            :multiple="true"
            :file-list="batchFileList"
            :auto-upload="true">
            <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
            <span slot="tip" class="el-upload__tip upload-prompt">（图片格式为"jpg/png/gif"，单张不超过450K）</span>
          </el-upload>
          <div class="btn-row">
            <el-button type="primary" size="small" @click="confirmBatchUpload">确定批量填充</el-button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>

	import utils from '../../libs/utils';
  import uri from '../../libs/uri';

  var g_curUploadIcon = null;
  var g_individualProup = null;

	export default {
		props: {
			value: {
				type: Object,
				required: true
			}

		},

		data: function() {
			return {

        individualMax: 20,  /* 个性化最大多少张图片 */
        // activePicTemplates: [],

        openBatchPanel: false,

        readyUpload: false,
        singleUploadUrl: '',
        singleUploadData: { desc: '' },
        singleFileList: [
          // {
          //  name: 'food.jpeg',
          //  url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
          // }, {
          //  name: 'food2.jpeg',
          //  url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}
          ],

        batchUploadUrl: '',
        batchUploadData: { desc: '' },
        batchFileList: []

			};
		},

		computed: {

		},

		watch: {

			value(val) {
				if (val && (val != this.value)) {
					this.value = val;

          // var activePicTemplates = [];
          // val.groups.forEach(group => {
          //   activePicTemplates.push(group.id);
          // });
          // this.activePicTemplates = activePicTemplates;

          this.$refs.signleUpload.abort();  /* 当正在上传图片时，调用这个中断，success和error函数不会调用 */
          this.$refs.signleUpload.clearFiles();

          this.$refs.batchUpload.abort();
          this.$refs.batchUpload.clearFiles();
				}
			}
		},

		mounted() {
		},

		destroyed() {

		},

		created() {

		},

		methods: {

      hasSingleCouponUpload() {
        if (this.couponInfo && this.couponInfo.image.isUpload) {
          return true;
        }
        return false;
      },


      hasSinglePictureUpload() {
        if (this.value.groups) {
          for (var i = 0;  i < this.value.groups.length; i++) {
            var pictures = (this.value.groups[i]).pictures;
            for (var j = 0; j < pictures.length; j++) {
              var picture = pictures[j];
              if (picture.isUpload) {
                return true;
              }
            }
          }
        }
        return false;
      },


      openUploadSelect(picture) {

        if (!this.hasSinglePictureUpload()) {
          g_curUploadIcon = picture;
          var limitSizeRatio = this.getRatio();
          if (!limitSizeRatio) {
            limitSizeRatio = '0';
          }

          var sizeStr = '';
          var size = picture.size;
          if (size) {
            var sArr = size.split('*');
            sizeStr += '&width=' + sArr[0] + '&height=' + sArr[1];
          }
          this.singleUploadUrl = this.$URL.getUrl('getUploadUrl') + '&m=ups&is_https=0' + sizeStr + '&limit_size_ratio=' + limitSizeRatio + '&id=' + this.value.templateId;
          this.$refs.signleUploadBtn.$el.click();
        } else {
          this.$toast({
            title: '图片正在上传中，请耐心等待...',
            type: 'warning'
          });
        }
      },

      clickPicDelete(picture, pictures) {
        picture.url = '';
        picture.surl = '';
      },

      deleteIndividualAll(group) {
        group.individualPics = [];
      },

      clickIndividualDelete(picture, pictures) {
        for (var i = 0;  i < pictures.length; i++) {
          if (picture == pictures[i]) {
            pictures.splice(i, 1);
            break;
          }
        }
      },

      clickIndividualFavorite(picture, pictures) {
        if (picture.isDefault) {
          picture.isDefault = 0;
        } else {
          for (var i = 0;  i < pictures.length; i++) {
            if (pictures[i].isDefault) {  //删除其余的
              pictures[i].isDefault = 0;
            }
          }
          picture.isDefault = 1;
        }

      },

      openPicManager(group) {
        this.$picmanager(
          {
            maxNum: this.individualPics,
            onSelect: this.callbackPicmanager,
            onCancel: this.callbackPicmanager,
            list: group.individualPics,
            context: this
          });
        g_individualProup = group;
      },

      callbackPicmanager(pictures) {
        if (pictures && g_individualProup) {
          g_individualProup.individualPics = pictures;
        }
        g_individualProup = null;
      },

      // submitUpload() {
      //  this.$refs.upload.submit();
      // },

      handleUploadExceed(files, fileList) {
        /* 这个回调执行，on-change不会执行 */
        this.$toast({
          title: '一次只能选择1张图片.',
          type: 'warning'
        });
      },

      handleUploadChange(file, fileList) {
        /* 文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用 */
        // console.log('handleChange......', file, fileList);
        // console.log( ((this.$refs.signleUpload.$refs)['upload-inner']).$refs.input );
        // console.log( ((this.$refs.signleUpload.$refs)['upload-inner']).$refs.input.files.length);
        // console.log(this.$refs.signleUpload.uploadFiles.length);
        // console.log('-------------------------');
        if (g_curUploadIcon) {
          g_curUploadIcon.isUpload = true;
          g_curUploadIcon.percent = 1;
        }
      },


      handleUploadProgress(event, file, fileList) {
        // console.log(event.percent);
        // console.log('handleProgress......', event, file, fileList);
        // console.log(file);
        if (g_curUploadIcon) {
          g_curUploadIcon.percent = event.percent;
        }

      },

      handleUploadSuccess(response, file, fileList) {
        /* 每张图片上传成功都会调用一次 */
        // console.log('handleSuccess......', response, file, fileList);
        //respone
        /*{
          "status": 1,  //201:图片的尺寸不对
          "msg": "成功",
          "size": null,
          "url": "http:\/\/a.vpimg2.com\/upload\/flow\/2018\/01\/11\/116\/15156739563635.png",
          "surl": "http:\/\/a.vpimg2.com\/upload\/flow\/2018\/01\/11\/116\/15156739563635_560x638_50.png"
        }*/

        // response.url = 'http://b.appsimg.com/upload/dsdmin/2017/12/21/49/15138420286448.jpg';
        // response.surl = 'http://b.appsimg.com/upload/dsdmin/2017/12/21/49/15138420286448.jpg';

        if (response && response.status == 1 && response.url && response.surl) {
          g_curUploadIcon.url = response.url;
          g_curUploadIcon.surl = response.surl;
          this.$toast({
            title: '图片上传成功.',
            type: 'success'
          });
        } else if (response && response.status == 201 && response.url && response.surl && this.getRatio()) {
          g_curUploadIcon.url = response.url;
          g_curUploadIcon.surl = response.surl;
          this.$toast({
            title: response.msg ? response.msg : '图片上传成功.',
            type: 'warning'
          });
        } else {
          var msg = '图片上传失败.'
          if (response && response.msg) {
            msg = response.msg;
          }
          this.$toast({
            title: msg,
            type: 'warning'
          });
        }

        if (g_curUploadIcon) {
          g_curUploadIcon.isUpload = false;
          g_curUploadIcon = null;
        }

        this.$refs.signleUpload.clearFiles();

      },

      handleUploadError(err, file, fileList) {
        /* 每张图片上传错误都会调用一次 */
        // console.log('handleError......', err, file, fileList);
        // console.log(file);

        this.$toast({
          title: '图片上传失败.',
          type: 'warning'
        });

        if (g_curUploadIcon) {
          g_curUploadIcon.isUpload = false;
          g_curUploadIcon = null;
        }

        this.$refs.signleUpload.clearFiles();
      },



      /* 检查图片的合法性，也和mask upload共用 */
      handleUploadBefore(file) {
        /* 这个回调执行，on-change也会执行 */
        var typeExt = file.type && file.type.split('/')[1];
        var isRightType = true;
        var rightExts = ['jpeg', 'jpg', 'gif', 'png'];
        if (!rightExts.includes(typeExt)) {
          isRightType = false;
        }
        if (!isRightType) {
          this.$toast({
            title: '上传图片只能是JPG/GIF/PNG格式!.',
            type: 'warning'
          });

          if (g_curUploadIcon) {
            g_curUploadIcon.isUpload = false;
            g_curUploadIcon = null;
          }
          this.$refs.signleUpload.clearFiles();

          return false;
        }

        const maxSize = 450;
        var isRightSize = file.size / 1024  <= maxSize;
        if (!isRightSize) {
          this.$toast({
            title: '上传图片大小不能超过' + maxSize + 'K!',
            type: 'warning'
          });

          if (g_curUploadIcon) {
            g_curUploadIcon.isUpload = false;
            g_curUploadIcon = null;
          }
          this.$refs.signleUpload.clearFiles();

          return false;
        }

        return true;

      },

      /* 打开批量上传面罩 */
      openUploadMask() {
        this.openBatchPanel = true;
        this.$refs.batchUpload.abort();
        this.$refs.batchUpload.clearFiles();
        var limitSizeRatio = this.getRatio();
        if (!limitSizeRatio) {
          limitSizeRatio = '0';
        }
        this.batchUploadUrl = this.$URL.getUrl('getUploadUrl') + '&m=ups&is_https=0&limit_size_ratio=' + limitSizeRatio + '&id=' + this.value.templateId;
      },

      /* 关闭批量上传面罩 */
      closeUploadMask() {
        this.openBatchPanel = false;
        this.$refs.batchUpload.abort();
        this.$refs.batchUpload.clearFiles();
      },

      /* 批量上传后的确认 */
      confirmBatchUpload() {

        var images = [];
        var files = this.getUploadVueFiles();
        files.forEach(function(item) {
          if (item.response && item.response.url && item.response.surl) {
            var image = {};
            image.size = item.response.size;
            image.url = item.response.url;
            image.surl = item.response.surl;
            images.push(image);
          }
        });
        this.closeUploadMask();
        this.fillBatchImages(images);
      },

      /* 填充上传图片 */
      fillBatchImages(images) {
        // console.log(images)
        if (images.length > 0) {
          if (this.value.isOperation&&this.value.isIndividual) {  /* 个性化 */
            //暂时不做这个功能，因为现在后台不支持
            return;
            /* 在前面添加就可以了 */
            // this.value.groups.forEach(group => {
            //   var individualPics = group.individualPics;
            //   var addImgs = [];

            //   var min = Math.min(this.individualMax - group.individualPics.length, images.length);
            //   if (min > 0) {
            //     var addImgs = images.slice(0, min);
            //     group.individualPics.unshift(...addImgs);
            //   }

            // });
          } else {
            /* 替换 */
            this.value.groups.forEach(group => {
              var pictures = group.pictures;
              pictures.forEach(picture => {
                var image = this.findRightImage(picture.size, images);
                if (image) {
                  picture.url = image.url;
                  picture.surl = image.surl;
                }
              });
            });
          }
        }
      },

      findRightImage(size, images) {
        if (size) {
          for (var i = 0; i < images.length; i++) {
            var image = images[i];
            if (size == image.size) {
              return image;
            }
          }
        } else {
          return images[0];
        }
        return null;
      },

      handleBatchUploadExceed(files, fileList) {
        /* 这个回调执行，on-change不会执行 */
        this.$toast({
          title: '一次只能选择5张图片.',
          type: 'warning'
        });
        // console.log('handleExceed......', files, fileList);
      },

      handleBatchUploadChange(file, fileList) {
        /* 文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用 */
        // console.log('handleChange......', file, fileList);
        // console.log( ((this.$refs.upload.$refs)['upload-inner']).$refs.input );
        // console.log( ((this.$refs.upload.$refs)['upload-inner']).$refs.input.files.length);
        // console.log(this.$refs.upload.uploadFiles.length);
        // console.log('-------------------------');
      },

      handleBatchUploadSuccess(response, file, fileList) {
        /* 每张图片上传成功都会调用一次 */
        // console.log('handleSuccess......', response, file, fileList);
        // respone
        /*{
            "status": 1,  //201:图片的尺寸不对
            "msg": "成功",
            "size": null,
            "url": "http:\/\/a.vpimg2.com\/upload\/flow\/2018\/01\/11\/116\/15156739563635.png",
            "surl": "http:\/\/a.vpimg2.com\/upload\/flow\/2018\/01\/11\/116\/15156739563635_560x638_50.png"
          }*/
        //

        // response.url = 'http://b.appsimg.com/upload/dsdmin/2017/12/21/49/15138420286448.jpg';
        // response.surl = 'http://b.appsimg.com/upload/dsdmin/2017/12/21/49/15138420286448.jpg';

        // console.log(file);
        if (response && response.url && response.surl) {

        } else {

          // var tmpFiles = this.getUploadVueFiles();
          var tmpFiles = fileList;
          for (var i = 0; i < tmpFiles.length; i++) {
            var tmpFile = tmpFiles[i];
            if (tmpFile.uid == file.uid) {
              tmpFiles.splice(i, 1);
            }
          }

          var msg = '图片上传失败.'
          if (response && response.msg) {
            msg = response.msg;
          }
          this.$toast({
            title: msg,
            type: 'warning'
          });
        }
      },

      handleBatchUploadError(err, file, fileList) {
        /* 每张图片上传错误都会调用一次 */
        // console.log('handleError......', err, file, fileList);
        // console.log(file);
        this.$toast({
          title: '图片上传失败.',
          type: 'warning'
        });

      },

      /* 取出批量上传的信息。注：因为el-upload还没有对外取文件的接口，所以才这样取，不过此种方法不可取 */
      getUploadVueFiles() {
        var vueFiles = (this.$refs.batchUpload.$children)[1];
        return vueFiles.files;
      },

      getRatio() {
        var limitSizeRatio = uri.query('limitsizeratio', true);
        var radioReg = /^\d+(\.\d{1,2})?$/;
        if (limitSizeRatio && radioReg.test(limitSizeRatio)) {
          return limitSizeRatio;
        } else {
          return '';
        }
      },

			syncInput() {
				this.$emit('input', this.value);
			}

		}
	};
</script>

<style lang="scss">

  @import "../../static/styles/_mixin_base.scss";

	.vip-template-box {
    position: relative;

    .template-box {
      position: relative;
      margin-top: 10px;
      border-left: 1px solid #ebeef5;
      border-right: 1px solid #ebeef5;
    }

    .template-box.min-box {
      min-height: 350px;
    }

    .el-collapse-item__header {
      line-height: 32px;
      height: 32px;
      &:hover {
        border-bottom-color : #edeff5;
        -webkit-transition: border-bottom-color 0s;
          transition: border-bottom-color 0s;
      };
    }

    .el-collapse-item__arrow {
      line-height: 32px;
      height: 32px;
    }

    .el-collapse-item__content {
      padding-bottom: 15px;
    }

    .icon-progress-bar {
      position: absolute;
      top: 50%;
      left: 5%;
      width: 90%;
      margin-top: -3px;
    }

    .batch-btn {
      min-width: 100px;
    }

    .upload-prompt{
      color: rgb(192,192,192);
      margin-left: 10px;
    }

    .individual-col {
      margin-top: 4px;
      text-align: right;
    }

    .mask-layer {
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      right: 0;

      background-color: rgba(0, 0, 0, 0.3);
    }

    .upload-panel {
      margin: 100px auto 0 auto;
      padding: 30px 30px;
      width: 400px;
      background-color: #fff;
      border-radius: 4px;
      text-align: left;

      .btn-row {
        text-align: center;
        margin-top: 20px;
      }
    }

    .mask-close {
      position: absolute;
      right: 10px;
      top: 10px;
      font-size: 30px;
      cursor: pointer;
      color: #ebeef5;

      &:hover {
        color: #cdd3e2;
      };
    }


    .item-header {
      position: relative;
      background: #f9fafc;
      padding-left: 15px;

      &:hover {
        background: #edeff5;
      }

      .delete-all {
        line-height: 22px;
        position: absolute;
        top: 6px;
        right: 30px;
      }

      .delete-btn {
        padding: 0;
        margin: 0;
        line-height: 22px;
        font-size: 12px;
      }
    }

    .item-body {
      margin: 0;
      padding: 0px 0px 0 15px;
      list-style: none;
      border-top: 1px solid #ebeef5;
    }

    .left-body {
      float: left;
      width: 135px;
    }

    .right-body {
      float: left;
      width: 549px;
      margin: 0 -10px 0 0;
      padding: 0;
      list-style: none;

    }


    .icon-box {
      float: left;
      width: 120px;
      margin-top: 15px;
      margin-right: 15px;
      position: relative;
    }

    .icon-row {
      position: relative;
      border: 1px dashed #e6e6e6;
      height: 60px;

      text-align: center;

      @include flex-center;

        &:hover {
          background-color: #f5f5f5;
        };

        img {
          max-width: 100%;
          max-height: 100%;
          display: block;
        }

        *{
          cursor: pointer;
        }

      &:hover .mask {
        display: block;
      };

      &:hover .favorite-off {
        display: block;
      };

      .add-box {
        width: 100%;
        height: 100%;
        @include flex-center;
        cursor: pointer;
      }
    }

    .mask {

      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      right: 0;
      background-color: rgba(0,0,0, 0.5);

      font-size: 20px;
      display: none;
    }

    .delete {
      position: absolute;
      right: 5px;
      bottom: 5px;
      color: #F56C6C;
    }

    .delete:hover {
      color: #fa1807;
    }

    .favorite {
      position: absolute;
      right: 5px;
      top: 5px;
      font-size: 21px;
      color: #F56C6C;
      outline: none;
    }

    .favorite:hover {
      color: #fa1807;
    }

    .favorite-off {
      display: none;
    }

    .favorite-on {
      color: #F56C6C;
    }

    .add-icon {
      font-size: 22px;
      line-height: 24px;
      color: #838383;
    }

    .icon-txt {
      color: #a7a7a7;
      cursor: pointer;
      white-space: nowrap;
      width: 100%;
      font-size: 12px;
      line-height: 15px;
    }

    .txt-row {
      margin-top: 2px;
      color: #a7a7a7;
      text-align: center;
      font-size: 13px;
      line-height: 20px;
    }

	}
</style>