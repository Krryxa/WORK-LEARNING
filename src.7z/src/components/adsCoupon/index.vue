<template>
	<div class="vip-coupon-box">
    <div class="g-hidden-box">
      <el-upload
        ref="couponUpload"
        name="userfile"
        :action="singleUploadUrl"
        :limit="5"
        :data="singleUploadData"
        :on-exceed="handleUploadExceed"
        :before-upload="handleUploadBefore"
        :on-change="handleUploadChange"
        :on-success="handleUploadSuccess"
        :on-error="handleUploadError"
        :on-progress="handleUploadProgress"
        accept="image/gif,image/jpeg,image/png"
        :multiple="false"
        :file-list="singleFileList"
        :auto-upload="true">
        <el-button slot="trigger" ref='couponUploadBtn' size="small" type="primary">选取文件</el-button>
      </el-upload>
    </div>
    <div class="img-row clearfix">
      <label class="label-col"><span class="star">*</span> 红包弹窗图：</label>
      <div class="icon-col">
        <div class="icon-row" @click="openUploadSelect()">
          <img v-if="value.image.url" :src="value.image.url" alt="" />
          <div v-else>
            <i class="el-icon-plus add-icon"></i>
            <div class="icon-txt" v-if="value.image.placeholder">{{value.image.placeholder}}</div>
          </div>
          <el-progress v-if="value.image.isUpload" class="icon-progress-bar progress2" :text-inside="true" :show-text="false" :stroke-width="6" :percentage="value.image.percent" status="success"></el-progress>
        </div>
        <div class="size-row">{{value.image.size}}</div>
      </div>
      <div class="txt-col">
        <div class="input-bar" v-for="(button, index) in value.buttons" :key="index">
          <div class="txt-label"><span class="star" v-if="button.required">*</span> {{button.msg}}：</div>
          <el-input v-model="button.text" :placeholder="button.placeholder" size="small"></el-input>
        </div>
        <!-- <div class="input-bar">
          <div class="txt-label"><span class="star">*</span> 跳转按钮文案：</div>
          <el-input v-model="adsTooltips" placeholder="" size="small"></el-input>
        </div>
        <div class="input-bar">
          <div class="txt-label"><span class="star">*</span> 已领券按钮文案：</div>
          <el-input v-model="adsTooltips" placeholder="" size="small"></el-input>
        </div> -->
      </div>
      <el-tooltip placement="right">
        <div slot="content">
          <img class="g-block" alt="" :src="couponImgSrc">
        </div>
        <div class="tooltips"><i class="el-icon-info"></i></div>
      </el-tooltip>
    </div>
    <div class="coupon-row">
      <div class="add-bar" v-for="(inputs, index) in value.couponList" :key="index">
        <label class="label"><span class="star">*</span> 红包券：</label>
        <div class="input-zone clearfix">
          <div class="inner" v-for="(item, index2) in inputs" :key="index2">
            <div class="inner2">
              <el-input v-model="item.text" :placeholder="item.placeholder" size="small"></el-input>
            </div>
          </div>
          <!-- <div class="inner"><div class="inner2">
            <el-input v-model="adsTooltips" placeholder="规则id（选填）" size="small"></el-input>
          </div></div>
          <div class="inner"><div class="inner2">
            <el-input v-model="adsTooltips" placeholder="来源（选填）" size="small"></el-input>
          </div></div> -->
        </div>
        <el-tooltip placement="right" v-if="index==0">
          <div slot="content" class="g-ads-tooltip">新增</div>
          <div class="coupon-normal-icon" @click="addCoupon"><i class="el-icon-circle-plus"></i></div>
        </el-tooltip>
        <el-tooltip placement="right" v-else>
          <div slot="content" class="g-ads-tooltip">删除</div>
          <div class="coupon-normal-icon" @click="deleteCoupon(index)"><i class="el-icon-remove"></i></div>
        </el-tooltip>
      </div>
    </div>
    <div class="after-row">
      <label class="label">领券后：</label>
      <template>
        <el-radio-group v-model="value.other.isShow">
          <el-radio :label='1'>仍显示此广告</el-radio>
          <el-radio :label='0'>不显示此广告</el-radio>
        </el-radio-group>
      </template>
    </div>
  </div>
</template>
<script>

	import utils from '../../libs/utils';

	export default {
		props: {
			value: {
				type: Object,
				required: true
			}

		},

		data: function() {
			return {

        couponImgSrc: '',

        readyUpload: false,
        singleUploadUrl: '',
        singleUploadData: { desc: '' },
        singleFileList: [
          // {
          //  name: 'food.jpeg',
          //  url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
          // }, {
          //  name: 'food2.jpeg',
          //  url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}
          ],
			};
		},

		computed: {

		},

		watch: {

			value(val) {
				if (val && (val != this.value)) {
					this.value = val;
				}
			}
		},

		mounted() {
      this.couponImgSrc = this.$URL.getImgUrl() + 'coupon-ui.png';
		},

		destroyed() {
      // console.log('destroyed....');
      if (this.value.image.isUpload) {
        this.$refs.couponUpload.abort();  /* 当正在上传图片时，调用这个中断，success和error函数不会调用 */
        this.$refs.couponUpload.clearFiles();
      }
		},

		created() {

		},

		methods: {

      openUploadSelect(picture) {

        if (!this.value.image.isUpload) {
          this.readyUpload = true;
          this.singleUploadUrl = this.$URL.getUrl('getUploadUrl') + '&m=upCouponImg&size=' + this.value.image.size;
          this.$refs.couponUploadBtn.$el.click();
        } else {
          this.$toast({
            title: '图片正在上传中，请耐心等待...',
            type: 'warning'
          });
        }
      },

      handleUploadExceed(files, fileList) {
        /* 这个回调执行，on-change不会执行 */
        this.$toast({
          title: '一次只能选择1张图片.',
          type: 'warning'
        });
      },

      handleUploadChange(file, fileList) {
        /* 文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用 */
        // console.log('handleChange......', file, fileList);
        // console.log( ((this.$refs.couponUpload.$refs)['upload-inner']).$refs.input );
        // console.log( ((this.$refs.couponUpload.$refs)['upload-inner']).$refs.input.files.length);
        // console.log(this.$refs.couponUpload.uploadFiles.length);
        // console.log('-------------------------');
        if (this.readyUpload) {
          this.value.image.isUpload = true;
          this.value.image.percent = 1;
        }

      },


      handleUploadProgress(event, file, fileList) {
        // console.log(event.percent);
        // console.log('handleProgress......', event, file, fileList);
        // console.log(file);
        this.value.image.percent = event.percent;

      },

      handleUploadSuccess(response, file, fileList) {
        /* 每张图片上传成功都会调用一次 */
        // console.log('handleSuccess......', response, file, fileList);
        //respone
        /*{
          "status": 1,  //201:图片的尺寸不对
          "msg": "成功",
          "size": null,
          "url": "http:\/\/a.vpimg2.com\/upload\/flow\/2018\/01\/11\/116\/15156739563635.png",
          "surl": "http:\/\/a.vpimg2.com\/upload\/flow\/2018\/01\/11\/116\/15156739563635_560x638_50.png"
        }*/

        // response.url = 'http://b.appsimg.com/upload/dsdmin/2017/12/21/49/15138420286448.jpg';
        // response.surl = 'http://b.appsimg.com/upload/dsdmin/2017/12/21/49/15138420286448.jpg';

        if (response && response.status == 1 && response.url && response.surl) {
          this.value.image.url = response.url;
          this.value.image.surl = response.surl;
          this.$toast({
            title: '图片上传成功.',
            type: 'success'
          });
        } else {
          var msg = '图片上传失败.'
          if (response && response.msg) {
            msg = response.msg;
          }
          this.$toast({
            title: msg,
            type: 'warning'
          });
        }

        this.value.image.isUpload = false;
        this.readyUpload = false;

        this.$refs.couponUpload.clearFiles();

      },

      handleUploadError(err, file, fileList) {
        /* 每张图片上传错误都会调用一次 */
        // console.log('handleError......', err, file, fileList);
        // console.log(file);

        this.$toast({
          title: '图片上传失败.',
          type: 'warning'
        });

        this.value.image.isUpload = false;
        this.readyUpload = false;

        this.$refs.couponUpload.clearFiles();
      },



      /* 检查图片的合法性，也和mask upload共用 */
      handleUploadBefore(file) {
        /* 这个回调执行，on-change也会执行 */
        var typeExt = file.type && file.type.split('/')[1];
        var isRightType = true;
        var rightExts = ['jpeg', 'jpg', 'gif', 'png'];
        if (!rightExts.includes(typeExt)) {
          isRightType = false;
        }
        if (!isRightType) {
          this.$toast({
            title: '上传图片只能是JPG/GIF/PNG格式!.',
            type: 'warning'
          });

          this.value.image.isUpload = false;
          this.readyUpload = false;
          this.$refs.couponUpload.clearFiles();

          return false;
        }

        const maxSize = 450;
        var isRightSize = file.size / 1024  <= maxSize;
        if (!isRightSize) {
          this.$toast({
            title: '上传图片大小不能超过' + maxSize + 'K!',
            type: 'warning'
          });

          this.value.image.isUpload = false;
          this.readyUpload = false;
          this.$refs.couponUpload.clearFiles();

          return false;
        }

        return true;

      },

      addCoupon() {
        // console.log(12)
        var maxNum = 20;
        if (this.value.couponList.length > maxNum) {
          this.$toast({
            title: '冷静，最多' + (maxNum + 1) + '条跳转地址.',
            type: 'warning'
          });
          return;
        }

        var inputs = utils.deepCopy(this.value.couponList[0]);
        inputs.forEach(item => {
          item.text = '';
        });
        this.value.couponList.splice(1, 0, inputs);
      },

      deleteCoupon(index) {
        this.value.couponList.splice(index, 1);
      },

			syncInput() {
				this.$emit('input', this.value);
			}

		}
	};
</script>

<style lang="scss">

  @import "../../static/styles/_mixin_base.scss";

	.vip-coupon-box {
    margin: 0;
    padding: 10px 15px;
    border-radius: 4px;
    background-color: #f9fafc;
    border: 1px solid #ebeef5;

    .icon-progress-bar {
      position: absolute;
      top: 50%;
      left: 5%;
      width: 90%;
      margin-top: -3px;
    }

    .progress2 {
      margin-top: 12px;
    }

    .img-row {
      position: relative;

      .label-col {
        float: left;
        display: inline-block;
        margin: 0;
        padding: 0;
        width: 100px;
        text-align: right;
        line-height: 40px;
      }

      .icon-col {
        float: left;
        display: inline-block;
        margin: 0 25px;
        width: 80px;
      }

      .txt-col {
        float: left;
        display: inline-block;
        margin-right: -10px;
        padding: 0;
        width: 400px;
      }

      .input-bar {
        position: relative;
        margin-top: 6px;
        padding-left: 125px;
      }

      .input-bar:first-child {
        margin-top: 0;
      }

      .txt-label {
        position: absolute;
        left: 0;
        top: 0;
        line-height: 32px;
        text-align: right;
        white-space: nowrap;
        width: 120px;
      }

      .tooltips {
        position: absolute;
        right: 8px;
        top: 5px;
        color: #8492a6;
        font-size: 20px;
      }

      .icon-row {
        border: 1px dashed #e6e6e6;
        height: 104px;
        font-size: 20px;
        cursor: pointer;
        text-align: center;
        position: relative;
        @include flex-center;

        &:hover {
          background-color: #f5f5f5;
        };

        img {
          max-width: 100%;
          max-height: 100%;
          display: block;
          margin: auto;
        }
      }

      .size-row {
        margin-top: 3px;
        line-height: 20px;
        color: #97989a;
        text-align: center;
        font-size: 13px;
      }

      .icon-txt {
        color: #a7a7a7;
        cursor: pointer;
        white-space: nowrap;
        width: 100%;
        font-size: 12px;
        line-height: 15px;
      }
    }

    $labelWidth: 80px;
    .coupon-row {
      position: relative;
      margin: 10px 0 0 0;
      padding: 6px 0;
      border-top: 1px solid #ebeef5;
    }

    .add-bar {
      position: relative;
      padding: 6px 30px 6px $labelWidth + 5;

      .coupon-normal-icon {
        position: absolute;
        right: 10px;
        top: 12px;
        cursor: pointer;
          color: #8492a6;
        font-size: 20px;

        &:hover {
          color: #1d8ce0;
        }
      }

      .label {
        line-height: 32px;
      }

      .inner {
        float: left;
        display: inline-block;
        width: 33.333333%;
      }

      .inner:last-child {
        margin-right: -3px;
      }

      .inner2 {
        margin-right: 5px;
      }
    }

    .after-row {
      position: relative;
      margin: 0;
      padding: 12px 30px 12px $labelWidth + 5;
      border-top: 1px solid #ebeef5;

      .label {
        line-height: 19px;
        top: 12px;
      }
    }

    .label {
      position: absolute;
      left: 0;
      top: 6px;
      text-align: right;
      width: $labelWidth;
      line-height: 20px;
    }

	}
</style>