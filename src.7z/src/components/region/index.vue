<template>
	<div class="vip-region-box">
		<div class="source-col">
			<div class="province-col">
				<div class="vip-header">
					<el-checkbox :indeterminate="isdtmProvince" v-model="checkProvinceAll">省份</el-checkbox>
					<span class="per-num">{{checkedProvinces.length}}/{{provinces.length}}</span>
				</div>
				<div class="vip-body">
					<div class="vip-search">
						<el-input
							placeholder="请输入内容"
							prefix-icon="el-icon-search"
							size="small"
							v-model="searchProvinceTxt" @input="changeProvinceSearch">
						</el-input>
					</div>
					<div class="list-box">
						<template v-if="hasShowProvince">
							<el-checkbox-group v-model="checkedProvinces">
								<el-checkbox v-if="province.isShow" :class="[{ 'is-focus': province.isFocus}, 'checkbox-bar']" v-for="province in provinces" :label="province" :key="province.id" @change="clickProvinceBar(province)">{{province.text}}</el-checkbox>
							</el-checkbox-group>
						</template>
						<div class="none-txt" v-else>无数据</div>
					</div>

				</div>
				<div class="vip-footer">
					<el-button type="text" :disabled="checkedProvinces.length > 0 ? false: true" size="small" round @click="addProvince">添加选中省份</el-button>
				</div>
			</div>
			<div class="city-col">
				<div class="vip-header">
					<el-checkbox :indeterminate="isdtmCity" v-model="checkCityAll">城市</el-checkbox>
					<span class="per-num">{{checkedCitys.length}}/{{citys.length}}</span>
				</div>
				<div class="vip-body">
					<div class="vip-search">
						<el-input
							placeholder="请输入内容"
							prefix-icon="el-icon-search"
							size="small"
							v-model="searchCityTxt" @input="changeCitySearch">
						</el-input>
					</div>
					<div class="list-box">
						<template v-if="hasShowCity">
							<el-checkbox-group v-model="checkedCitys">
								<el-checkbox v-if="city.isShow" :class="[{ 'is-focus': city.isFocus}, 'checkbox-bar']" v-for="city in citys" :label="city" :key="city.id" @change="clickCityBar(city)">{{city.text}}</el-checkbox>
							</el-checkbox-group>
						</template>
						<div class="none-txt" v-else>无数据</div>
					</div>

				</div>
				<div class="vip-footer">
					<el-button type="text" :disabled="checkedCitys.length > 0 ? false: true" size="small" round @click="addCity">添加选中城市</el-button>
				</div>
			</div>
			<div class="county-col">
				<div class="vip-header">
					<el-checkbox :indeterminate="isdtmCounty" v-model="checkCountyAll">区域</el-checkbox>
					<span class="per-num">{{checkedCountys.length}}/{{countys.length}}</span>
				</div>
				<div class="vip-body">
					<div class="vip-search">
						<el-input
							placeholder="请输入内容"
							prefix-icon="el-icon-search"
							size="small"
							v-model="searchCountyTxt" @input="changeCountySearch">
						</el-input>
					</div>
					<div class="list-box">
						<template v-if="hasShowCounty">
							<el-checkbox-group v-model="checkedCountys">
								<el-checkbox v-if="county.isShow" :class="[{ 'is-focus': county.isFocus}, 'checkbox-bar']" v-for="county in countys" :label="county" :key="county.id" @change="clickCountyBar(county)">{{county.text}}</el-checkbox>
							</el-checkbox-group>
						</template>
						<div class="none-txt" v-else>无数据</div>
					</div>

				</div>
				<div class="vip-footer">
					<el-button type="text" :disabled="checkedCountys.length > 0 ? false: true" size="small" round @click="addCounty">添加选中区域</el-button>
				</div>
			</div>

			<i class="el-icon-d-arrow-right arrow-right" size="small"></i>
		</div>
		<div class="target-col">
			<div class="vip-header">
				<el-checkbox :indeterminate="isdtmTarget" v-model="checkTargetAll">选中地区</el-checkbox>
				<span class="per-num">{{checkedTargets.length}}/{{targets.length}}</span>
			</div>
			<div class="vip-body">
				<div class="vip-search">
					<el-input
						placeholder="请输入内容"
						prefix-icon="el-icon-search"
						size="small"
						v-model="searchTargetTxt" @input="changeTargetSearch">
					</el-input>
				</div>
				<div class="list-box">
					<template v-if="targets.length > 0">
						<el-checkbox-group v-model="checkedTargets">
							<el-checkbox v-if="target.isShow" :class="[{ 'is-focus': target.isFocus}, 'checkbox-bar']" v-for="target in targets" :label="target" :key="target.id" @change="clickTargetBar(target)">{{target.text}}</el-checkbox>
						</el-checkbox-group>
					</template>
					<div class="none-txt" v-else>无数据</div>
				</div>

			</div>
			<div class="vip-footer">
				<el-button type="text" :disabled="checkedTargets.length > 0 ? false: true" size="small" round @click="removeTarget">删除选中地区</el-button>
			</div>
		</div>
	</div>
</template>
<script>

	import utils from '../../libs/utils';

	/* 按中文拼音比较 */
	function compare(text1, text2) {
		var result;
		if (text1.localeCompare) {
			result = text1.localeCompare(text2, 'zh');
		} else {
			if (text1 > text2) {
				result = 1;
			} else if (text1 == text2) {
				result = 0;
			} else {
				result = -1;
			}
		}
		return result;
	}

	/* 按中文拼音排序 */
	function sortRegion(a, b) {
		return compare(a.text, b.text);
	}

	function ellipsis(value) {
		if (value && value.length > 3) {
			return value.substr(0, 2) + '...';
		} else {
			return value;
		}
	}


	export default {
		props: {
			data: {
				type: Object,
				required: true
			},
			value: {
				type: Array,
				required: true
			}
		},

		data: function() {
			return {

				/*
				{
					isShow: 是否显示,
					id,
					text: 显示文字
					isFocus: 控制点击时的背景
				}
				*/
				provinces: [],
				searchProvinceTxt: '',
				checkedProvinces: [],

				/*
				{
					isShow: 是否显示,
					id,
					text: 显示文字
					isFocus: 控制点击时的背景
					provinceId:
					provinceName:
				}
				*/
				citys: [],
				checkedCitys: [],
				searchCityTxt: '',

				/*
				{
					isShow: 是否显示,
					id,
					text: 显示文字
					isFocus: 控制点击时的背景
					provinceId:
					provinceName:
					cityId:
					cityName:
				}
				*/
				countys: [],
				checkedCountys: [],
				searchCountyTxt: '',

				/*
				{
					level: 哪一个级别：1=>省级，2=>市级，3=>区域级
					provinceId: 1=>省级要用
					provinceName:
					cityId: 2=>市级要用
					cityName:
					countyId: 3=>区域级要用
					countyName:
					isShow: 是否显示,
					id,
					text: 显示文字
					isFocus: 控制点击时的背景
				}
				*/
				targets: [],
				checkedTargets: [],
				searchTargetTxt: '',

				selectedList: [],	//[104103,104104-104104112-104104112102,省ID-市ID-县ID]

			};
		},

		computed: {

			isdtmProvince() {
				var checkedCount = this.checkedProvinces.length;
				if (checkedCount > 0) {
					var showNum = 0;
					var selectedShowNum = 0;
					this.provinces.forEach((item) => {
						if (item.isShow) {
							showNum++;
						}
						if (item.isShow && this.checkedProvinces.includes(item)) {
							selectedShowNum++;
						}
					});
					return selectedShowNum > 0 && selectedShowNum < showNum;
				} else {
					return false;
				}
			},

			checkProvinceAll: {
				get() {
					// console.log('checkProvinceAll', this.checkedProvinces)
					var checkedCount = this.checkedProvinces.length;
					if (checkedCount > 0) {
						var showNum = 0;
						var selectedShowNum = 0;
						this.provinces.forEach((item) => {
							if (item.isShow) {
								showNum++;
							}
							if (item.isShow && this.checkedProvinces.includes(item)) {
								selectedShowNum++;
							}
						});
						return selectedShowNum > 0 && selectedShowNum == showNum;
					} else {
						return false;
					}
				},
				set(val) {
					if (val) {
						var tmpCheckedProvinces = [];
						this.provinces.forEach((item) => {
							if (item.isShow && !this.checkedProvinces.includes(item)) {
								tmpCheckedProvinces.push(item);
							}
						});
						if (tmpCheckedProvinces.length > 0) {
							tmpCheckedProvinces = tmpCheckedProvinces.concat(this.checkedProvinces);
							tmpCheckedProvinces.sort(sortRegion);
							this.checkedProvinces = tmpCheckedProvinces;
						}

					} else {
						this.checkedProvinces = [];
					}

				}
			},



			isdtmCity() {
				var checkedCount = this.checkedCitys.length;
				if (checkedCount > 0) {
					var showNum = 0;
					var selectedShowNum = 0;
					this.citys.forEach((item) => {
						if (item.isShow) {
							showNum++;
						}
						if (item.isShow && this.checkedCitys.includes(item)) {
							selectedShowNum++;
						}
					});
					return selectedShowNum > 0 && selectedShowNum < showNum;
				} else {
					return false;
				}
			},

			checkCityAll: {
				get() {
					// console.log(this.checkedCitys);
					var checkedCount = this.checkedCitys.length;
					if (checkedCount > 0) {
						var showNum = 0;
						var selectedShowNum = 0;
						this.citys.forEach((item) => {
							if (item.isShow) {
								showNum++;
							}
							if (item.isShow && this.checkedCitys.includes(item)) {
								selectedShowNum++;
							}
						});
						// console.log(selectedShowNum, showNum);
						return selectedShowNum > 0 && selectedShowNum == showNum;
					} else {
						return false;
					}
				},
				set(val) {
					// console.log(val, this.checkedCitys);
					if (val) {
						var tmpCheckedCitys = [];
						this.citys.forEach((item) => {
							if (item.isShow && !this.checkedCitys.includes(item)) {
								tmpCheckedCitys.push(item);
							}
						});
						if (tmpCheckedCitys.length > 0) {
							tmpCheckedCitys = tmpCheckedCitys.concat(this.checkedCitys);
							tmpCheckedCitys.sort(sortRegion);
							this.checkedCitys = tmpCheckedCitys;
						}

					} else {
						this.checkedCitys = [];
					}

				}
			},



			isdtmCounty() {
				var checkedCount = this.checkedCountys.length;
				if (checkedCount > 0) {
					var showNum = 0;
					var selectedShowNum = 0;
					this.countys.forEach((item) => {
						if (item.isShow) {
							showNum++;
						}
						if (item.isShow && this.checkedCountys.includes(item)) {
							selectedShowNum++;
						}
					});
					return selectedShowNum > 0 && selectedShowNum < showNum;
				} else {
					return false;
				}
			},

			checkCountyAll: {
				get() {
					var checkedCount = this.checkedCountys.length;
					if (checkedCount > 0) {
						var showNum = 0;
						var selectedShowNum = 0;
						this.countys.forEach((item) => {
							if (item.isShow) {
								showNum++;
							}
							if (item.isShow && this.checkedCountys.includes(item)) {
								selectedShowNum++;
							}
						});
						return selectedShowNum > 0 && selectedShowNum == showNum;
					} else {
						return false;
					}
				},
				set(val) {
					if (val) {
						var tmpCheckedCountys = [];
						this.countys.forEach((item) => {
							if (item.isShow && !this.checkedCountys.includes(item)) {
								tmpCheckedCountys.push(item);
							}
						});
						if (tmpCheckedCountys.length > 0) {
							tmpCheckedCountys = tmpCheckedCountys.concat(this.checkedCountys);
							tmpCheckedCountys.sort(sortRegion);
							this.checkedCountys = tmpCheckedCountys;
						}

					} else {
						this.checkedCountys = [];
					}

				}
			},




			isdtmTarget() {
				var checkedCount = this.checkedTargets.length;
				if (checkedCount > 0) {
					var showNum = 0;
					var selectedShowNum = 0;
					this.targets.forEach((item) => {
						if (item.isShow) {
							showNum++;
						}
						if (item.isShow && this.checkedTargets.includes(item)) {
							selectedShowNum++;
						}
					});
					return selectedShowNum > 0 && selectedShowNum < showNum;
				} else {
					return false;
				}
			},

			checkTargetAll: {
				get() {
					var checkedCount = this.checkedTargets.length;
					if (checkedCount > 0) {
						var showNum = 0;
						var selectedShowNum = 0;
						this.targets.forEach((item) => {
							if (item.isShow) {
								showNum++;
							}
							if (item.isShow && this.checkedTargets.includes(item)) {
								selectedShowNum++;
							}
						});
						return selectedShowNum > 0 && selectedShowNum == showNum;
					} else {
						return false;
					}
				},
				set(val) {
					if (val) {
						var tmpCheckedTargets = [];
						this.targets.forEach((item) => {
							if (item.isShow && !this.checkedTargets.includes(item)) {
								tmpCheckedTargets.push(item);
							}
						});
						if (tmpCheckedTargets.length > 0) {
							tmpCheckedTargets = tmpCheckedTargets.concat(this.checkedTargets);
							tmpCheckedTargets.sort(sortRegion);
							this.checkedTargets = tmpCheckedTargets;
						}

					} else {
						this.checkedTargets = [];
					}

				}
			},

			/* 是否有显示的省份 */
			hasShowProvince() {
				var provinces = this.provinces;
				for (var i = 0; i < provinces.length; i++) {
					if (provinces[i].isShow) {
						return true;
					}
				}
				return false;
			},

			/* 是否有显示的城市 */
			hasShowCity() {
				var citys = this.citys;
				for (var i = 0; i < citys.length; i++) {
					if (citys[i].isShow) {
						return true;
					}
				}
				return false;
			},

			/* 是否有显示的区域 */
			hasShowCounty() {
				var countys = this.countys;
				for (var i = 0; i < countys.length; i++) {
					if (countys[i].isShow) {
						return true;
					}
				}
				return false;
			}

		},

		watch: {

			value(val) {
				/*
				console.log('watch val:', val == this.selectedList, this.isEqualTarget(val))
				经实验证明：this.emit('input', this.selectedList)，会触发这个watch, 不过val==this.selectedList 为true,也就是说他们用的是同一个对像
				不过现在程序用了深拷贝
				*/
				// console.log('watch val:', val == this.selectedList, this.isEqualTarget(val));
				if (val && !this.isEqualTarget(val)) {		/* 从原来的target发出来的 */
					this.selectedList = utils.deepCopy(val);
					this.update();
				}
			},

			data(val) {
				// console.log('data ...', val == this.data);
				if (val && val.province && val.city && val.country) {
					// this.data = utils.deepCopy(val);
					this.update();
				}
			}
		},

		mounted() {
			// this.provinces = this.extractProvince();
			this.selectedList = this.value;
			this.update();
		},

		destroyed() {

		},

		created() {

		},

		methods: {

			isEqualTarget(list) {
				if (this.selectedList.length == list.length) {
					for (var i = 0; i < list.length; i++) {
						if (!this.selectedList.includes(list[i])) {
							return false;
						}
					}
					return true;
				} else {
					return false;
				}
			},

			update() {

				this.citys = [];
				this.checkedCitys = [];
				this.searchCityTxt = '';
				this.countys = [];
				this.checkedCountys = [];
				this.searchCountyTxt = '';

				this.checkedProvinces = [];
				// this.searchProvinceTxt = '';
				this.checkedTargets = [];
				this.targets = [];
				this.searchTargetTxt = '';
				var provinces = this.extractProvince();
				// console.log('provinces', provinces);
				var selectedList = utils.deepCopy(this.selectedList);
				// console.log('selectedList', selectedList);
				if (selectedList.length > 0) {
					selectedList = selectedList.sort();

					/* 删除重复的，比如省下面的市（做些兼容） */
					var prevItem = false;	/* 记录前一个 */
					for (var i = 0; i < selectedList.length; i++) {
						var curItem = selectedList[i];
						if (!prevItem || (curItem.indexOf('-') < 0)) {		/* 第一个或是省 */
							prevItem = curItem;
						} else {
							if (curItem.indexOf(prevItem + '-') == 0) {
								selectedList.splice(i, 1);
								i--;
								continue;
							} else {
								prevItem = curItem;
							}
						}
					}

					//添加到目标区域
					var targets = [];
					selectedList.forEach(item => {
						var info = this.parseRegion(item);
						// console.log('info', info);
						if (info) {
							targets.push(info);
							if (info.level == 1) {	/* 删除目标区域有的省份，因为市和县此时都设置为空就不用删了 */
								for (var i = 0; i < provinces.length; i++) {
									var province = provinces[i];
									if (province.id == info.provinceId) {
										provinces.splice(i, 1);
										break;
									}
								}
							}
						}
					});
					this.provinces = provinces;
					this.targets = targets.sort(sortRegion);
					this.syncInput();	/* 重新同步一个，可能顺序有改变 */
					// console.log('provinces', provinces);
					// console.log('this.targets', this.targets);
				} else {
					this.provinces = provinces;
					this.targets = [];
				}
			},

			parseRegion(selectedTxt) {	/* 形式如：省ID-市ID-县ID */
				var info = {};
				var ids = selectedTxt.split('-');
				if (ids.length == 1) {	/* 是省 */
					var provinces = this.data.province;
					var provinceId = ids[0];
					var provinceName = provinces[provinceId];
					if (provinceName) {
						var uiText = provinceName;
						return {
							level: 1,
							provinceId: provinceId,
							provinceName: provinceName,
							isFocus: false,
							isShow: (!this.searchTargetTxt) || utils.hasSearch(this.searchTargetTxt, uiText),
							id: 'province' + provinceId,
							text: uiText
						}
					} else {
						return false;
					}
				} else if (ids.length == 2) {	/* 是市 */
					var provinces = this.data.province;
					var provinceId = ids[0];
					var cityId = ids[1];
					var provinceName = provinces[provinceId];
					if (provinceName && cityId) {
						var citys = this.data.city[provinceId];
						if (!citys) {
							return false;
						}
						var cityName = false;
						for (var i = 0; i < citys.length; i++) {
							var city = citys[i];
							if (city.id == cityId) {
								cityName = city.text;
								break;
							}
						}
						if (cityName) {
							var uiText = ellipsis(provinceName) + '-' + cityName;
							return {
								level: 2,
								provinceId: provinceId,
								provinceName: provinceName,
								cityId: cityId,
								cityName: cityName,
								isFocus: false,
								isShow: (!this.searchTargetTxt) || utils.hasSearch(this.searchTargetTxt, uiText),
								id: 'city' + cityId,
								text: uiText
							}
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {	/* 是县 */
					var provinces = this.data.province;
					var provinceId = ids[0];
					var cityId = ids[1];
					var countyId = ids[2];
					var provinceName = provinces[provinceId];
					if (provinceName && cityId && countyId) {
						var citys = this.data.city[provinceId];
						if (!citys) {
							return false;
						}
						var cityName = false;
						for (var i = 0; i < citys.length; i++) {
							var city = citys[i];
							if (city.id == cityId) {
								cityName = city.text;
								break;
							}
						}
						if (cityName) {
							var countys = this.data.country[cityId];
							if (!countys) {
								return false;
							}

							var countyName = false;
							for (var i = 0; i < countys.length; i++) {
								var county = countys[i];
								if (county.id == countyId) {
									countyName = county.text;
									break;
								}
							}

							if (countyName) {
								var uiText = ellipsis(provinceName) + '-' + ellipsis(cityName) + '-' + countyName;
								return {
									level: 3,
									provinceId: provinceId,
									provinceName: provinceName,
									cityId: cityId,
									cityName: cityName,
									countyId: countyId,
									countyName: countyName,
									isFocus: false,
									isShow: (!this.searchTargetTxt) || utils.hasSearch(this.searchTargetTxt, uiText),
									id: 'county' + countyId,
									text: uiText
								}
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						return false;
					}
				}
			},

			/* 提取省份 */
			extractProvince() {
				var provinces = this.data.province;
				if (provinces) {
					var tmpProvinces = [];
					for (var key in provinces) {

						var provinceId = key;

						var isIn = false;
						for (var i = 0; i < this.targets.length; i++) {
							var curTarget = this.targets[i];
							if (curTarget.level == 1 && curTarget.provinceId == provinceId) {
								isIn = true;
								break;
							}
						}

						if (!isIn) {	/* 不在目标区域，那么源数据可以显示 */
							var province = {
								id: provinceId,
								text: provinces[key],
								isShow: (!this.searchProvinceTxt) || utils.hasSearch(this.searchProvinceTxt, provinces[key]),		/* 设置为显示/隐藏 */
								isFocus: false
							};
							tmpProvinces.push(province);
						}
					}
					return tmpProvinces.sort(sortRegion);
				} else {
					return [];
				}
			},

			/* 提取城市 */
			extractCity(province) {
				var sourceCityList = this.data.city;
				var sourceCitys = sourceCityList ? sourceCityList[province.id] : null;
				if (sourceCitys) {
					var tmpCitys = [];
					sourceCitys.forEach((item) => {

						var isIn = false;
						for (var i = 0; i < this.targets.length; i++) {
							var curTarget = this.targets[i];
							if (curTarget.level == 2 && curTarget.cityId == item.id) {
								isIn = true;
								break;
							}
						}

						if (!isIn) {	/* 不在目标区域，那么源数据可以显示 */
							var city = {
								id: item.id,
								text: item.text,
								isShow: (!this.searchCityTxt) || utils.hasSearch(this.searchCityTxt, item.text),		/* 设置为显示/隐藏 */
								isFocus: false,
								provinceId: province.id,
								provinceName: province.text
							};
							tmpCitys.push(city);
						}

					});
					return tmpCitys.sort(sortRegion);
				} else {
					return [];
				}
			},

			/* 提取区域/城镇 */
			extractCounty(city) {
				var sourceCountyList = this.data.country;
				var sourceCountys = sourceCountyList ? sourceCountyList[city.id] : null;
				if (sourceCountys) {
					var tmpCountys = [];
					sourceCountys.forEach((item) => {

						var isIn = false;
						for (var i = 0; i < this.targets.length; i++) {
							var curTarget = this.targets[i];
							if (curTarget.level == 3 && curTarget.countyId == item.id) {
								isIn = true;
								break;
							}
						}

						if (!isIn) {	/* 不在目标区域，那么源数据可以显示 */
							var county = {
								id: item.id,
								text: item.text,
								isShow: (!this.searchCountyTxt) || utils.hasSearch(this.searchCountyTxt, item.text),		/* 设置为显示/隐藏 */
								isFocus: false,
								provinceId:  city.provinceId,
								provinceName:  city.provinceName,
								cityId:  city.id,
								cityName:  city.text
							};
							tmpCountys.push(county);
						}

					});
					return tmpCountys.sort(sortRegion);
				} else {
					return [];
				}
			},

			clickProvinceBar(province) {
				if (!province.isFocus) {
					// this.focusProvinceId = province.id;

					this.provinces.forEach((item) => {
						item.isFocus = false;
					});
					province.isFocus = true;

					var citys = this.extractCity(province);
					if (citys && citys.length > 0) {

						this.citys = citys;

						//清空市级和镇级的数据
						this.checkedCitys = [];
						// this.searchCityTxt = '';

						this.checkedCountys = [];
						this.countys = [];
						// this.searchCountyTxt = '';
					} else {

						this.checkedCitys = [];
						this.citys = [];
						// this.searchCityTxt = '';

						this.checkedCountys = [];
						this.countys = [];
						// this.searchCountyTxt = '';

						console.log('这个省份(' + province.text + ')没有城市');
					}
				}
			},

			clickCityBar(city) {
				if (!city.isFocus) {
					// this.focusCityId = city.id;

					this.citys.forEach((item) => {
						item.isFocus = false;
					});
					city.isFocus = true;

					var countys = this.extractCounty(city);
					if (countys) {

						this.countys = countys;

						//清空镇级的数据
						this.checkedCountys = [];
						// this.searchCountyTxt = '';
					} else {
						//比如那四个直辖市
						this.checkedCountys = [];
						this.countys = [];
						// this.searchCountyTxt = '';
						console.log('这个城市(' + city.text + ')没有区域');
					}
				}
			},

			clickCountyBar(county) {
				// if (!county.isFocus) {
				// 	// this.focusCountyId = county.id;
				// 	this.countys.forEach((item) => {
				// 		item.isFocus = false;
				// 	});
				// 	county.isFocus = true;
				// }
			},

			clickTargetBar(target) {
				// if (!target.isFocus) {
				// 	this.targets.forEach((item) => {
				// 		item.isFocus = false;
				// 	});
				// 	target.isFocus = true;
				// }
			},


			changeProvinceSearch() {
				if (this.searchProvinceTxt) {
					// var newProvinces = [];
					this.provinces.forEach((item) => {
						if (utils.hasSearch(this.searchProvinceTxt, item.text)) {
							if (!item.isShow) {
								item.isShow = true;
							}
						} else if(item.isShow) {
							item.isShow = false;
						}
					});

				} else {
					this.provinces.forEach((item) => {
						if(!item.isShow) {
							item.isShow = true;
						}
					});
				}
			},

			changeCitySearch() {
				if (this.searchCityTxt) {
					this.citys.forEach((item) => {
						if (utils.hasSearch(this.searchCityTxt, item.text)) {
							if (!item.isShow) {
								item.isShow = true;
							}
						} else if(item.isShow) {
							item.isShow = false;
						}
					});
				} else {
					this.citys.forEach((item) => {
						if(!item.isShow) {
							item.isShow = true;
						}
					});
				}
			},

			changeCountySearch() {
				if (this.searchCountyTxt) {
					this.countys.forEach((item) => {
						if (utils.hasSearch(this.searchCountyTxt, item.text)) {
							if (!item.isShow) {
								item.isShow = true;
							}
						} else if(item.isShow) {
							item.isShow = false;
						}
					});
				} else {
					this.countys.forEach((item) => {
						if(!item.isShow) {
							item.isShow = true;
						}
					});
				}
			},


			changeTargetSearch() {
				if (this.searchTargetTxt) {
					this.targets.forEach((item) => {
						if (utils.hasSearch(this.searchTargetTxt, item.text)) {
							if (!item.isShow) {
								item.isShow = true;
							}
						} else if(item.isShow) {
							item.isShow = false;
						}
					});
				} else {
					this.targets.forEach((item) => {
						if(!item.isShow) {
							item.isShow = true;
						}
					});
				}
			},

			addProvince() {
				let checkedProvinces = this.checkedProvinces;
				if (checkedProvinces.length > 0) {
					let newProvinces = [];
					this.provinces.forEach((item) => {
						if (!this.checkedProvinces.includes(item)) {
							newProvinces.push(item);
						}
					});
					this.provinces = newProvinces;
					this.checkedProvinces = [];

					for (let i = 0; i < checkedProvinces.length; i++) {
						if (checkedProvinces[i].isFocus) {	/* 清空下一级 */
							//清空市级和镇级的数据
							this.checkedCitys = [];
							this.citys = [];
							// this.searchCityTxt = '';

							this.checkedCountys = [];
							this.countys = [];
							// this.searchCountyTxt = '';
							break;
						}
					}

					//添加到目标地区
					for (let m = 0; m < this.targets.length; m++) {

						let curTarget = this.targets[m];
						for (let n = 0; n < checkedProvinces.length; n++) {
							if (checkedProvinces[n].id == curTarget.provinceId) {

								this.targets.splice(m, 1);	/* 删除自己下一级的元素 */
								m--;

								for (let k = 0; k < this.checkedTargets.length; k++) {
									let curCheckedTarget = this.checkedTargets[k];
									if (curCheckedTarget == curTarget) {
										this.checkedTargets.splice(k, 1);	/* 上面不要了，删除这个选中 */
										break;
									}
								}
								break;
							}
						}

					}

					checkedProvinces.forEach((item) => {
						let uiText = item.text;
						let curItem = {
							level: 1,
							provinceId: item.id,
							provinceName: item.text,
							isFocus: false,
							isShow: (!this.searchTargetTxt) || utils.hasSearch(this.searchTargetTxt, uiText),
							id: 'province' + item.id,
							text: uiText
						}

						let hasInsert = false;
						for (let p = 0; p < this.targets.length; p++) {
							let curTarget2 = this.targets[p];
							if (compare(curTarget2.text, uiText) > 0) {
								this.targets.splice(p, 0, curItem);
								hasInsert = true;
								break;
							}

						}
						if (!hasInsert) {
							this.targets.push(curItem);
						}
					});

					//同步绑定
					// this.$emit('input', this.targets);
					this.syncInput();

				}
			},

			addCity() {
				let checkedCitys = this.checkedCitys;
				if (checkedCitys.length > 0) {
					let newCitys = [];
					this.citys.forEach((item) => {
						if (!this.checkedCitys.includes(item)) {
							newCitys.push(item);
						}
					});
					this.citys = newCitys;
					this.checkedCitys = [];


					for (let i = 0; i < checkedCitys.length; i++) {
						if (checkedCitys[i].isFocus) {	/* 清空下一级 */
							//清空镇级的数据
							this.checkedCountys = [];
							this.countys = [];
							break;
						}
					}

					//添加到目标地区
					for (let m = 0; m < this.targets.length; m++) {
						let curTarget = this.targets[m]
						for (let n = 0; n < checkedCitys.length; n++) {
							if (checkedCitys[n].id == curTarget.cityId) {

								this.targets.splice(m, 1);	/* 删除自己下一级的元素 */
								m--;

								for (let k = 0; k < this.checkedTargets.length; k++) {
									let curCheckedTarget = this.checkedTargets[k];
									if (curCheckedTarget == curTarget) {
										this.checkedTargets.splice(k, 1);	/* 上面不要了，删除这个选中 */
										break;
									}
								}
								break;
							}
						}
					}


					checkedCitys.forEach((item) => {
						let uiText = ellipsis(item.provinceName) + '-' + item.text;
						let curItem = {
							level: 2,
							provinceId: item.provinceId,
							provinceName: item.provinceName,
							cityId: item.id,
							cityName: item.text,
							isFocus: false,
							isShow: (!this.searchTargetTxt) || utils.hasSearch(this.searchTargetTxt, uiText),
							id: 'city' + item.id,
							text: uiText
						}

						let hasInsert = false;
						for (let p = 0; p < this.targets.length; p++) {
							let curTarget2 = this.targets[p];
							if (compare(curTarget2.text, uiText) > 0) {
								this.targets.splice(p, 0, curItem);
								hasInsert = true;
								break;
							}

						}
						if (!hasInsert) {
							this.targets.push(curItem);
						}
					});

					//同步绑定
					// this.$emit('input', this.targets);
					this.syncInput();

				}
			},

			addCounty() {

				let checkedCountys = this.checkedCountys;
				if (checkedCountys.length > 0) {
					let newCountys = [];
					this.countys.forEach((item) => {
						if (!this.checkedCountys.includes(item)) {
							newCountys.push(item);
						}
					});
					this.countys = newCountys;
					this.checkedCountys = [];


					//添加到目标地区
					for (let m = 0; m < this.targets.length; m++) {

						let curTarget = this.targets[m]
						for (let n = 0; n < checkedCountys.length; n++) {
							if (checkedCountys[n].id == curTarget.countyId) {

								this.targets.splice(m, 1);	/* 删除自己下一级的元素 */
								m--;

								for (let k = 0; k < this.checkedTargets.length; k++) {
									let curCheckedTarget = this.checkedTargets[k];
									if (curCheckedTarget == curTarget) {
										this.checkedTargets.splice(k, 1);	/* 上面不要了，删除这个选中 */
										break;
									}
								}
								break;
							}
						}

					}
					checkedCountys.forEach((item) => {
						let uiText = ellipsis(item.provinceName) + '-' + ellipsis(item.cityName) + '-' + item.text;
						let curItem = {
							level: 3,
							provinceId: item.provinceId,
							provinceName: item.provinceName,
							cityId: item.cityId,
							cityName: item.cityName,
							countyId: item.id,
							countyName: item.text,
							isFocus: false,
							isShow: (!this.searchTargetTxt) || utils.hasSearch(this.searchTargetTxt, uiText),
							id: 'county' + item.id,
							text: uiText
						}

						let hasInsert = false;
						for (let p = 0; p < this.targets.length; p++) {
							let curTarget2 = this.targets[p];
							if (compare(curTarget2.text, uiText) > 0) {
								this.targets.splice(p, 0, curItem);
								hasInsert = true;
								break;
							}

						}
						if (!hasInsert) {
							this.targets.push(curItem);
						}
					});

					//同步绑定
					// this.$emit('input', this.targets);
					this.syncInput();

				}
			},

			getFocusProvinceId() {
				for (let i = 0; i < this.provinces.length; i++) {
					var item = this.provinces[i];
					if (item.isFocus) {
						return item.id;
					}
				}
				return false;
			},

			getFocusCityId() {
				for (let i = 0; i < this.citys.length; i++) {
					var item = this.citys[i];
					if (item.isFocus) {
						return item.id;
					}
				}
				return false;
			},

			/* 删除所选择的地区 */
			removeTarget() {

				let checkedTargets = this.checkedTargets;
				if (checkedTargets.length > 0) {

					let newTargets = [];
					this.targets.forEach((item) => {
						if (!this.checkedTargets.includes(item)) {
							newTargets.push(item);
						}
					});
					this.targets = newTargets;
					this.checkedTargets = [];


					//还原到省/市/区域中
					let hasInsert;

					checkedTargets.forEach((item) => {

						if (item.level == 1) {		/* 省级 */
							let newProvince = {
								id: item.provinceId,
								text: item.provinceName,
								isFocus: false,
								isShow: (!this.searchProvinceTxt) || utils.hasSearch(this.searchProvinceTxt, item.provinceName)
							}

							hasInsert = false;
							for (let i = 0; i < this.provinces.length; i++) {
								let curProvince = this.provinces[i];
								if (compare(curProvince.text, item.provinceName) > 0) {
									this.provinces.splice(i, 0, newProvince);
									hasInsert = true;
									break;
								}

							}
							if (!hasInsert) {
								this.provinces.push(newProvince);
							}

						} else if (item.level == 2) {	/* 市级 */
							let focusProvinceId = this.getFocusProvinceId();
							if (focusProvinceId == item.provinceId) {
								let newCity = {
									id: item.cityId,
									text: item.cityName,
									provinceId: item.provinceId,
									provinceName: item.provinceName,
									isFocus: false,
									isShow: (!this.searchCityTxt) || utils.hasSearch(this.searchCityTxt, item.cityName)
								}

								hasInsert = false;
								for (let i = 0; i < this.citys.length; i++) {
									let curCity = this.citys[i];
									if (compare(curCity.text, item.cityName) > 0) {
										this.citys.splice(i, 0, newCity);
										hasInsert = true;
										break;
									}

								}
								if (!hasInsert) {
									this.citys.push(newCity);
								}
							} else {
								//放弃，当前的市级不是自己的同类
							}

						} else if (item.level == 3) {	/* 区级 */
							let focusCityId = this.getFocusCityId();
							if (focusCityId == item.cityId) {
								let newCounty = {
									id: item.countyId,
									text: item.countyName,
									provinceId: item.provinceId,
									provinceName: item.provinceName,
									cityId: item.cityId,
									cityName: item.cityName,
									isFocus: false,
									isShow: (!this.searchCountyTxt) || utils.hasSearch(this.searchCountyTxt, item.countyName)
								}

								hasInsert = false;
								for (let i = 0; i < this.countys.length; i++) {
									let curCounty = this.countys[i];
									if (compare(curCounty.text, item.countyName) > 0) {
										this.countys.splice(i, 0, newCounty);
										hasInsert = true;
										break;
									}

								}
								if (!hasInsert) {
									this.countys.push(newCounty);
								}
							} else {
								//放弃，当前的市级不是自己的同类
							}

						}
					});

					//同步绑定
					// this.$emit('input', this.targets);
					this.syncInput();

				}

			},

			syncInput() {
				var ids = [];
				this.targets.forEach(item => {
					var txt;
					if (item.level == 1) {
						txt = item.provinceId;
					} else if (item.level == 2) {
						txt = item.provinceId + '-' + item.cityId;
					} else {
						txt = item.provinceId + '-' + item.cityId + '-' + item.countyId;
					}
					ids.push(txt);
				});
				this.selectedList = ids;
				this.$emit('input', utils.deepCopy(ids));
			}

		}
	};
</script>

<style lang="scss">

	.vip-region-box {
		*zoom:1;
		&:after{ display:block; clear:both; content:""; height: 0; overflow: hidden;}

		.source-col {
			float: left;
			width: 70%;
			border: 1px solid #ebeef5;
		    border-radius: 4px;
		    box-sizing: border-box;
		    -webkit-box-sizing: border-box;
		    position: relative;
		}

		.target-col {
			margin-left: 2%;
			float: left;
			width: 28%;
			margin-right: -4px;
			border: 1px solid #ebeef5;
		    border-radius: 4px;
		    box-sizing: border-box;
		    -webkit-box-sizing: border-box;
		}

		.arrow-right {
			position: absolute;
			top: 50%;
			right: -15px;
			margin-top: -10px;
		}

		.province-col {
			float: left;
			width: 32%;
			border-right: 1px solid #ebeef5;
		    -webkit-box-sizing: border-box;
		    box-sizing: border-box;
		    position: relative;
		}

		.city-col {
			float: left;
			width: 32%;
			border-right: 1px solid #ebeef5;
			-webkit-box-sizing: border-box;
		    box-sizing: border-box;
		    position: relative;
		}

		.county-col {
			float: left;
			width: 36%;
			-webkit-box-sizing: border-box;
		    box-sizing: border-box;
		    position: relative;
		}

		.vip-header {
			position: relative;
			height: 40px;
			line-height: 40px;
			background: #f5f7fa;
			margin: 0;
			padding-left: 15px;
			border-bottom: 1px solid #ebeef5;
			-webkit-box-sizing: border-box;
			box-sizing: border-box;
			color: #000;
		}

		.per-num {
			position: absolute;
		    right: 15px;
		    color: #909399;
		    font-size: 12px;
		    font-weight: 400;
		}

		.vip-search {
			text-align: center;
		    margin: 15px;
		    -webkit-box-sizing: border-box;
		    box-sizing: border-box;
		    display: block;
		    width: auto;

		    .el-input__inner{
				border-radius: 16px;
			}
		}

		.list-box {
			height: 194px;
    		padding-top: 0;
    		border-bottom: 1px solid #ebeef5;
    		overflow-x: hidden;
    		overflow-y: auto;
		}

		.vip-footer {
			position: relative;
			margin: 0;
			padding: 5px 0;
			text-align: center;
		}

		.checkbox-bar {
			display: block;
			padding: 2px 0 2px 15px;
			margin: 0 !important;
		}

		.checkbox-bar:hover {
			background: #dfe0e2;
		}

		.checkbox-bar.is-focus {
			background: #d3d5d7;
		}


		.none-txt {
			color: #909399;
			padding-left: 20px;
			text-align: left;
		}

	}
</style>