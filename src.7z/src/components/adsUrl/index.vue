<template>
	<div class="vip-url-box">

		<template v-for="(item, index) in value.urls">
			<div v-if="index == 0" class="url-row" :key="index">
				<el-input
					v-model="item.url"
					type="textarea"
					:rows="1"
					:placeholder="value.placeholder"
					size="small"
				></el-input>
				<el-tooltip placement="right">
					<div slot="content" class="g-ads-tooltip">新增分仓或分平台的跳转地址，不分仓只填此跳转地址即可</div>
					<div class="url-normal-icon" @click="addUrl"><i class="el-icon-circle-plus"></i></div>
				</el-tooltip>

				<el-tooltip placement="right">
					<div slot="content" class="g-ads-tooltip">点击预览跳转地址（仅支持URL形式）</div>
					<div class="url-view-icon"><i class="el-icon-view" @click="clickView(item.url, '此跳转地址')"></i></div>
				</el-tooltip>
			</div>
			<div v-else class="url-row" :key="index">
				<div class="clearfix">

					<el-select v-model="item.warehouse" class="select-wrap" slot="prepend" placeholder="请选择" size="small">
						<el-option
						v-for="item in urlWarehouseList"
						:key="item.id"
						:label="item.name"
						:value="item.id">
						</el-option>
					</el-select>

					<el-select v-model="item.platform" class="select-wrap" slot="prepend" placeholder="请选择" size="small">
						<el-option
						v-for="item in urlPlatformList"
						:key="item.id"
						:label="item.name"
						:value="item.id">
						</el-option>
					</el-select>
<!-- placeholder="读取跳转方式的&quot;跳转参数&quot;" -->
					<el-input
						class="url-wrap"
						type="textarea"
						:rows="1"
						:placeholder="value.placeholder"
						v-model="item.url"
						size="small"
					></el-input>

				</div>

				<el-tooltip placement="right">
					<div slot="content" class="g-ads-tooltip">删除此跳转地址</div>
					<div class="url-normal-icon" @click="deleteUrl(index)"><i class="el-icon-remove"></i></div>
				</el-tooltip>

				<el-tooltip placement="right">
					<div slot="content" class="g-ads-tooltip">点击预览跳转地址（仅支持URL形式）</div>
					<div class="url-view-icon"><i class="el-icon-view" @click="clickView(item.url, '此跳转地址')"></i></div>
				</el-tooltip>
			</div>
		</template>
	</div>
</template>
<script>

	import utils from '../../libs/utils';

	export default {
		props: {
			value: {
				type: Object,
				required: true
			},

			urlPlatformList: {
				type: Array,
				required: true
			},

			urlWarehouseList: {
				type: Array,
				required: true
			}

		},

		data: function() {
			return {
				// warehouseList: [{
				// 		id: '',
				// 		name: '全部分仓'
				// 	},{
				// 		id: 'VIP_BJ',
				// 		name: '北京-BJ'
				// 	},{
				// 		id: 'VIP_CD',
				// 		name: '成都-CD'
				// 	},{
				// 		id: 'VIP_SH',
				// 		name: '上海-SH'
				// 	},{
				// 		id: 'VIP_NH',
				// 		name: '南海-NH'
				// 	},{
				// 		id: 'VIP_HZ',
				// 		name: '华中-HZ'}],
			};
		},

		computed: {

		},

		watch: {

			value(val) {
				if (val && (val != this.value)) {
					// this.selectedList = val;
					// this.update();
				}
			},

			urlPlatformList(val) {
				if (val && (val != this.platforms)) {
					this.platforms = val;
				}
			}
		},

		mounted() {

		},

		destroyed() {

		},

		created() {

		},

		methods: {

			addUrl() {
				var maxNum = 20;
				if (this.value.urls.length > maxNum) {
					this.$toast({
						title: '冷静，最多' + (maxNum + 1) + '条跳转地址.',
						type: 'warning'
					});
					return;
				}

				var info = {
					url: '',
					warehouse: '',
					platform: ''
				};
				this.value.urls.splice(1, 0, info);
			},

			deleteUrl(index) {
				this.value.urls.splice(index, 1);
				this.syncInput();
			},

			clickView(url, title) {
				if (utils.isUri(url)) {
					window.open(url, '_blank');
				} else {
					this.$toast({
						title: title + '不是一条完整的链接，不能打开！',
						type: 'warning'
					});
				}
			},

			syncInput() {
				this.$emit('input', this.value);
			}

		}
	};
</script>

<style lang="scss">

	.vip-url-box {
		*zoom:1;
		position: relative;
		&:after{ display:block; clear:both; content:""; height: 0; overflow: hidden;}

		.url-row {
			margin-top: 10px;
			position: relative;
			background: #fff;
		}

		.url-wrap {
			width: 64%;
			margin-right: -4px;
		}

		.select-wrap {
			float: left;
			width: 18%;
		}

		.select-wrap .el-input__inner {
			border-right: 0px;
			border-radius: 0;
			border-radius: 0;
			height: 33px;
		}

		.select-wrap:first-child .el-input__inner{
			border-top-left-radius: 4px;
			border-bottom-left-radius: 4px;
		}

		.url-wrap .el-textarea__inner {
			border-top-left-radius: 0;
			border-bottom-left-radius: 0;
		}

		.select-wrap .el-input.is-focus .el-input__inner {
			border-color: #dcdfe6 !important;
		}

		.url-normal-icon {
			position: absolute;
			right: -36px;
			top: 6px;
			/*margin-top: -10px;*/
			width: 24px;
			height: 24px;
			cursor: pointer;
			color: #8492a6;
			font-size: 20px;
		}

		.url-normal-icon:hover {
			color: #1d8ce0;
		}

		.url-view-icon {
			position: absolute;
			right: -60px;
			top: 6px;
			/*margin-top: -10px;*/
			width: 24px;
			height: 24px;
			cursor: pointer;
			color: #8492a6;
			font-size: 20px;
			outline: none;
		}

		.url-view-icon:hover {
			color: #1d8ce0;
		}

	}
</style>