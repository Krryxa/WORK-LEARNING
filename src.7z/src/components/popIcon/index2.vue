<template>
	<div class="pop-img-warp">
		<Cover
			:isShow = 'isShow'
		></Cover>	
		<transition name="fade">
			<div class="pop-img"
				v-if="isShow"
			>	
		    	<img
					v-if="imgUrl && imgUrl!=''"
					:src="imgUrl"
				>
				<div class="pop-close"
					@click="close"
					v-bind:class="getWH.className"
				>
					<a></a>
				</div>
				<div class="img-detail">
					<span>{{getWH.width}}</span> X <span>{{getWH.height}}</span>
				</div>
			</div>	
		</transition>	
	</div>
</template>
<script>
	import Cover from '../cover/index';

	export default {
		props: {
			isShow: {
				type: Boolean,
				default: false
			},
			imgUrl: {
				type: String,
				default: ''
			}
		},
		computed: {
			getWH() {
				let img = new Image();
				let className = '';
				img.src = this.imgUrl;
				if (img.height > window.screen.height) {
					className = 'offset';
				}
				return {
					width: img.width,
					height: img.height,
					className: className
				};
			}
		},
		methods: {
			close() {
				this.$emit('close');
			}
		},
		components: {
			Cover
		}
	};
</script>
<style lang="scss" scoped>
	.pop-img-warp .pop-img{
		position:absolute;
		top: 50%;
		left: 50%;
		z-index: 101;
		transition: transform 1s cubic-bezier(.23,1,.32,1) .1s,opacity .5s cubic-bezier(.23,1,.32,1) .1s;		
		transform:translate(-50%,-50%);
	}
	.pop-img-warp .fade-leave-active{
		transform:translate(100%,100%) rotate3d(1,1,0,90deg);
	}
	.pop-img-warp .fade-enter {
		transform:translate(-100%,-100%) rotate3d(1,1,0,90deg);
	}
	.pop-close{
		position:absolute;
		right:-15px;
		top: -15px;
		border-radius: 50%;
		background: #fff;
		width: 30px;
		height: 30px;
		cursor: pointer;
		transition: transform 1s cubic-bezier(.23,1,.32,1) .1s,
	}
	.pop-close.offset{
		top: 50%;
		transform:translate(0,-50%);
	}
	.pop-close a{ 
		display: inline-block; 
		width: 20px;
		height:2px; 
		background: #000000;
		line-height: 0;
		font-size:0;
		vertical-align: middle;
		transform: rotate(45deg);
		margin:8px 0 0 5px;
	}
  	.pop-close a:after{
  		content:'/';
  		display:block;
  		width: 20px;
  		height:2px;
  		background: #000000;
  		transform: rotate(-90deg);
  	}
	.pop-close:hover{
		transform:scale(1.2);
	}
	.img-detail{
		color: #ffffff;
		text-align: center;
		font-size: 16px;
		padding: 5px 0;
	}
	.img-detail span{
		font-size: 24px;
		color: #20A0FF;
		padding: 0 5px;
	}
</style>