<template>
	<div>
		<div class="pop-icon-box" @click.stop="clickIcon">
			<!--<img alt="" ref="img"
				:src="getImg('icon-default.jpg')"
				:class="[isdepend ? 'dependWidth' : 'dependHeight']"
			>-->
			<img alt="" ref="img"
				:src="row.imageurl"
				:class="[isdepend ? 'dependWidth' : 'dependHeight']"
			>
			<el-popover
				ref="mainImgPop"
				placement="right-start"
				trigger="hover"
				>
				<div>
					<img v-if="isLoaded" alt="" :style="size"
						:src="row.imageurl"
					>
					<div class="icon-pop-name">
						{{rawSize.width + ' x ' + rawSize.height}}
					</div>
				</div>
			</el-popover>

			<div class="icon-cover"
				v-show="isLoaded"
				v-popover:mainImgPop
			>
				<div class="ad-view-box">
					<i class="el-icon-view"></i>
					<span class="icon-txt">编辑广告内容</span>
				</div>
			</div>
		</div>
	</div>
</template>
<script>

	const scrollName = 'scrollName';

	export default {
		props: {
			rowData: {
				type: Object,
				required: true
			}
		},

		data: function() {
			return {
				row: this.rowData,
				size: {
					width: '1px',
					height: '1px'
				},
				rawSize: {
					width: '0',
					height: '0'
				},
				isLoaded: false,
				isdepend: true
			};
		},

		// computed: {
		// 	isdepend() {
		// 		return true;
		// 	}
		// },

		mounted() {
			// console.log('icon mounted..................');
			this.$won(scrollName, function(data) {
				// console.log(this);
				this.$woff(scrollName);
				// console.log('data: ----------------', data);
			});
		},

		destroyed() {
			this.$woff(scrollName);
		},

		created() {
			// console.log('icon created..................');
			var vm = this;
			var rawImg = new Image();	/* 创建一个图片实例。 */
			rawImg.onload = function() {
				var size = vm.countSize(rawImg);
				rawImg.onload = rawImg.onerror = rawImg.onabort = null;
				if (size) {
					vm.size = size;
					vm.rawSize = {width: rawImg.width, height: rawImg.height};
					vm.isLoaded = true;
					vm.$refs.img.src = vm.row.imageurl;
				} else {
					vm.$refs.img.src = vm.getImg('no-img.png');
				}
				rawImg = null;
			};

			rawImg.onerror = rawImg.onabort = function(e) {
				rawImg.onload = rawImg.onerror = rawImg.onabort = null;
				rawImg = null;
				vm.$refs.img.src = vm.getImg('no-img.png');
			};
			rawImg.src = vm.row.imageurl;
		},

		methods: {
			// 获取图片路径
			getImg(name) {
				return this.$URL.getImgUrl() + name;
			},

			countSize(img) {
				var maxW = 468;
				var maxH = 200;
				var w = img.width;
				var h = img.height;
				var newW, newH;
				var rateW, rateH;

				if (w && h) {
					if (w <= maxW && h <= maxH) {
						return {width: w, height: h};
					} else if (w > maxW && h > maxH) {
						rateW = w / maxW;
						rateH = h / maxH;
						if (rateW > rateH) {
							newW = maxW;
							newH = Math.floor(h / rateW);
							this.isdepend = true;
						} else {
							newW = Math.floor(w / rateH);
							newH = maxH;
							this.isdepend = false;
						}
					} else {
						if (w > maxW) {
							rateW = w / maxW;
							newW = maxW;
							newH = Math.floor(h / rateW);
							this.isdepend = true;
						} else {
							rateH = h / maxH;
							newW = Math.floor(w / rateH);
							newH = maxH;
							this.isdepend = false;
						}
					}

					return {width: newW + 'px', height: newH + 'px'};

				} else {
					return false;
				}
				if (w == h) {
					this.isdepend = false;
				}
			},

			clickIcon() {
				this.$emit('click');
			}
		}
	};
</script>

<style lang="scss" scoped>
	
	$opacity : opacity .5s cubic-bezier(.23,1,.32,1) .1s;
	$transform : transform .3s cubic-bezier(.23,1,.32,1) .1s;
	.dependWidth{
			max-width: 100%;
			max-height: 100%;
		}

		.dependHeight{
			max-width: 100%;
			max-height: 100%;
		}
	.icon-pop-name {
		margin-top: 2px;
		text-align: center;
	}

	.pop-icon-box {
		width: 117px;
		height:50px;
		overflow:hidden;
		margin: 10px auto;
		position:relative;
		background: rgba(0,0,0,0);
		display: flex;
    	align-items: center;
		justify-content: center;

		/*img {
			display:block;
			pointer-events:none;
		}*/

		.icon-cover {
			background: rgba(0, 0, 0, 0.72);
			width:100%;
			height:100%;
			position:absolute;
			top:0px;
			left:0px;
			transition: $opacity;
			opacity:0;
		}
		

		.ad-view-name {
			position:absolute;
			bottom:0px;
			left:0px;
			width:95%;
			height:22px;
			line-height:23px;
			padding:0 0 0 5%;
			font-weight: 400;
			color: #fff;
			text-align:left;
			overflow:hidden;
			font-size:12px;
			transition: $transform;
			transform:scaleY(0);

		}
		.cover-msg {
			color:#fff;
			font-size:12px;
			transition: $transform,$opacity;
			transform:translateY(5px);
			opacity:0;
		}

		&:hover {
			.icon-cover {
				opacity:1;
			}
			.ad-view-name {
				transform:scaleY(1);
			}
		}
	}
</style>